//
//  CreatePostViewController.swift
//  Oriscene
//
//  Created by Parth on 14/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit
import MobileCoreServices
import AVFoundation
import CoreLocation

protocol CreatePostDelegate {
    func reloadPostData() -> Void
}

class CreatePostViewController: BaseViewController, UICollectionViewDelegate,UICollectionViewDataSource, UITextFieldDelegate, UITextViewDelegate , CreatePostCategoryDelegate, UINavigationControllerDelegate , UIImagePickerControllerDelegate, AttachmentCreatePostDelegate, AttachmentVideoCreatePostDelegate, LocationSearchViewDelegate, CLLocationManagerDelegate {
    
    var delegate : CreatePostDelegate?
    
    let locationManager = CLLocationManager()
    var dictSelectedCatgeroy = Dictionary<String, String>()
    var arrAttachment = [ Dictionary<String,Any>]()
    var viewLocationSearch : LocationSearchView? = nil
    var dictSelectedLocation : Dictionary<String, Any>?
    var assets = [DKAsset]()
    var service = WebService()
    var currentAttachmentIndex = -1
    var arrUploadedAttachment = [Dictionary<String,Any>]()
    var selectedCategoryForCreatePost : NSInteger = -1
    var dictPostData = NSMutableDictionary()
    
    @IBOutlet var viewProfileDataContainer: UIView!
    @IBOutlet var imgProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var txtViewDetail: UITextView!
    @IBOutlet var viewImageVideoContainer: UIView!
    @IBOutlet var cvAttachedImageVideo: UICollectionView!
    @IBOutlet var viewLocationContainer: UIView!
    @IBOutlet var lblLocation: UILabel!
    @IBOutlet var viewAttachmentTypeContainer: UIView!
    @IBOutlet var btnImageType: UIButton!
    @IBOutlet var btnLocationType: UIButton!
    @IBOutlet var btnVideoType: UIButton!
    @IBOutlet var viewShareSellTypeContainer: UIView!
    @IBOutlet var btnShare: UIButton!
    @IBOutlet var btnSell: UIButton!
    @IBOutlet var viewAdultCategoryContainer: UIView!
    @IBOutlet var btnAdultContent: UIButton!
    @IBOutlet var viewCategoryContainer: UIView!
    @IBOutlet var imgDownArrawForCategory: UIImageView!
    
    @IBOutlet var btnSelectCategory: UIButton!
    @IBOutlet var btnShareIt: UIButton!
    
    @IBOutlet var viewInputAccessory: UIView!
    @IBOutlet var btnDoneInputAcceesory: UIButton!
    
    @IBOutlet var viewAutoAutionPriceContainer: UIView!
    @IBOutlet var btnAuto: UIButton!
    @IBOutlet var btnAuction: UIButton!
    
    
    @IBOutlet var viewPriceContainer: UIView!
    @IBOutlet var viewPriceTextFieldContainer: UIView!
    @IBOutlet var txtPrice: UITextField!
    
    @IBOutlet var viewDateContainer: UIView!
    @IBOutlet var imgDateIcon: UIImageView!
    @IBOutlet var txtDate: UITextField!
    
    @IBOutlet var viewDatePickerContainer: UIView!
    @IBOutlet var viewDateContainerPickerHeader: UIView!
    @IBOutlet var btnCancelDate: UIButton!
    @IBOutlet var btnSelectDate: UIButton!
    
    @IBOutlet var datePicker: UIDatePicker!
    @IBOutlet var viewTransparent: UIView!
    
    @IBOutlet var heightConstViewAutoAuction: NSLayoutConstraint!
    @IBOutlet var heightConstViewDate: NSLayoutConstraint!
    @IBOutlet var heightConstContentView: NSLayoutConstraint!
    @IBOutlet var heightConstImageVideoContainer: NSLayoutConstraint!
    @IBOutlet var heightConstLocationContainer: NSLayoutConstraint!
    
    @IBOutlet var btnRemoveLocation: UIButton!
    
    @IBOutlet var bottomConstScrollView: NSLayoutConstraint!
    
    @IBOutlet weak var viewPrimePostContainer: UIView!
    @IBOutlet weak var heighConstPrimePostContainer: NSLayoutConstraint!
    @IBOutlet weak var btnPrime: UIButton!
    
    //Content Specification OutLets
    @IBOutlet weak var viewContenetSpecification: UIView!
    @IBOutlet weak var viewContentSpecificationContainer: UIView!
    @IBOutlet weak var lblFileType: UILabel!
    @IBOutlet weak var lblFileSize: UILabel!
    @IBOutlet weak var lblFileFormat: UILabel!
    @IBOutlet weak var lblAdultContent: UILabel!
    @IBOutlet weak var lblMultiFile: UILabel!
    @IBOutlet weak var lblSellOption: UILabel!
    @IBOutlet weak var lblSpecificationDate: UILabel!
    @IBOutlet weak var lblContentDescription: UILabel!
    @IBOutlet weak var btnSignTheEcontract: UIButton!
    @IBOutlet weak var lblSpecificationLocation: UILabel!
    
    // MARK: - UIView Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            //            lblUserName.text = (dictUser["firstname"] as! String) + " " + (dictUser["lastname"] as! String)
            let strusenickname = dictUser["usenickname"] as! String
            if strusenickname == "1" {
                lblUserName.text = dictUser["reporter_name"] as? String
            }
            else{
                lblUserName.text = (dictUser["firstname"] as! String) + " " + (dictUser["lastname"] as! String)
            }
            imgProfilePic.clipsToBounds = true
            imgProfilePic.contentMode = UIViewContentMode.redraw
            
            if dictUser.keys.contains("photo") {
                let strPhotoName = dictUser["photo"] as! String
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictUser["photo"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    imgProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    imgProfilePic.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                imgProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            //            locationManager.startUpdatingLocation()
        }
        self.setUpUI()
        
        viewContenetSpecification.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if viewLocationSearch == nil {
            viewLocationSearch = LocationSearchView.instanceFromNib() as? LocationSearchView
            viewLocationSearch?.frame = UIScreen.main.bounds
            viewLocationSearch?.isHidden = true
            viewLocationSearch?.delegate = self
            viewLocationSearch?.alpha = 0.0
            self.view.addSubview(viewLocationSearch!)
        }
        
    }
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLayoutSubviews() {
        cvAttachedImageVideo.register(ImageVideoAttachmentCVCell.self, forCellWithReuseIdentifier: "ImageVideoAttachmentCVCell")
        cvAttachedImageVideo.register(UINib.init(nibName: "ImageVideoAttachmentCVCell", bundle: nil), forCellWithReuseIdentifier: "ImageVideoAttachmentCVCell")
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstScrollView?.constant = 0.0
                //                self.scrollView.setContentOffset(CGPoint(x: 0.0, y: 0.0), animated: true)
            } else {
                self.bottomConstScrollView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - Custom Method
    
    func setUpUI() -> Void {
        self.hideSpinner()
        btnShare.isSelected = true
        btnSell.isSelected = false
        
        btnAuction.isSelected = false
        btnAuto.isSelected = true
        
        heightConstImageVideoContainer.constant = 0.0
        heightConstLocationContainer.constant = 0.0
        heightConstViewDate.constant = 0.0
        heightConstViewAutoAuction.constant = 0.0
        
        viewImageVideoContainer.isHidden = true
        viewDateContainer.isHidden = true
        viewLocationContainer.isHidden = true
        viewAutoAutionPriceContainer.isHidden = true
        
        heighConstPrimePostContainer.constant = 0.0
        heightConstContentView.constant = 580 + heightConstImageVideoContainer.constant + heightConstLocationContainer.constant + heightConstViewAutoAuction.constant + heightConstViewDate.constant + heighConstPrimePostContainer.constant
        
        self.view.updateConstraintsIfNeeded()
        self.view.layoutIfNeeded()
        
        viewTransparent.isHidden = true
        
        viewInputAccessory.layer.borderColor = UIColor.lightGray.cgColor
        viewInputAccessory.layer.borderWidth = 1.0
        
        viewDateContainerPickerHeader.layer.borderColor = UIColor.lightGray.cgColor
        viewDateContainerPickerHeader.layer.borderWidth = 1.0
        
        txtViewDetail.inputAccessoryView = viewInputAccessory
        txtDate.inputView = viewDatePickerContainer
        
        txtPrice.inputAccessoryView = viewInputAccessory
        
        self.view.layoutIfNeeded()
        imgProfilePic.layer.cornerRadius = imgProfilePic.frame.size.height / 2
        imgProfilePic.layer.masksToBounds = true
        
        viewShareSellTypeContainer.layer.cornerRadius = 3.0
        viewShareSellTypeContainer.layer.masksToBounds = true
        viewShareSellTypeContainer.layer.borderWidth = 1.0
        viewShareSellTypeContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        viewCategoryContainer.layer.borderWidth = 1.0
        viewCategoryContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewCategoryContainer.layer.cornerRadius = 3.0
        viewCategoryContainer.layer.masksToBounds = true
        
        btnShareIt.layer.cornerRadius = 3.0
        btnShareIt.layer.masksToBounds = true
        
        viewPriceContainer.layer.borderWidth = 1.0
        viewPriceContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        viewPriceTextFieldContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewPriceTextFieldContainer.layer.borderWidth = 1.0
        viewPriceTextFieldContainer.layer.cornerRadius = 3.0
        viewPriceTextFieldContainer.layer.masksToBounds = true
        
        viewDateContainer.layer.cornerRadius = 3.0
        viewDateContainer.layer.borderWidth = 1.0
        viewDateContainer.layer.masksToBounds = true
        viewDateContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        btnRemoveLocation.layer.cornerRadius = btnRemoveLocation.frame.size.height / 2.0
        btnRemoveLocation.layer.masksToBounds = true
        
        cvAttachedImageVideo.register(ImageVideoAttachmentCVCell.self, forCellWithReuseIdentifier: "ImageVideoAttachmentCVCell")
        cvAttachedImageVideo.register(UINib.init(nibName: "ImageVideoAttachmentCVCell", bundle: nil), forCellWithReuseIdentifier: "ImageVideoAttachmentCVCell")
        
        cvAttachedImageVideo.register(VideoAttachmentCVCell.self, forCellWithReuseIdentifier: "VideoAttachmentCVCell")
        cvAttachedImageVideo.register(UINib.init(nibName: "VideoAttachmentCVCell", bundle: nil), forCellWithReuseIdentifier: "VideoAttachmentCVCell")
        
        cvAttachedImageVideo.reloadData()
    }
    
    // MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrAttachment.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let dictAttachment = arrAttachment[indexPath.row]
        
        if dictAttachment["type"] as! String == "0" {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageVideoAttachmentCVCell", for: indexPath) as! ImageVideoAttachmentCVCell
            cell.delegate = self
            cell.index = indexPath.row
            
            let nsDocumentDirectory = FileManager.SearchPathDirectory.documentDirectory
            let nsUserDomainMask    = FileManager.SearchPathDomainMask.userDomainMask
            let paths               = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory, nsUserDomainMask, true)
            if let dirPath          = paths.first
            {
                let imageURL = URL(fileURLWithPath: dirPath).appendingPathComponent(dictAttachment["imageName"]! as! String)
                let image    = UIImage(contentsOfFile: imageURL.path)
                cell.imgAttachment.image = image
            }
            return cell
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VideoAttachmentCVCell", for: indexPath) as! VideoAttachmentCVCell
            cell.delegate = self
            cell.index = indexPath.row
            cell.lblVideoName.text = dictAttachment["videoName"] as! String?
            cell.imgAttachedVideo.image = UIImage.init(named: "video_icon_sel")
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath : IndexPath) -> CGSize{
        
        let dictAttachment = arrAttachment[indexPath.row]
        
        if dictAttachment["type"] as! String == "0" {
            return CGSize(width: 100, height: 100);
        }
        else{
            return CGSize(width: self.view.frame.size.width - 40, height: 50);
        }
    }
    // MARK: - UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
    
    // MARK: - Action Method
    
    @IBAction func btnImageTypeAction(_ sender: Any) {
        
        if btnVideoType.isSelected {
            if arrAttachment.count > 0 {
                let alertWarning = UIAlertView(title: Constant.APP_NAME, message: Constant.ALERT_MSG_ATTACHMENT_TYPE_VALIDATE + " Image" , delegate: nil, cancelButtonTitle: "OK")
                alertWarning.show()
            }
            else{
                if arrAttachment.count >= 5 {
                    let alertWarning = UIAlertView(title: Constant.APP_NAME, message: Constant.ALERT_MSG_ATTACHMENT_TYPE_IMAGE_MAXIMUM_VALIDATE , delegate: nil, cancelButtonTitle: "OK")
                    alertWarning.show()
                }
                else{
                    btnImageType.isSelected = true
                    btnVideoType.isSelected = false
                    btnLocationType.isSelected = false
                    self.selectImage()
                }
            }
        }
        else{
            
            if arrAttachment.count >= 5 {
                let alertWarning = UIAlertView(title: Constant.APP_NAME, message: Constant.ALERT_MSG_ATTACHMENT_TYPE_IMAGE_MAXIMUM_VALIDATE , delegate: nil, cancelButtonTitle: "OK")
                alertWarning.show()
            }
            else{
                btnImageType.isSelected = true
                btnVideoType.isSelected = false
                btnLocationType.isSelected = false
                //self.selectImage()
                openGalleryForImageSelection()
            }
        }
        
    }
    
    @IBAction func btnLocationTypeAction(_ sender: Any) {
        
        let alert:UIAlertController=UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let SearchLocationAction = UIAlertAction(title: "Pick location from list", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.viewLocationSearch?.isHidden = false
            UIView.animate(withDuration: 0.0, animations: {() -> Void in
                self.viewLocationSearch?.alpha = 0.0
            }, completion: {(_ finished: Bool) -> Void in
                UIView.animate(withDuration: 0.3, animations: {() -> Void in
                    self.viewLocationSearch?.alpha = 1.0
                }, completion: { _ in })
            })
            self.btnImageType.isSelected = false
            self.btnVideoType.isSelected = false
            self.btnLocationType.isSelected = true
        }
        let CurrentLoationAction = UIAlertAction(title: "Use current location", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.btnImageType.isSelected = false
            self.btnVideoType.isSelected = false
            self.btnLocationType.isSelected = true
            
            DispatchQueue.main.async {
                self.showSpinner(enableInteraction: false)
            }
            self.locationManager.startUpdatingLocation()
            
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
        }
        
        // Add the actions
        
        alert.addAction(SearchLocationAction)
        alert.addAction(CurrentLoationAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func btnVideoTypeAction(_ sender: Any) {
        
        if btnImageType.isSelected {
            if arrAttachment.count > 0 {
                let alertWarning = UIAlertView(title: Constant.APP_NAME, message: Constant.ALERT_MSG_ATTACHMENT_TYPE_VALIDATE + " Video", delegate: nil, cancelButtonTitle: "OK")
                alertWarning.show()
            }
            else{
                if arrAttachment.count >= 1 {
                    let alertWarning = UIAlertView(title: Constant.APP_NAME, message: Constant.ALERT_MSG_ATTACHMENT_TYPE_VIDEO_MAXIMUM_VALIDATE , delegate: nil, cancelButtonTitle: "OK")
                    alertWarning.show()
                }
                else{
                    btnImageType.isSelected = false
                    btnVideoType.isSelected = true
                    btnLocationType.isSelected = false
                    self.selectVideo()
                }
            }
        }
        else{
            
            if arrAttachment.count >= 1 {
                let alertWarning = UIAlertView(title: Constant.APP_NAME, message: Constant.ALERT_MSG_ATTACHMENT_TYPE_VIDEO_MAXIMUM_VALIDATE , delegate: nil, cancelButtonTitle: "OK")
                alertWarning.show()
            }
            else{
                btnImageType.isSelected = false
                btnVideoType.isSelected = true
                btnLocationType.isSelected = false
                self.selectVideo()
            }
        }
        
    }
    @IBAction func btnShareAction(_ sender: Any) {
        btnShare.isSelected = true
        btnSell.isSelected = false
        btnShareIt.setTitle("SHARE IT", for: UIControlState.normal)
        UIView .animate(withDuration: 0.5, animations: {
            
            self.heightConstViewAutoAuction.constant = 0
            self.heightConstViewDate.constant = 0
            self.heighConstPrimePostContainer.constant = 0
            
            if self.arrAttachment.count > 0 {
                self.heighConstPrimePostContainer.constant = 70.0
            }
            
            self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant + self.heighConstPrimePostContainer.constant
            
            self.view.updateConstraintsIfNeeded()
            self.view.layoutIfNeeded()
            
        }) { (Bool) in
            
            self.viewAutoAutionPriceContainer.isHidden = true
            self.viewDateContainer.isHidden = true
        }
    }
    @IBAction func btnSellAction(_ sender: Any) {
        btnShare.isSelected = false
        btnSell.isSelected = true
        btnShareIt.setTitle("SELL IT", for: UIControlState.normal)
        viewAutoAutionPriceContainer.isHidden = false
        viewDateContainer.isHidden = false
        
        UIView .animate(withDuration: 0.5, animations: {
            self.heightConstViewAutoAuction.constant = 170
            self.heightConstViewDate.constant = 45.0
            self.heighConstPrimePostContainer.constant = 0.0
            
            //  self.heightConstContentView.constant = 934.0
            self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant + self.heighConstPrimePostContainer.constant
            self.view.updateConstraintsIfNeeded()
            self.view.layoutIfNeeded()
        }) { (Bool) in
            
        }
    }
    @IBAction func btnAdultContentTypeAction(_ sender: Any) {
        btnAdultContent.isSelected = !btnAdultContent.isSelected
    }
    @IBAction func btnAuctionAction(_ sender: Any) {
        btnAuction.isSelected = true
        btnAuto.isSelected = false
    }
    @IBAction func btnAutoAction(_ sender: Any) {
        btnAuction.isSelected = false
        btnAuto.isSelected = true
    }
    
    @IBAction func btnSelectCategoryAction(_ sender: Any) {
        let vcCatFirst = self.storyboard?.instantiateViewController(withIdentifier: "CategoryFirstViewController") as! CategoryFirstViewController
        vcCatFirst.isFromCreatePost = true
        vcCatFirst.delegate = self
        vcCatFirst.selectedCategoryForCreatePost = selectedCategoryForCreatePost
        self.navigationController?.pushViewController(vcCatFirst, animated: true)
        
    }
    @IBAction func btnShareItAction(_ sender: Any) {
        if btnSell.isSelected {
            if trimString(string: (txtViewDetail.text)!).characters.count < 25 {
                showAlert(string: Constant.ALERT_MSG_POST_SELL_DESCRIPTION_VALIDATE)
                return
            }
            else {
                if arrAttachment.count > 0 {
                    let dictAttachment = arrAttachment[0]
                    if self.validateSellPostData() {
                        if dictAttachment["type"] as! String == "0" {
                            uploadImageData()
                        }
                        else {
                            callWebserviceUploadVideo()
                        }
                    }
                }
                else{
                    showAlert(string: Constant.ALERT_MSG_POST_ATTACHMENT_EMPTY_VALIDATE)
                }
            }
        }
        else {
            if validateSharePostData() {
                if arrAttachment.count > 0 {
                    let dictAttachment = arrAttachment[0]
                    if dictAttachment["type"] as! String == "0" {
                        uploadImageData()
                    }
                    else {
                        callWebserviceUploadVideo()
                    }
                }
                else {
                    //only text post
                    self.createDictionaryPostData()
                    self.callWebserviceCreatePost(dictParam: self.dictPostData)
                }
            }
        }
    }
    
    @IBAction func btnDoneInputAcceesoryAction(_ sender: Any) {
        
        if txtPrice.isFirstResponder {
            txtPrice.resignFirstResponder()
        }
        else{
            txtViewDetail.resignFirstResponder()
            if txtViewDetail.text.characters.count>0 {
            }
            else{
                txtViewDetail.text = "Description..."
            }
        }
    }
    
    @IBAction func btnSelectDateAction(_ sender: Any) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        let dateString = dateFormatter.string(from: datePicker.date)
        txtDate.text = dateString
        txtDate.resignFirstResponder()
    }
    @IBAction func btnCancelDateAction(_ sender: Any) {
        txtDate .resignFirstResponder()
    }
    
    @IBAction func btnRemoveLocationAction(_ sender: Any) {
        UIView .animate(withDuration: 0.5, animations: {
            self.heightConstLocationContainer.constant = 0.0
            self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant + self.heighConstPrimePostContainer.constant
            self.view.updateConstraintsIfNeeded()
            self.view.layoutIfNeeded()
        }) { (Bool) in
            self.viewLocationContainer.isHidden = true
            self.btnLocationType.isSelected = false
        }
    }
    
    @IBAction func btnPrimeAction(_ sender: Any) {
        btnPrime.isSelected = !btnPrime.isSelected
    }
    
    @IBAction func btnSignTheEcontactAction(_ sender: Any) {
        callWebserviceEcommerceAgreement()
    }
    @IBAction func btnSpecificationCloseAction(_ sender: Any) {
        viewContenetSpecification?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewContenetSpecification?.alpha = 0.0
        }) { (Bool) in
            self.viewContenetSpecification?.isHidden = true
        }
    }
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == txtDate {
            viewTransparent.isHidden = false
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        viewTransparent.isHidden = true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: - UITextViewDelegate
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        if txtViewDetail.text == "Description..." {
            txtViewDetail.text = ""
            textView.textColor = UIColor.black
        }
        
        return true
    }
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        
        if txtViewDetail.text.characters.count>0 {
            textView.textColor = UIColor.black
        }
        else{
            txtViewDetail.text = "Description..."
            textView.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        
    }
    
    func textViewDidChange(_ textView: UITextView) {
        
        let length = textView.text.characters.count as Int
        
        if length > 0 {
            textView.textColor = UIColor.black
        }
        else{
            textView.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        }
    }
    
    // MARK: - CreatePostCategoryDelegate
    
    func selectedCategoryForPost(dictCategory: Dictionary<String, String>) {
        dictSelectedCatgeroy = dictCategory
        selectedCategoryForCreatePost = Int(dictCategory["selectedCategory"]!)!
        btnSelectCategory .setTitle(dictCategory["con_name"], for: UIControlState.normal)
    }
    
    func selectedCategoryForFilterPost(arrCategory: [Dictionary<String, String>]) {
        
    }
    
    // MARK: - Select Image
    
    func selectImage() {
        
        let alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openCamera()
        }
        let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openGallary()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
        }
        // Add the actions
        
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func selectVideo() {
        
        let alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openCameraForVideo()
        }
        let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openGallaryForVideo()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
        }
        // Add the actions
        
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func openCamera()
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            picker.sourceType = UIImagePickerControllerSourceType.camera
            picker.allowsEditing = true
            self .present(picker, animated: true, completion: nil)
        }
        else
        {
            let alertWarning = UIAlertView(title: "Warning", message: "You don't have camera", delegate: nil, cancelButtonTitle: "OK")
            alertWarning.show()
        }
    }
    func openGallary()
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        picker.allowsEditing = true
        self.present(picker, animated: true, completion: nil)
    }
    
    func openCameraForVideo()
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            picker.sourceType = UIImagePickerControllerSourceType.camera
            picker.allowsEditing = true
            picker.videoMaximumDuration = 15.0
            //            picker.cameraCaptureMode = UIImagePickerControllerCameraCaptureMode.video
            picker.mediaTypes = [(kUTTypeVideo as String), (kUTTypeMovie as String)]
            self .present(picker, animated: true, completion: nil)
        }
        else
        {
            let alertWarning = UIAlertView(title: "Warning", message: "You don't have camera", delegate: nil, cancelButtonTitle: "OK")
            alertWarning.show()
        }
    }
    func openGallaryForVideo()
    {
        let picker = UIImagePickerController()
        picker.title = "Video"
        picker.navigationItem.title = "Video"
        picker.delegate = self
        picker.sourceType = UIImagePickerControllerSourceType.savedPhotosAlbum
        picker.mediaTypes = [(kUTTypeVideo as String), (kUTTypeMovie as String)]
        picker.allowsEditing = true
        self.present(picker, animated: true, completion: nil)
    }
    
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool)
    {
        if btnImageType.isSelected {
            viewController.navigationItem.title = "Photos"
        }
        else{
            viewController.navigationItem.title = "Video"
        }
    }
    
    func openGalleryForImageSelection() -> Void {
        
        let pickerController = DKImagePickerController()
        //pickerController.sourceType = DKImagePickerControllerSourceType(rawValue: 1)!
        pickerController.defaultSelectedAssets = self.assets
        pickerController.maxSelectableCount = 5
        pickerController.allowMultipleTypes = false
        pickerController.showsCancelButton = true
        pickerController.assetType = .allPhotos
        pickerController.didCancel = {
            if self.arrAttachment.count <= 0 {
                self.btnImageType.isSelected = false
                self.btnVideoType.isSelected = false
            }
        }
        pickerController.didSelectAssets = { (assets: [DKAsset]) in
            print("didSelectAssets")
            print(assets)
            if assets.count <= 0 {
                self.btnImageType.isSelected = false
                self.btnVideoType.isSelected = false
            }else {
                self.assets = assets
                self.getImageFromAssetAndReloadArray()
            }
        }
        
        self.present(pickerController, animated: true) {
        }
    }
    // MARK: - PickerView Delegate Methods
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        picker .dismiss(animated: true, completion: nil)
        let type = (info[UIImagePickerControllerMediaType] as! String)
        if (type == (kUTTypeVideo as String)) || (type == (kUTTypeMovie as String)) {
            // movie != video
            let url = info[UIImagePickerControllerMediaURL] as! URL
            
            let filePaths = url.path
            let MyUrl = NSURL(fileURLWithPath: filePaths)
            let fileAttributes = try! FileManager.default.attributesOfItem(atPath: MyUrl.path!)
            let fileSizeNumber = fileAttributes[FileAttributeKey.size] as! NSNumber
            let fileSize = fileSizeNumber.int64Value
            var sizeMB = Double(fileSize / 1024)
            sizeMB = Double(sizeMB / 1024)
            print(String(format: "%.2f", sizeMB) + " MB")
            if sizeMB > 100.00 {
                self.showAlert(string: "Video size is large.")
                return
            }
            showSpinner(enableInteraction: true)
            
            let documentsDirectory2 = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] as NSURL
            let filePath = documentsDirectory2.appendingPathComponent("uploaded-Video.mp4")
            let filePathThumbnail = documentsDirectory2.appendingPathComponent("uploaded-Video-thumbnail.png")
            
            deleteFile(filePath: (filePath?.path)!)
            deleteFile(filePath: (filePathThumbnail?.path)!)
            
            let avAsset = AVURLAsset(url: url, options: nil)
            do {
                let imgGenerator = AVAssetImageGenerator(asset: avAsset)
                imgGenerator.appliesPreferredTrackTransform = true
                let cgImage = try imgGenerator.copyCGImage(at: CMTimeMake(0, 1), actualTime: nil)
                let uiImage = UIImage(cgImage: cgImage)
                
                let imageData : NSData = UIImagePNGRepresentation(uiImage)! as NSData
                imageData.write(to: filePathThumbnail! as URL, atomically: true)
                // lay out this image view, or if it already exists, set its image property to uiImage
            } catch let error as NSError {
                print("Error generating thumbnail: \(error)")
            }
            
            let exportSession = AVAssetExportSession(asset: avAsset, presetName: AVAssetExportPresetPassthrough)
            exportSession!.outputURL = filePath
            exportSession!.outputFileType = AVFileTypeMPEG4
            exportSession!.shouldOptimizeForNetworkUse = true
            DispatchQueue.global().async {
                
                exportSession!.exportAsynchronously(completionHandler: {() -> Void in
                    
                    DispatchQueue.main.async {
                        self.hideSpinner()
                        switch exportSession!.status {
                            
                        case .failed:
                            print("%@",exportSession?.error ?? "")
                            let alertWarning = UIAlertView(title: Constant.APP_NAME, message: exportSession?.error as? String ?? "Export Fail", delegate: nil, cancelButtonTitle: "OK")
                            alertWarning.show()
                        case .cancelled:
                            print("Export canceled")
                            let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Export canceled", delegate: nil, cancelButtonTitle: "OK")
                            alertWarning.show()
                        case .completed:
                            //Video conversion finished
                            var dictVideo : Dictionary<String, Any> = [:]
                            
                            dictVideo["videoPath"] = filePath
                            dictVideo["videoName"] = filePath?.lastPathComponent
                            dictVideo["videoThumbnailPath"] = filePathThumbnail
                            dictVideo["videoThumbnailName"] = filePathThumbnail?.lastPathComponent
                            dictVideo["type"] = "1" //Video
                            self.arrAttachment.append(dictVideo)
                            
                            if self.arrAttachment.count == 1 {
                                self.viewImageVideoContainer.isHidden = false
                                self.heightConstImageVideoContainer.constant = 99.0
                                
                                if self.btnSell.isSelected {
                                    self.heighConstPrimePostContainer.constant = 0.0
                                }
                                else {
                                    self.heighConstPrimePostContainer.constant = 70.0
                                }
                                self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant + self.heighConstPrimePostContainer.constant
                            }
                            self.cvAttachedImageVideo.reloadData()
                            
                        default:
                            break
                        }
                    }
                })
            }
            
        }
        else{
            let image = info[UIImagePickerControllerEditedImage] as? UIImage
            let imageData : NSData = UIImagePNGRepresentation(image!)! as NSData
            
            let documentsPath = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let timestamp = NSDate().timeIntervalSince1970
            
            let strTimestamp:String = String(format:"%f", timestamp)
            // create a name for your image
            let fileURL = documentsPath.appendingPathComponent(strTimestamp + ".png")
            
            imageData.write(to: fileURL as URL, atomically: true)
            
            var dictImage : Dictionary<String, Any> = [:]
            
            dictImage["imagePath"] = fileURL.absoluteString
            dictImage["imageName"] = fileURL.lastPathComponent
            dictImage["type"] = "0" //Image
            arrAttachment.append(dictImage)
            
            if arrAttachment.count == 1 {
                
                viewImageVideoContainer.isHidden = false
                heightConstImageVideoContainer.constant = 99.0
                if self.btnSell.isSelected {
                    self.heighConstPrimePostContainer.constant = 0.0
                }
                else {
                    self.heighConstPrimePostContainer.constant = 70.0
                }
                self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant + self.heighConstPrimePostContainer.constant
            }
            
            cvAttachedImageVideo.reloadData()
        }
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker .dismiss(animated: true, completion: nil)
        print("picker cancel.")
    }
    
    func deleteFile(filePath:String) {
        guard FileManager.default.fileExists(atPath: filePath) else {
            return
        }
        
        do {
            try FileManager.default.removeItem(atPath: filePath)
        }catch{
            fatalError("Unable to delete file: \(error) : \(#function).")
        }
    }
    
    // MARK: - AttachmentCreatePostDelegate
    
    func removeAttachment(index: NSInteger) {
        arrAttachment.remove(at: index)
        if assets.count > index {
            self.assets.remove(at: index)
        }
        // arrUploadedAttachment.remove(at: index)
        
        cvAttachedImageVideo.reloadData()
        if arrAttachment.count == 0 {
            UIView .animate(withDuration: 0.5, animations: {
                self.heightConstImageVideoContainer.constant = 0.0
                self.heighConstPrimePostContainer.constant = 0.0
                
                self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant + self.heighConstPrimePostContainer.constant
                self.view.layoutIfNeeded()
                self.view.updateConstraints()
            }) { (Bool) in
                self.viewImageVideoContainer.isHidden = true
                self.btnImageType.isSelected = false
                self.btnVideoType.isSelected = false
            }
        }
    }
    
    // MARK: - LocationSearchViewDelegate
    
    func hideLocationSearchView() {
        viewLocationSearch?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewLocationSearch?.alpha = 0.0
        }) { (Bool) in
            self.viewLocationSearch?.isHidden = true
        }
    }
    
    func selectedLocation(dictLocation: Dictionary<String, Any>) {
        self.view.endEditing(true)
        hideLocationSearchView()
        dictSelectedLocation = dictLocation
        
        lblLocation.text = dictLocation["description"] as! String?
        viewLocationContainer.isHidden = false
        UIView .animate(withDuration: 0.5, animations: {
            self.heightConstLocationContainer.constant = 40.0
            self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant + self.heighConstPrimePostContainer.constant
            self.view.layoutIfNeeded()
            self.view.updateConstraintsIfNeeded()
        }) { (Bool) in
            
        }
    }
    
    // MARK: - Get image from selected asset and add in array
    func getImageFromAssetAndReloadArray() -> Void {
        
        if self.assets.count > 0 {
            // if arrAttachment
            if arrAttachment.count > 0 {
                arrAttachment.removeAll()
            }
            
            for (index, var asset) in self.assets.enumerated() {
                
                asset.fetchOriginalImageWithCompleteBlock({ (image, info) in
                    let imageData : NSData = UIImagePNGRepresentation(image!)! as NSData
                    let documentsPath = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                    let timestamp = NSDate().timeIntervalSince1970
                    
                    let strTimestamp:String = String(format:"%f", timestamp)
                    // create a name for your image
                    let fileURL = documentsPath.appendingPathComponent(strTimestamp + ".png")
                    
                    imageData.write(to: fileURL as URL, atomically: true)
                    
                    var dictImage : Dictionary<String, Any> = [:]
                    
                    dictImage["imagePath"] = fileURL.absoluteString
                    dictImage["imageName"] = fileURL.lastPathComponent
                    dictImage["type"] = "0" //Image
                    self.arrAttachment.append(dictImage)
                    
                    if index == self.assets.count - 1 {
                        if self.arrAttachment.count > 0 {
                            
                            if self.btnShare.isSelected {
                                self.heighConstPrimePostContainer.constant = 70.0
                            }else{
                                self.heighConstPrimePostContainer.constant = 0.0
                            }
                            
                            self.viewImageVideoContainer.isHidden = false
                            self.heightConstImageVideoContainer.constant = 99.0
                            self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant + self.heighConstPrimePostContainer.constant
                        }
                        self.cvAttachedImageVideo.reloadData()
                        self.currentAttachmentIndex = 0
                    }
                })
            }
        }
    }
    // MARK: - Custom methods // Looping for attachment images
    func uploadImageData() -> Void {
        var imageData = NSData()
        if currentAttachmentIndex < arrAttachment.count {
            let dictAttachment = arrAttachment[currentAttachmentIndex]
            
            let nsDocumentDirectory = FileManager.SearchPathDirectory.documentDirectory
            let nsUserDomainMask    = FileManager.SearchPathDomainMask.userDomainMask
            let paths               = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory, nsUserDomainMask, true)
            if let dirPath          = paths.first
            {
                let imageURL = URL(fileURLWithPath: dirPath).appendingPathComponent(dictAttachment["imageName"]! as! String)
                let image    = UIImage(contentsOfFile: imageURL.path)
                imageData  = UIImagePNGRepresentation(image!)! as NSData
                callWebserviceUploadPostImages(attachmentData: imageData)
            }
        }
        else{
            return
        }
    }
    
    // MARK: - Custom methods // Create Post Dictionary
    func createDictionaryPostData() -> Void {
        
        let dictParam = NSMutableDictionary()
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        if btnSell.isSelected {
            dictParam["forWhat"] = "0"
            if btnAuto.isSelected {
                dictParam["sellType"] = "Auto" //Auto,Auction
            }
            else{
                dictParam["sellType"] = "Auction" //Auto,Auction
            }
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy"
            let Date = dateFormatter.date(from: txtDate.text!)
            dateFormatter.dateFormat = "yyyy/MM/dd"
            let dateString = dateFormatter.string(from: Date!)
            
            dictParam["sellDate"] = dateString
            dictParam["sellAmount"] = txtPrice.text
        }
        else{
            dictParam["forWhat"] = "1"
            dictParam["sellType"] = ""
            dictParam["sellDate"] = ""
            dictParam["sellAmount"] = ""
        }
        dictParam["description"] = txtViewDetail.text
        dictParam["location"] = lblLocation.text
        if btnPrime.isSelected {
            dictParam["primePost"] = "yes"
        }else {
            dictParam["primePost"] = "no"
        }
        
        if btnAdultContent.isSelected {
            dictParam["adultContent"] = "yes"
        }else {
            dictParam["adultContent"] = "no"
        }
        
        dictParam["category"] = dictSelectedCatgeroy["con_id"]
        
        if arrUploadedAttachment.count > 0 {
            
            let dictAttachment = arrAttachment[0]
            if dictAttachment["type"] as! String == "0" {
                dictParam["typeOfUpload"] = "image" // image,audio,video
            }
            else{
                dictParam["typeOfUpload"] = "video" // image,audio,video
            }
            var sizeInByte : String = ""
            var filename : String = ""
            var filesize : String = ""
            var fileExt : String = ""
            
            for (index,var dict) in arrUploadedAttachment.enumerated() {
                if sizeInByte == "" {
                    sizeInByte =  (dict["size_in_byte"] as AnyObject).stringValue
                }
                else{
                    sizeInByte = sizeInByte + "," + (dict["size_in_byte"] as AnyObject).stringValue
                }
                
                if filename == "" {
                    filename = dict["fname"] as! String
                }
                else{
                    filename = String("\(filename),\(dict["fname"] as! String)")
                }
                
                if filesize == "" {
                    filesize = dict["size"] as! String
                }
                else{
                    filesize = String("\(filesize),\(dict["size"] as! String)")
                }
                
                if fileExt == "" {
                    fileExt = dict["ext"] as! String
                }
                else{
                    fileExt = String("\(fileExt),\(dict["ext"] as! String)")
                }
            }
            dictParam["sizeInByte"] = sizeInByte
            dictParam["fileName"] = filename
            dictParam["fileSize"] = filesize
            dictParam["extension"] = fileExt
        }else{
            
            dictParam["sizeInByte"] = ""
            dictParam["fileName"] = ""
            dictParam["fileSize"] = ""
            dictParam["extension"] = ""
            dictParam["typeOfUpload"] = "" // image,audio,video
        }
        dictPostData = dictParam
    }
    
    // MARK: - Custom methods // Content Specification UISetup
    func setContentSpecificationView() -> Void {
        viewContentSpecificationContainer.layer.cornerRadius = 5.0;
        
        if arrUploadedAttachment.count > 0 {
            var filesize : Double = 0
            var fileExt : String = ""
            
            for (index,var dict) in arrUploadedAttachment.enumerated() {
                if filesize == 0 {
                    filesize = (dict["size_in_byte"] as AnyObject).doubleValue
                }
                else{
                    filesize = filesize + (dict["size_in_byte"] as AnyObject).doubleValue
                }
                
                if fileExt == "" {
                    fileExt = dict["ext"] as! String
                }
                else{
                    fileExt = String("\(fileExt),\(dict["ext"] as! String)")
                }
            }
            lblFileFormat.text = fileExt
            if filesize > 0 {
                filesize = filesize / 1024
                if filesize > 1024 {
                    filesize = filesize / 1024
                    lblFileSize.text = String.localizedStringWithFormat("%0.2f MB", filesize)
                }else {
                    lblFileSize.text = String.localizedStringWithFormat("%0.2f KB", filesize)
                }
            }
            else{
                lblFileSize.text = ""
            }
        }
        
        let dictAttachment = arrAttachment[0]
        if dictAttachment["type"] as! String == "0" {
            lblFileType.text = "image" // image,audio,video
        }
        else{
            lblFileType.text = "video" // image,audio,video
        }
        
        if btnAdultContent.isSelected {
            lblAdultContent.text = "Yes"
        }
        else {
            lblAdultContent.text = "No"
        }
        
        lblMultiFile.text = ""
        if arrAttachment.count > 1 {
            lblMultiFile.text = "Yes"
        }
        else {
            lblMultiFile.text = "No"
        }
        
        if btnAuto.isSelected {
            lblSellOption.text = "Auto"
        }
        else {
            lblSellOption.text = "Auction"
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        let Date = dateFormatter.date(from: txtDate.text!)
        dateFormatter.dateFormat = "yyyy/MM/dd"
        let dateString = dateFormatter.string(from: Date!)
        
        lblSpecificationDate.text = dateString
        lblContentDescription.text = txtViewDetail.text
        
        var strLocation = lblLocation.text
        
        if strLocation?.characters.count == 0 || strLocation == "" {
            strLocation = " "
        }
        
        lblSpecificationLocation.text = strLocation
        
        btnSignTheEcontract.layer.cornerRadius = 5.0
        
        viewContenetSpecification?.alpha = 0.0
        viewContenetSpecification?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewContenetSpecification?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewContenetSpecification?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    // MARK: - Validation Methods
    func validateSharePostData() -> Bool {
        if trimString(string: (txtViewDetail.text)!) == "Description..." {
            showAlert(string: Constant.ALERT_MSG_POST_SHARE_DESCRIPTION_VALIDATE)
            return false
        }
        if dictSelectedCatgeroy.count == 0 {
            showAlert(string: Constant.ALERT_MSG_CATEGORY_SELECT_FOR_CREATE_POST)
            return false
        }
        return true
    }
    
    func validateSellPostData() -> Bool {
        if trimString(string: (txtPrice.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_POST_AMOUNT_VALIDATE)
            return false
        }
        if dictSelectedCatgeroy.count == 0 {
            showAlert(string: Constant.ALERT_MSG_CATEGORY_SELECT_FOR_CREATE_POST)
            return false
        }
        if trimString(string: (txtDate.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_POST_DATE_EMPTY_VALIDATE)
            return false
        }
        return true
    }
    
    
    // MARK: - Webservice methods
    func callWebserviceCreatePost(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            service.callJSONMethod(methodName: "createPost", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.showAlert(string: dict?["message"] as! String)
                        self.delegate?.reloadPostData()
                        self.navigationController!.popViewController(animated: true)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceUploadPostImages(attachmentData : NSData) -> Void {
        
        if isConnectedToNetwork() {
            if currentAttachmentIndex == 0
            {
                showSpinner(enableInteraction: false)
            }
            let dictParam = NSMutableDictionary()
            dictParam["attachment"] = "attachment"
            service.callJSONMethod(methodName: "uploadPostAttachment", imageData:attachmentData as NSData? , attachmentKey: "attachment",parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        
                        self.arrUploadedAttachment.append(dict!)
                        if self.currentAttachmentIndex == self.arrAttachment.count - 1 {
                            
                            if self.btnSell.isSelected {
                                self.createDictionaryPostData()
                                self.setContentSpecificationView()
                            }
                            else{
                                self.createDictionaryPostData()
                                self.callWebserviceCreatePost(dictParam: self.dictPostData)
                            }
                            self.hideSpinner()
                        }
                        else{
                            self.currentAttachmentIndex += 1
                            self.uploadImageData()
                        }
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                        self.currentAttachmentIndex = -1
                        if self.arrUploadedAttachment.count > 0 {
                            self.arrUploadedAttachment.removeAll()
                        }
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
                
                self.currentAttachmentIndex = -1
                if self.arrUploadedAttachment.count > 0 {
                    self.arrUploadedAttachment.removeAll()
                }
                
            }, onProgressResponse: { (_ progress:Float?) in
                print("uploading ==",progress ?? "")
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceUploadVideo() -> Void {
        
        if isConnectedToNetwork() {
            showSpinner(enableInteraction: false)
            let dictVideo = arrAttachment[0]
            let videoData = NSData.init(contentsOf: dictVideo["videoPath"] as! URL)
            
            let dictParam = NSMutableDictionary()
            dictParam["attachment"] = "attachment"
            service.callJSONMethod_Video(methodName: "uploadPostAttachment", imageData:videoData as NSData? , attachmentKey: "attachment",filename:dictVideo["videoName"] as! NSString,parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        if self.arrUploadedAttachment.count > 0 {
                            self.arrUploadedAttachment.removeAll()
                        }
                        self.arrUploadedAttachment.append(dict!)
                        if self.btnSell.isSelected {
                            self.createDictionaryPostData()
                            self.setContentSpecificationView()
                        }
                        else{
                            self.createDictionaryPostData()
                            self.callWebserviceCreatePost(dictParam: self.dictPostData)
                        }
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            }, onProgressResponse: { (_ progress:Float?) in
                print(progress ?? "")
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceEcommerceAgreement() -> Void {
        
        if self.isConnectedToNetwork() {
            
            self.showSpinner(enableInteraction: false)
            let dictParam = NSMutableDictionary()
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            dictParam["sellAmount"] = txtPrice.text
            
            if arrUploadedAttachment.count > 0 {
                
                let dictAttachment = arrAttachment[0]
                if dictAttachment["type"] as! String == "0" {
                    dictParam["typeOfUpload"] = "image" // image,audio,video
                }
                else{
                    dictParam["typeOfUpload"] = "video" // image,audio,video
                }
                var filesize : String = ""
                var fileExt : String = ""
                
                for (index,var dict) in arrUploadedAttachment.enumerated() {
                    
                    if filesize == "" {
                        //                        filesize = (dict["size"] as AnyObject).stringValue
                        filesize = dict["size"] as! String
                    }
                    else{
                        filesize = String("\(filesize),\(dict["size"] as! String)")
                    }
                    
                    if fileExt == "" {
                        fileExt = dict["ext"] as! String
                    }
                    else{
                        fileExt = String("\(fileExt),\(dict["ext"] as! String)")
                    }
                    
                    print(index)
                }
                
                dictParam["fileSize"] = filesize
                dictParam["extension"] = fileExt
            }
            service.callJSONMethod(methodName: "createEcontract", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        let vcEcommerce = self.storyboard?.instantiateViewController(withIdentifier: "EcommerceAgreementViewController") as! EcommerceAgreementViewController
                        vcEcommerce.dictCreatePostData = self.dictPostData
                        vcEcommerce.dictEcommerceAgreement = dict!
                        vcEcommerce.isFromCreatePost = true
                        self.navigationController?.pushViewController(vcEcommerce, animated: true)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if locations.last != nil {
            locationManager.stopUpdatingLocation()
            CLGeocoder().reverseGeocodeLocation(locations.last!, completionHandler: {(placemarks, error) -> Void in
                self.hideSpinner()
                if error != nil {
                    self.showAlert(string: "Reverse geocoder failed with error" + (error?.localizedDescription)!)
                    return
                }
                
                if (placemarks?.count)! > 0 {
                    let pm = placemarks?[0]
                    let arrFormatedAddress = pm?.addressDictionary?["FormattedAddressLines"] as! Array<String>
                    let strAddress = arrFormatedAddress.joined(separator: ",")
                    self.lblLocation.text = strAddress
                    self.viewLocationContainer.isHidden = false
                    UIView .animate(withDuration: 0.5, animations: {
                        self.heightConstLocationContainer.constant = 40.0
                        self.heightConstContentView.constant = 580 + self.heightConstImageVideoContainer.constant + self.heightConstLocationContainer.constant + self.heightConstViewAutoAuction.constant + self.heightConstViewDate.constant +  self.heighConstPrimePostContainer.constant
                        self.view.layoutIfNeeded()
                        self.view.updateConstraintsIfNeeded()
                    }) { (Bool) in
                        
                    }
                    
                    print(pm?.locality ?? "")
                }
                else {
                    print("Problem with the data received from geocoder")
                }
            })
            
        }
        else {
            self.hideSpinner()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        self.hideSpinner()
    }
}

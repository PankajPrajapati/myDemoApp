//
//  FollowersViewController.swift
//  Oriscene
//
//  Created by Parth on 29/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class FollowersViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    
    let service = WebService()
    var arrFollowers = [Dictionary<String,Any>]()
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var tblFollowers: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.callWebserviceForFollowers()
        // Do any additional setup after loading the view.
        setUpUI()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    
    // MARK: - Custom Method
    func setUpUI() -> Void {
        
        tblFollowers.register(FollowersTVCell.self, forCellReuseIdentifier: "FollowersTVCell")
        tblFollowers.register(UINib.init(nibName: "FollowersTVCell", bundle: nil), forCellReuseIdentifier: "FollowersTVCell")
        
        tblFollowers.reloadData()
    }
    
    // MARK: - UITableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrFollowers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "FollowersTVCell") as! FollowersTVCell
        //        cell.delegate = self
        cell.index = indexPath.row
        cell.lblUserName.text = "Jhon Doe"
        
        let dictMessage = arrFollowers[indexPath.row]
        let dictUserDataNew = dictMessage["user_data"]
        //        let dictLastMsg = dictMessage["last_msg"]
        
        if dictUserDataNew is Dictionary<String,Any> {
            cell.lblUserName.isHidden = false
            cell.imgUserPic.isHidden = false
            
            
            let dictUserData = dictUserDataNew as! Dictionary<String,Any>
            
            cell.lblUserName.text = (dictUserData["firstname"] as! String?)! + " " + (dictUserData["lastname"] as! String?)!
            if dictUserData.keys.contains("photo") {
                let strPhotoNameID = dictUserData["photo"]
                
                if strPhotoNameID is String {
                    let strPhotoName = strPhotoNameID as! String
                    if strPhotoName.characters.count != 0 {
                        let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                        let fileUrl = NSURL(string: strUrl)
                        
                        cell.imgUserPic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                            if error != nil {
                                print("Failed: \(error)")
                            } else {
                                print("Success")
                            }
                        }
                    }
                    else{
                        cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                    }
                }
                else{
                    cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        else{
            cell.lblUserName.isHidden = true
            cell.imgUserPic.isHidden = true
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 72.0
    }
    
    // MARK: - UITableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let dictFollowers = arrFollowers[indexPath.row];
        
        let vcUserProfile = self.storyboard?.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
        var dictPostDummy = Dictionary<String,Any>()
        var dictPostDetailIndiv = Dictionary<String,Any>()
        dictPostDetailIndiv["postuserdata"] = dictFollowers["user_data"]
        dictPostDetailIndiv["need_to_follow"] = dictFollowers["need_to_follow"]
        dictPostDummy["postdetailindiv"] = dictPostDetailIndiv
        vcUserProfile.dictUserPostData = dictPostDummy
        vcUserProfile.isfollowers = 1
        self.navigationController?.pushViewController(vcUserProfile, animated: true)
    }
    
    // MARK: - Webservice Call
    
    func callWebserviceForFollowers() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            dictParam["fromView"] = ""
            
            dictParam["otherUserId"] = ""
            dictParam["type"] = "my_followers"
            dictParam["postId"] = ""
            
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "followUser", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrFollowers = dict?["data"] as! [Dictionary<String,Any>]
                        self.tblFollowers.reloadData()
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

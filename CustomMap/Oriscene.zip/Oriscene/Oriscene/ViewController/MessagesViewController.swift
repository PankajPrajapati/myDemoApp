//
//  MessagesViewController.swift
//  Oriscene
//
//  Created by Parth on 12/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class MessagesViewController: BaseViewController , UITableViewDelegate, UITableViewDataSource, ChatViewDelegate {
    let service = WebService()
    
    var arrMessages = [Dictionary<String,Any>]()
    var isFromAppdelegate = false
    
    @IBOutlet var tblMessages: UITableView!
    @IBOutlet var viewHeader: UIView!
    @IBOutlet weak var lblNoMessage: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        tblMessages.register(MessageListTVCell.self, forCellReuseIdentifier: "MessageListTVCell")
        tblMessages.register(UINib.init(nibName: "MessageListTVCell", bundle: nil), forCellReuseIdentifier: "MessageListTVCell")
        self.callWebserviceGetMessages()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.lblNoMessage.isHidden = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - UITableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMessages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "MessageListTVCell") as! MessageListTVCell
        cell.index = indexPath.row
        let dictMessage = arrMessages[indexPath.row]
        let dictUserData = dictMessage["user_data"] as! Dictionary<String,Any>
        let dictLastMsg = dictMessage["last_msg"]
        
        let strusenickname = dictUserData["usenickname"] as! String
        if strusenickname == "1" {
            cell.lblUserName.text = dictUserData["reporter_name"] as? String
        }
        else{
            cell.lblUserName.text = (dictUserData["firstname"] as! String) + " " + (dictUserData["lastname"] as! String)
        }
        if dictUserData.keys.contains("photo") {
            let strPhotoName = dictUserData["photo"] as! String
            if strPhotoName.characters.count != 0 {
                let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                let fileUrl = NSURL(string: strUrl)
                
                cell.imgUserProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                    if error != nil {
                        print("Failed: \(error)")
                    } else {
                        print("Success")
                    }
                }
            }
            else{
                cell.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        else{
            cell.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
        }
        
        if dictLastMsg is Dictionary<String,Any> {
            
            let dictMessagesNew = dictLastMsg as! Dictionary<String,Any>
            cell.lblMessage.text = dictMessagesNew["message"] as? String
            if dictMessagesNew.keys.contains("posteddate") {
                cell.lblTime.text = convertStringToDate(strDate: dictMessagesNew["posteddate"] as! String)
            }
            else{
                cell.lblTime.text = "--"
            }
        }
        else{
            cell.lblMessage.text = "There is no message"
            cell.lblTime.text = "--"
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vcChatMsg = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        vcChatMsg.dictMainMessage = arrMessages[indexPath.row]
        vcChatMsg.indexOfMessage = indexPath.row
        vcChatMsg.delegate = self
        self.navigationController?.pushViewController(vcChatMsg, animated: true)
    }
    
    // MARK: - ChatView Delegate Method
    func replaceLastMessage(index : NSInteger, dictMessageData : Dictionary<String,Any>) -> Void {
        arrMessages[index] = dictMessageData
        let contentOffset = tblMessages.contentOffset
        tblMessages.reloadData()
        tblMessages.contentOffset = contentOffset
    }
    
    // MARK: - Webservice Call
    
    func callWebserviceGetMessages() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            if arrMessages.count <= 0 {
                self.showSpinner(enableInteraction: true)
            }
            service.callJSONMethod(methodName: "getMessage", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        let tempArray =  dict?["data"] as! [Dictionary<String,Any>]
                        
                        if self.arrMessages.count > 0 {
                            self.arrMessages.append(contentsOf: tempArray)
                        }else{
                            self.arrMessages = tempArray
                        }
                        if self.isFromAppdelegate {
                            self.arrMessages = tempArray
                            self.isFromAppdelegate = false
                        }
                        
                        self.tblMessages.reloadData()
                    }
                    else if dict?["status"] as! String == "0" {
                        self.lblNoMessage.isHidden = false
                        self.showAlert(string: dict?["message"] as! String)
                    }
                    else{
                        if self.arrMessages.count <= 0 {
                            self.showAlert(string: dict?["message"] as! String)
                        }
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

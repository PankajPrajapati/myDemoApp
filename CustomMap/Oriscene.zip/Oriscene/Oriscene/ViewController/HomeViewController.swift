//
//  HomeViewController.swift
//  Oriscene
//
//  Created by Parth on 10/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class HomeViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource, PostListingDelegate, PostCommentViewDelegate , UISearchBarDelegate, SharePostDelegate, CreatePostCategoryDelegate, BidPriceDelegate, AudioPlayViewDelegate, DocumentViewerViewDelegate, PostImageViewDelegate, PostDetailViewDelegate, UIScrollViewDelegate, PostDetailScreenDelegate, PostDescriptionEditViewDelegate, UserProfileDelegate, CreatePostDelegate {
    
    let service = WebService()
    var arrPost = [Dictionary<String,Any>]()
    var viewPostComments : PostCommentView? = nil
    var viewPostShare : PostShareView? = nil
    var viewBidPrice : BidPriceView? = nil
    var viewAudioPlay : AudioPlayView? = nil
    var viewDocumentViewer : DocumentViewerView? = nil
    
    var viewPostImage : PostImageView? = nil
    var viewPostDetail : PostDetailView? = nil
    var player : AVPlayer?
    var postCount = 0
    var isPagingAvailable = true
    var isSeachCompleted = false
    var isLoadingData = false
    var isSearch = false
    var viewForFooter : TableFooterView? = nil
    var viewDescriptionEdit : PostDescriptionEditView? = nil
    var currentPostType : NSInteger = -1
    var dictSelectedCatgeroy : Dictionary<String, String>?
    var arrSelectedCategoryForFilter = [Dictionary<String,String>]()
    
    // MARK: - Controll Outlet
    
    @IBOutlet var btnMenu: UIButton!
    @IBOutlet var btnCategory: UIButton!
    @IBOutlet var btnSearch: UIButton!
    @IBOutlet var tblPost: UITableView!
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var viewCreatePost: UIView!
    @IBOutlet var imgUserProfilePic: UIImageView!
    @IBOutlet var lblPostCaption: UILabel!
    @IBOutlet var btnCreatePost: UIButton!
    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet weak var heightViewCreatePost: NSLayoutConstraint!
    
    // MARK: - UIView Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupUI()
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            imgUserProfilePic.clipsToBounds = true
            imgUserProfilePic.contentMode = UIViewContentMode.redraw
            
            if dictUser.keys.contains("photo") {
                let strPhotoName = dictUser["photo"] as! String
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictUser["photo"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    imgUserProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        let notificationName = Notification.Name("commentNotification")
        // Do any additional setup after loading the view.
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleNotification), name: notificationName, object: nil)
    }
    func handleNotification() {
        print("RECEIVED ANY NOTIFICATION")
        callWebservicePostForHome()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if viewPostComments == nil {
            viewPostComments = PostCommentView.instanceFromNib() as? PostCommentView
            viewPostComments?.frame = UIScreen.main.bounds
            viewPostComments?.isHidden = true
            viewPostComments?.delegate = self
            viewPostComments?.alpha = 0.0
            self.view.addSubview(viewPostComments!)
        }
        
        if viewPostShare == nil {
            viewPostShare = PostShareView.instanceFromNib() as? PostShareView
            viewPostShare?.frame = UIScreen.main.bounds
            viewPostShare?.isHidden = true
            viewPostShare?.delegate = self
            viewPostShare?.alpha = 0.0
            self.view.addSubview(viewPostShare!)
        }
        
        if viewBidPrice == nil {
            viewBidPrice = BidPriceView.instanceFromNib() as? BidPriceView
            viewBidPrice?.frame = UIScreen.main.bounds
            viewBidPrice?.isHidden = true
            viewBidPrice?.delegate = self
            viewBidPrice?.alpha = 0.0
            self.view.addSubview(viewBidPrice!)
        }
        
        if viewAudioPlay == nil {
            viewAudioPlay = AudioPlayView.instanceFromNib() as? AudioPlayView
            viewAudioPlay?.frame = UIScreen.main.bounds
            viewAudioPlay?.isHidden = true
            viewAudioPlay?.delegate = self
            viewAudioPlay?.alpha = 0.0
            self.view.addSubview(viewAudioPlay!)
        }
        
        if viewDocumentViewer == nil {
            viewDocumentViewer = DocumentViewerView.instanceFromNib() as? DocumentViewerView
            viewDocumentViewer?.frame = UIScreen.main.bounds
            viewDocumentViewer?.isHidden = true
            viewDocumentViewer?.delegate = self
            viewDocumentViewer?.alpha = 0.0
            self.view.addSubview(viewDocumentViewer!)
        }
        
        if viewPostImage == nil {
            viewPostImage = PostImageView.instanceFromNib() as? PostImageView
            viewPostImage?.frame = UIScreen.main.bounds
            viewPostImage?.isHidden = true
            viewPostImage?.delegate = self
            viewPostImage?.alpha = 0.0
            self.view.addSubview(viewPostImage!)
        }
        
        if viewPostDetail == nil {
            viewPostDetail = PostDetailView.instanceFromNib() as? PostDetailView
            viewPostDetail?.frame = UIScreen.main.bounds
            viewPostDetail?.isHidden = true
            viewPostDetail?.delegate = self
            viewPostDetail?.alpha = 0.0
            self.view.addSubview(viewPostDetail!)
        }
        
        if viewDescriptionEdit == nil {
            viewDescriptionEdit = PostDescriptionEditView.instanceFromNib() as? PostDescriptionEditView
            viewDescriptionEdit?.frame = UIScreen.main.bounds
            viewDescriptionEdit?.isHidden = true
            viewDescriptionEdit?.delegate = self
            viewDescriptionEdit?.alpha = 0.0
            self.view.addSubview(viewDescriptionEdit!)
        }
        btnCategory.isUserInteractionEnabled = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        btnCategory.isUserInteractionEnabled = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    func setupUI() {
        
        searchBar.isHidden = true
        searchBar.tintColor = UIColor.white
        
        let view: UIView = self.searchBar.subviews[0]
        let subViewsArray = view.subviews
        
        for (_, subView) in subViewsArray.enumerated() {
            if subView is UITextField {
                subView.tintColor = UIColor.black
            }
        }
        
        tblPost.register(PostListTVCell.self, forCellReuseIdentifier: "PostListTVCell")
        tblPost.register(UINib.init(nibName: "PostListTVCell", bundle: nil), forCellReuseIdentifier: "PostListTVCell")
        
        //        self.view.layoutIfNeeded()
        imgUserProfilePic.layer.cornerRadius = imgUserProfilePic.frame.size.height/2.0
        imgUserProfilePic.layer.masksToBounds = true
        
        if currentPostType == CurrentSelectedPostType.BOTH.rawValue {
            callWebservicePostForHome()
        }
        else if currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
            callWebservicePostForSell()
        }
    }
    
    // MARK: - Action Method
    
    @IBAction func btnSearchAction(_ sender: AnyObject) {
        searchBar.isHidden = false
        searchBar.showsCancelButton = true
        heightViewCreatePost.constant = 0.0
        viewCreatePost.setNeedsUpdateConstraints()
        viewCreatePost.setNeedsLayout()
        searchBar.becomeFirstResponder()
    }
    @IBAction func btnCategoryAction(_ sender: AnyObject) {
        btnCategory.isUserInteractionEnabled = false
        let vcCatFirst = self.storyboard?.instantiateViewController(withIdentifier: "CategoryFirstViewController") as! CategoryFirstViewController
        vcCatFirst.isFromCreatePost = false
        vcCatFirst.isFromFilterPost = true
        vcCatFirst.delegate = self
        let userDefault = UserDefaults.standard.dictionaryRepresentation()
        if userDefault.keys.contains("filterArray") {
            arrSelectedCategoryForFilter = userDefault["filterArray"] as! [Dictionary<String,String>]
        }
        vcCatFirst.arrSelectedCategoryListForFilter = arrSelectedCategoryForFilter
        self.navigationController?.pushViewController(vcCatFirst, animated: true)
    }
    @IBAction func btnCreatePostAction(_ sender: AnyObject) {
        let vcCreatPost = self.storyboard?.instantiateViewController(withIdentifier: "CreatePostViewController") as! CreatePostViewController
        vcCreatPost.delegate = self
        self.navigationController?.pushViewController(vcCreatPost, animated: true)
    }
    
    // MARK: - UITableView Datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPost.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "PostListTVCell") as! PostListTVCell
        cell.delegate = self
        cell.index = indexPath.row
        cell.lblCategory.backgroundColor = getRandomColor(index: indexPath.row)
        cell.viewMoreContainer.isHidden = true
        
        let dictPost = arrPost[indexPath.row] as Dictionary<String,Any>
        cell.currentPostType = currentPostType
        cell.dictPostDtl = dictPost
        
        cell.arrPostAction = dictPost["arrPostAction"] as! [Dictionary<String, Any>]
        cell.cvPostAction.reloadData()
        
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictPostCategory = dictPostDtlIndividual["categoryindiv"] as! Dictionary<String,Any>
        let dictUserData = dictPostDtlIndividual["postuserdata"] as! Dictionary<String,Any>
        
        if dictUserData.keys.contains("photo") {
            
            let strStringNameId = dictUserData["photo"]
            if strStringNameId is String {
                let strPhotoName = strStringNameId as! String
                
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    cell.imgProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    cell.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
                }
            }else {
                cell.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
            
        }
        else{
            cell.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
        }
        
        cell.lblPostDetail.text = dictPostDtlIndividual["post_content"] as? String
        cell.lblOrgText.text = dictPostDtlIndividual["share_org_text"] as? String
        cell.lblShareText.text = dictPostDtlIndividual["share_text"] as? String
        
        if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
            let strOrgText = dictPostDtlIndividual["share_org_text"] as? String
            
            if strOrgText != nil {
                cell.lblSeperaterForDtlOrgText.isHidden = false
            }
            else{
                cell.lblSeperaterForDtlOrgText.isHidden = true
            }
            //New Change By Pankaj
            cell.arrMoreAction = dictPost["arrMoreAction"] as! [Dictionary<String, Any>]
            cell.btnMore.isHidden = false
            if dictPostDtlIndividual.keys.contains("need_to_follow") {
                cell.btnFollow.isHidden = false
            }else{
                cell.btnFollow.isHidden = true
            }
            if dictPostDtlIndividual.keys.contains("is_prime") {
                cell.btnPrimePost.isHidden = false
            }else{
                cell.btnPrimePost.isHidden = true
            }
            
            if dictPostDtlIndividual.keys.contains("is_prime") || dictPostDtlIndividual.keys.contains("need_to_follow") {
                cell.topSpaceLblUserName.constant = 2.0
            }else{
                cell.topSpaceLblUserName.constant = 15.0
            }
        }
        else{
            cell.lblSeperaterForDtlOrgText.isHidden = true
            cell.btnFollow.isHidden = true
            cell.btnPrimePost.isHidden = true
            cell.btnMore.isHidden = true
            cell.topSpaceLblUserName.constant = 15.0
        }
        
        cell.lblCategory.text = "" + (dictPostCategory["con_name"] as? String)! + "   "
        
        let strusenickname = dictUserData["usenickname"] as! String
        if strusenickname == "1" {
            cell.lblUserName.text = dictUserData["reporter_name"] as? String
        }
        else{
            cell.lblUserName.text = (dictUserData["firstname"] as! String) + " " + (dictUserData["lastname"] as! String)
        }
        cell.lblCategory.layer.cornerRadius = 3.0
        cell.lblCategory.layer.masksToBounds = true
        cell.viewBottomForSellPost.isHidden = true
        
        if dictPostDtlIndividual.keys.contains("cp_loc") {
            if (dictPostDtlIndividual["cp_loc"] as! String).characters.count != 0 {
                cell.lblLocation.text = dictPostDtlIndividual["cp_loc"] as? String
                cell.heightConstLocation.constant = 34.0
            }
            else{
                cell.lblLocation.text = ""
                cell.heightConstLocation.constant = 0.0
            }
        }
        else{
            cell.lblLocation.text = ""
            cell.heightConstLocation.constant = 0.0
        }
        
        if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_IMAGE {
            cell.imgVideoSnapshot.isHidden = true
            cell.cvPostImages.isHidden = false
            cell.imgTypeOfAttachment.isHidden = true
            cell.imgTypeOfAttachment.image = #imageLiteral(resourceName: "play_bt")
            cell.imgTypeOfAttachment.backgroundColor = UIColor.init(colorLiteralRed: 243.0/255.0, green: 247.0/255.0, blue: 250.0/255.0, alpha: 1.0)
            cell.arrPostImages = dictPostDtlIndividual["att_detail"] as! [Dictionary<String,Any>]
            cell.heightConstImageType.constant = 164.0
            cell.reloadImages()
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_VIDEO {
            
            cell.imgVideoSnapshot.contentMode = .redraw
            let arrAttachment = dictPostDtlIndividual["att_detail"] as! [Dictionary<String,Any>]
            if arrAttachment.count != 0 {
                
                DispatchQueue.global().async {
                    let dictAttachment = arrAttachment[0]
                    
                    var strBaseUrl = ""
                    if self.currentPostType == CurrentSelectedPostType.BOTH.rawValue || self.currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                        strBaseUrl = VIDEO_ATTACHMENT_BASE_URL
                    }
                    else if self.currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
                        strBaseUrl = SELL_VIDEO_ATTACHMENT_BASE_URL
                    }
                    
                    let strUrl = strBaseUrl + (dictAttachment["attachment_name"] as! String)
                    let sourceURL = URL(string: strUrl)
                    let asset = AVAsset(url: sourceURL!)
                    let imageGenerator = AVAssetImageGenerator(asset: asset)
                    let time = CMTimeMake(1, 1)
                    
                    do{
                        let imageRef = try imageGenerator.copyCGImage(at: time, actualTime: nil)
                        DispatchQueue.main.async {
                            cell.imgVideoSnapshot.image = UIImage(cgImage:imageRef)
                        }
                    }
                    catch{
                        
                    }
                    
                }
                
            }
            
            cell.imgVideoSnapshot.isHidden = false
            
            cell.cvPostImages.isHidden = true
            cell.imgTypeOfAttachment.isHidden = false
            cell.imgTypeOfAttachment.image = #imageLiteral(resourceName: "play_bt")
            cell.imgTypeOfAttachment.backgroundColor = UIColor.clear
            cell.arrPostImages = [Dictionary<String,Any>]()
            cell.heightConstImageType.constant = 164.0
            cell.reloadImages()
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_AUDIO {
            cell.imgVideoSnapshot.isHidden = true
            cell.cvPostImages.isHidden = true
            cell.imgTypeOfAttachment.isHidden = false
            cell.imgTypeOfAttachment.image = #imageLiteral(resourceName: "audio_img")
            cell.imgTypeOfAttachment.backgroundColor = UIColor.init(colorLiteralRed: 243.0/255.0, green: 247.0/255.0, blue: 250.0/255.0, alpha: 1.0)
            cell.heightConstImageType.constant = 164.0
            cell.arrPostImages = [Dictionary<String,Any>]()
            cell.reloadImages()
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_DOCUMENT {
            cell.imgVideoSnapshot.isHidden = true
            cell.cvPostImages.isHidden = true
            cell.imgTypeOfAttachment.isHidden = false
            cell.imgTypeOfAttachment.image = #imageLiteral(resourceName: "doc_img")
            cell.imgTypeOfAttachment.backgroundColor = UIColor.init(colorLiteralRed: 243.0/255.0, green: 247.0/255.0, blue: 250.0/255.0, alpha: 1.0)
            cell.heightConstImageType.constant = 164.0
            cell.arrPostImages = [Dictionary<String,Any>]()
            cell.reloadImages()
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_LOCATION {
            cell.heightConstImageType.constant = 0.0
            cell.arrPostImages = [Dictionary<String,Any>]()
            cell.reloadImages()
            cell.cvPostImages.isHidden = true
            cell.imgTypeOfAttachment.isHidden = true
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_YOUTUBE {
            
            
            //YouTube Video Link Redirect to video player
            
            var strPostContent = dictPostDtlIndividual["post_content"] as! String
            
            let detector = try! NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
            let matches = detector.matches(in: strPostContent , options: [], range: NSRange(location: 0, length: (strPostContent.utf16.count)))
            
            print(matches.count)
            if matches.count != 0 {
                let match = matches[0]
                let url = (strPostContent as NSString).substring(with: match.range)
                print(url)
                strPostContent = strPostContent.replacingOccurrences(of: url, with: "")
                cell.lblPostDetail.text = strPostContent
                let array = url.components(separatedBy: "?")
                if array.count != 0 {
                    var strYouTubeID = array[1]
                    strYouTubeID = strYouTubeID.replacingOccurrences(of: "v=", with: "")
                    let strUrl = "http://img.youtube.com/vi/" + strYouTubeID + "/0.jpg"
                    
                    let fileUrl = NSURL(string: strUrl)
                    
                    cell.imgVideoSnapshot.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    cell.imgVideoSnapshot.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                cell.imgVideoSnapshot.image = #imageLiteral(resourceName: "default_img")
            }
            
            
            cell.imgVideoSnapshot.isHidden = false
            cell.imgTypeOfAttachment.backgroundColor = UIColor.clear
            cell.cvPostImages.isHidden = true
            cell.imgTypeOfAttachment.isHidden = false
            cell.imgTypeOfAttachment.image = #imageLiteral(resourceName: "play_bt")
            cell.heightConstImageType.constant = 164.0
            cell.imgVideoSnapshot.layoutIfNeeded()
            cell.arrPostImages = [Dictionary<String,Any>]()
            cell.reloadImages()
        }
        else {
            cell.heightConstImageType.constant = 0.0
            cell.arrPostImages = [Dictionary<String,Any>]()
            cell.reloadImages()
            cell.cvPostImages.isHidden = true
            cell.imgTypeOfAttachment.isHidden = true
            cell.imgVideoSnapshot.isHidden = true
            cell.imgTypeOfAttachment.backgroundColor = UIColor.lightGray
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if currentPostType == CurrentSelectedPostType.BOTH.rawValue {
            let dictPost = arrPost[indexPath.row] as Dictionary<String,Any>
            let vcPostDetail = self.storyboard?.instantiateViewController(withIdentifier: "PostDetailViewController") as! PostDetailViewController
            vcPostDetail.currentPostType = currentPostType
            vcPostDetail.intCurrentRow = indexPath.row
            vcPostDetail.dictPostDetail = dictPost
            vcPostDetail.delegate = self
            self.navigationController?.pushViewController(vcPostDetail, animated: true)
        }
        else if currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
            
        }
    }
    
    // MARK: - PostListingDelegate
    
    func postLikeClicked(indexOfPost: NSInteger) {
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictParam = NSMutableDictionary()
        
        dictParam["pId"] = dictPost["p_id"]
        dictParam["postType"] = dictPost["post_type"]
        
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        dictParam["forWhat"] = "1"
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        callWebserviceForLikeUnlikeSharePost(dictParam: dictParam,indexOfObject: indexOfPost)
    }
    
    func postUnLikeClicked(indexOfPost: NSInteger) {
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictParam = NSMutableDictionary()
        
        dictParam["pId"] = dictPost["p_id"]
        dictParam["postType"] = dictPost["post_type"]
        
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        dictParam["forWhat"] = "2"
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        callWebserviceForLikeUnlikeSharePost(dictParam: dictParam,indexOfObject: indexOfPost)
    }
    
    func postViewClicked(indexOfPost: NSInteger) {
        
    }
    
    
    func postCommentClicked(indexOfPost: NSInteger) {
        viewDocumentViewer?.frame = UIScreen.main.bounds
        viewPostComments?.intSelectedRowForComment = -1
        viewPostComments?.intSelectedSectionForComment = -1
        viewPostComments?.isHidden = false
        viewPostComments?.index = indexOfPost
        viewPostComments?.dictPostData = arrPost[indexOfPost] as Dictionary<String,Any>
        viewPostComments?.reloadComments()
        
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostComments?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostComments?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    func postReplyClicked(indexOfPost: NSInteger) {
        self.viewPostShare?.txtMessage.text = ""
        self.viewPostShare?.setUserData()
        self.viewPostShare?.index = indexOfPost
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        viewPostShare?.lblPostDetail.text = dictPostDtlIndividual["post_content"] as? String
        
        self.viewPostShare?.alpha = 0.0
        viewPostShare?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostShare?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostShare?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    func postFollowClicked(indexOfPost: NSInteger) {
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictUserData = (dictPostDtlIndividual["postuserdata"] as? Dictionary<String,Any>)!
        
        let dictParam = NSMutableDictionary()
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        dictParam["encPostId"] = dictPostDtlIndividual["enc_posted_by"] as! String
        dictParam["fromView"] = "0"
        dictParam["type"] = "follow"
        dictParam["otherUserId"] = dictUserData["reporter_id"] as! String
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        callWebserviceForFollowUser(dictParam: dictParam)
    }
    
    func postDeleteClicked(indexOfPost: NSInteger) {
        
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let alert:UIAlertController=UIAlertController(title: Constant.APP_NAME, message: Constant.ALERT_MSG_CONFIRM_TO_DELETE_POST, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = dictPost["share_id"] as! String;
            dictParam["type"] = dictPostDtlIndividual["post_type"] as! String
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            self.callWebserviceDeletePost(dictParam: dictParam,andIndexOfPost: indexOfPost)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
        }
        // Add the actions
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func openUserProfileScreen(indexOfPost: NSInteger) {
        let vcUserProfile = self.storyboard?.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
        vcUserProfile.delegate = self
        vcUserProfile.dictUserPostData = self.arrPost[indexOfPost]
        self.navigationController?.pushViewController(vcUserProfile, animated: true)
    }
    
    func postEAClicked(indexOfPost: NSInteger) {
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        let vcEcommerce = self.storyboard?.instantiateViewController(withIdentifier: "EcommerceAgreementViewController") as! EcommerceAgreementViewController
        vcEcommerce.dictPostDtl = dictPost
        self.navigationController?.pushViewController(vcEcommerce, animated: true)
    }
    
    func postChatClicked(indexOfPost: NSInteger) {
        let vcChatMsg = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictUserData = dictPostDtlIndividual["postuserdata"] as! Dictionary<String,Any>
        vcChatMsg.dictOtherUser = dictUserData
        self.navigationController?.pushViewController(vcChatMsg, animated: true)
    }
    
    func postBidClicked(indexOfPost: NSInteger) {
        
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        
        viewBidPrice?.index = indexOfPost
        viewBidPrice?.dictBidDtl = dictPostDtlIndividual
        
        if dictPostDtlIndividual.keys.contains("bid_price") {
            viewBidPrice?.txtPrice.text = ""
            viewBidPrice?.lblTitle.text = "Place Bid"
            viewBidPrice?.btnPlaceBid.setTitle("PLACE BID", for: .normal)
        }
        else{
            viewBidPrice?.txtPrice.text = dictPostDtlIndividual["amount"] as! String?
            viewBidPrice?.lblTitle.text = "Edit Bid"
            viewBidPrice?.btnPlaceBid.setTitle("EDIT BID", for: .normal)
        }
        
        viewBidPrice?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewBidPrice?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewBidPrice?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    func postViewMoreClicked(indexOfPost: NSInteger) {
        
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictViewMoredtl = dictPostDtlIndividual["view_more_detail"] as! Dictionary<String,Any>
        
        viewPostDetail?.lblCapturedOn.text = dictViewMoredtl["capture"] as? String
        viewPostDetail?.lblFileType.text = dictViewMoredtl["file_type"] as? String
        viewPostDetail?.lblFileSize.text = dictViewMoredtl["file_size"] as? String
        viewPostDetail?.lblFileFormat.text = dictViewMoredtl["file_format"] as? String
        viewPostDetail?.lblMultiFiles.text = dictViewMoredtl["multi_file"] as? String
        viewPostDetail?.lblPrice.text = "$ " + (dictViewMoredtl["price"] as? String)!
        viewPostDetail?.lblAudienceRestriction.text = dictViewMoredtl["audience_res"] as? String
        
        viewPostDetail?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostDetail?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostDetail?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    func openPostDetail(indexOfPost: NSInteger) {
        
        self.viewPostImage?.alpha = 0.0
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        let dictPostdetailindiv = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        viewPostImage?.currentPostType = currentPostType
        viewPostImage?.isHidden = false
        viewPostImage?.arrAttDetail = dictPostdetailindiv["att_detail"] as! [Dictionary<String,Any>]
        
        viewPostImage?.cvPostImageList.reloadData()
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostImage?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostImage?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    func openPostAttachment(indexOfPost: NSInteger) {
        
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_IMAGE {
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_VIDEO {
            
            var strBaseUrl = ""
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                strBaseUrl = VIDEO_ATTACHMENT_BASE_URL
            }
            else if currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
                strBaseUrl = SELL_VIDEO_ATTACHMENT_BASE_URL
            }
            
            let arrAttachment = dictPostDtlIndividual["att_detail"] as! [Dictionary<String,Any>]
            if arrAttachment.count != 0 {
                let dictAttachment = arrAttachment[0]
                let strUrl = strBaseUrl + (dictAttachment["attachment_name"] as! String)
                
                let url = NSURL(string: strUrl)!
                
                self.showSpinner(enableInteraction: false)
                
                DispatchQueue.global().async {
                    HttpDownloader.loadFileSync(url: url, completion: { (path, error) in
                        
                        DispatchQueue.main.async {
                            self.hideSpinner()
                            if (error == nil) {
                                
                                if path != "" {
                                    //                            let urlLocal = NSURL(fileURLWithPath: path)
                                    self.playVideo(videoUrl: path)
                                }
                            }
                        }
                    })
                }
                
                //                playVideo(videoUrl: strUrl)
            }
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_AUDIO {
            self.viewAudioPlay?.frame = UIScreen.main.bounds
            self.viewAudioPlay?.dictPostDetail = dictPostDtlIndividual
            self.viewAudioPlay?.lblTitle.text = dictPostDtlIndividual["post_content"] as? String
            self.viewAudioPlay?.currentPostType = currentPostType
            viewAudioPlay?.isHidden = false
            UIView.animate(withDuration: 0.0, animations: {() -> Void in
                self.viewAudioPlay?.alpha = 0.0
            }, completion: {(_ finished: Bool) -> Void in
                UIView.animate(withDuration: 0.3, animations: {() -> Void in
                    self.viewAudioPlay?.alpha = 1.0
                }, completion: { _ in })
            })
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_DOCUMENT {
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue {
                let arrAttachment = dictPostDtlIndividual["att_detail"] as! [Dictionary<String,Any>]
                if arrAttachment.count != 0 {
                    let dictAttachment = arrAttachment[0]
                    let strUrl = DOCUMENT_ATTACHMENT_BASE_URL + (dictAttachment["attachment_name"] as! String)
                    let url = NSURL(string: strUrl)!
                    
                    self.showSpinner(enableInteraction: true)
                    
                    DispatchQueue.global().async {
                        HttpDownloader.loadFileSync(url: url, completion: { (path, error) in
                            
                            DispatchQueue.main.async {
                                self.hideSpinner()
                                if (error == nil) {
                                    
                                    if path != "" {
                                        let urlLocal = NSURL(fileURLWithPath: path)
                                        self.viewDocumentViewer?.frame = UIScreen.main.bounds
                                        self.viewDocumentViewer?.webView.loadRequest(URLRequest(url: urlLocal as URL))
                                        self.viewDocumentViewer?.isHidden = false
                                        UIView.animate(withDuration: 0.0, animations: {() -> Void in
                                            self.viewDocumentViewer?.alpha = 0.0
                                        }, completion: {(_ finished: Bool) -> Void in
                                            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                                                self.viewDocumentViewer?.alpha = 1.0
                                            }, completion: { _ in })
                                        })
                                    }
                                }
                            }
                        })
                    }
                }
            }
            else if currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
                
            }
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_LOCATION {
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_YOUTUBE {
            //YouTube Video Link Redirect to video player
            
            let strPostContent = dictPostDtlIndividual["post_content"]
            
            let detector = try! NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
            let matches = detector.matches(in: strPostContent! as! String, options: [], range: NSRange(location: 0, length: ((strPostContent as! String).utf16.count)))
            if matches.count != 0 {
                let match = matches[0]
                let url = (strPostContent as! NSString).substring(with: match.range)
                let array = url.components(separatedBy: "?")
                if array.count != 0 {
                    var strYouTubeID = array[1]
                    strYouTubeID = strYouTubeID.replacingOccurrences(of: "v=", with: "")
                    
                    let videoPlayVC = self.storyboard?.instantiateViewController(withIdentifier: "VideoPlayerViewController") as! VideoPlayerViewController
                    //                    videoPlayVC.strVideoLink = "ruMTxHFf9OI"
                    videoPlayVC.strVideoLink = strYouTubeID as NSString?
                    self.navigationController?.pushViewController(videoPlayVC, animated: true)
                }
            }
        }
        else {
            
        }
    }
    
    func postDescriptionEditClicked(indexOfPost: NSInteger) -> Void {
        self.viewDescriptionEdit?.alpha = 0.0
        
        viewDescriptionEdit?.isHidden = false
        viewDescriptionEdit?.dictPostData = arrPost[indexOfPost]
        viewDescriptionEdit?.displayDescription()
        viewDescriptionEdit?.index = indexOfPost
        
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewDescriptionEdit?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewDescriptionEdit?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    // MARK: - BidPriceDelegate
    
    func hideBidPriceView() {
        self.view.endEditing(true)
        
        viewBidPrice?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewBidPrice?.alpha = 0.0
        }) { (Bool) in
            self.viewBidPrice?.isHidden = true
        }
    }
    func insertUpdateBidPriceClick(strAmount: String, indexOfObject: NSInteger) {
        let dictPost = arrPost[indexOfObject] as Dictionary<String,Any>
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        if dictPostDtlIndividual.keys.contains("bid_price") {
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = dictPostDtlIndividual["post_id"] as! String;
            dictParam["price"] = strAmount
            self.callWebserviceBidPost(dictParam: dictParam, andIndexOfPost: indexOfObject)
        }
        else{
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = dictPostDtlIndividual["post_id"] as! String;
            dictParam["bidId"] = dictPostDtlIndividual["bid_id"] as! String;
            dictParam["amount"] = strAmount
            self.callWebserviceEditBidPost(dictParam: dictParam, andIndexOfPost: indexOfObject)
        }
    }
    // MARK: - PostCommentViewDelegate
    
    func btnCloseCommentClicked() {
        self.view.endEditing(true)
        
        viewPostComments?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostComments?.alpha = 0.0
        }) { (Bool) in
            self.viewPostComments?.isHidden = true
        }
        
    }
    //To reload Updated Comment Call this insted of btnCloseCommentClicked
    func btnCloseCommentClickedWithData(index: NSInteger,dictComment : Dictionary<String,Any>) -> Void{
        
        self.view.endEditing(true)
        arrPost[index] = dictComment
        let indexPath = IndexPath.init(row: index, section: 0) as IndexPath
        tblPost.reloadRows(at: [indexPath], with:.none)
        
        viewPostComments?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostComments?.alpha = 0.0
        }) { (Bool) in
            self.viewPostComments?.isHidden = true
        }
    }
    
    // MARK: - SEARCHBAR DELEGATE METHODS -
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.isHidden = true
        isSearch = false
        searchBar.text = ""
        heightViewCreatePost.constant = 70.0
        viewCreatePost.setNeedsUpdateConstraints()
        viewCreatePost.setNeedsLayout()
        
        //call fresh webservice only if the user has search anything and post array is changed otherwise no need to change
        if isSeachCompleted {
            arrPost.removeAll()
            tblPost.reloadData()
            
            isPagingAvailable = true
            isSeachCompleted = false
            postCount = 0
            
            if currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue  ||  currentPostType == CurrentSelectedPostType.BOTH.rawValue {
                callWebservicePostForHome()
            }
            else if currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
                callWebservicePostForSell()
            }
        }
        self.perform(#selector(self.resignSearchBar), with: nil, afterDelay: 0.05)
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        isPagingAvailable = true
        postCount = 0
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        //call webservice
        isSearch = true
        isSeachCompleted = true
        isPagingAvailable = true
        postCount = 0
        arrPost.removeAll()
        tblPost.reloadData()
        if currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue || currentPostType == CurrentSelectedPostType.BOTH.rawValue {
            callWebservicePostForHome()
        }
        else{
            callWebservicePostForSell()
        }
        self.perform(#selector(self.resignSearchBar), with: nil, afterDelay: 0.05)
    }
    
    func resignSearchBar() {
        self.searchBar.resignFirstResponder()
    }
    
    // MARK: - SharePostDelegate
    
    func hideSharePostView() {
        self.view.endEditing(true)
        
        viewPostShare?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostShare?.alpha = 0.0
        }) { (Bool) in
            self.viewPostShare?.isHidden = true
        }
    }
    
    func sharePostClicked(strDescription: String, indexOfObject: NSInteger) {
        self.hideSharePostView()
        let dictPost = arrPost[indexOfObject] as Dictionary<String,Any>
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictParam = NSMutableDictionary()
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        dictParam["desc"] = strDescription
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        callWebserviceSharedPost(dictParam: dictParam)
    }
    // MARK: - AudioPlayViewDelegate
    
    func hideAudioPlayView() {
        viewAudioPlay?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewAudioPlay?.alpha = 0.0
        }) { (Bool) in
            self.viewAudioPlay?.isHidden = true
        }
    }
    
    func showSpinnerCallBack() {
        self.showSpinner(enableInteraction: false)
    }
    
    func hideSpinnerCallBack() {
        self.hideSpinner()
    }
    
    // MARK: - DocumentViewerViewDelegate
    
    func hideDocumentViewerView() {
        viewDocumentViewer?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewDocumentViewer?.alpha = 0.0
        }) { (Bool) in
            self.viewDocumentViewer?.isHidden = true
        }
    }
    
    func documentWebViewLoadFinish() {
        self.hideSpinner()
    }
    
    // MARK: - PostImageViewDelegate
    func hidePostImageView() -> Void {
        
        viewPostImage?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostImage?.alpha = 0.0
        }) { (Bool) in
            self.viewPostImage?.isHidden = true
        }
    }
    
    // MARK: - PostDetailViewDelegate
    func hidePostDetailView() -> Void {
        self.view.endEditing(true)
        
        viewPostDetail?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostDetail?.alpha = 0.0
        }) { (Bool) in
            self.viewPostDetail?.isHidden = true
        }
    }
    
    // MARK: - PostDescriptionEditViewDelegate
    func hideDescriptionEditView() -> Void {
        self.view.endEditing(true)
        
        viewDescriptionEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewDescriptionEdit?.alpha = 0.0
        }) { (Bool) in
            self.viewDescriptionEdit?.isHidden = true
        }
    }
    
    func savePostDescriptionEditView(indexOfPost : NSInteger, dictComment : Dictionary<String,Any>) -> Void {
        self.arrPost[indexOfPost] = dictComment
        self.tblPost.reloadRows(at: [IndexPath.init(row: indexOfPost , section: 0)], with: .none)
        viewDescriptionEdit?.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.viewDescriptionEdit?.alpha = 0.0
        }) { (Bool) in
            self.viewDescriptionEdit?.isHidden = true
        }
        
        self.reloadPostData()
    }
    
    
    // MARK: - CreatePostCategoryDelegate
    
    func selectedCategoryForPost(dictCategory: Dictionary<String, String>) {
        dictSelectedCatgeroy = dictCategory
        print(dictCategory["categoryName"] ?? "")
    }
    
    func selectedCategoryForFilterPost(arrCategory: [Dictionary<String, String>]) {
        UserDefaults.standard.setValue(arrCategory, forKey: "filterArray")
        UserDefaults.standard.synchronize()
        arrSelectedCategoryForFilter = arrCategory
        if currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue || currentPostType == CurrentSelectedPostType.BOTH.rawValue {
            self.arrPost = [Dictionary<String,Any>]()
            self.tblPost.reloadData()
            self.isPagingAvailable = true
            self.postCount = 0
            callWebservicePostForHome()
        }
        else{
            self.arrPost = [Dictionary<String,Any>]()
            self.tblPost.reloadData()
            self.isPagingAvailable = true
            self.postCount = 0
            callWebservicePostForSell()
        }
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent //or default
    }
    
    // MARK: - AVPlayer Methods
    func playVideo(videoUrl : String)->Void{
        
        let videoURL = NSURL(fileURLWithPath: videoUrl)
        player = AVPlayer(url: videoURL as URL)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if (keyPath == "status") {
            if let currentItem = self.player?.currentItem {
                let status = currentItem.status
                if (status == .readyToPlay) {
                    
                }
            }
        }
    }
    
    // MARK: - Webservice Call
    
    func callWebservicePostForHome() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            dictParam["postType"] = "share"
            if isSearch {
                dictParam["searchKey"] = searchBar.text
            } else{
                dictParam["searchKey"] = ""
            }
            var strCatID = ""
            if userDefault.keys.contains("filterArray") {
                arrSelectedCategoryForFilter = userDefault["filterArray"] as! [Dictionary<String,String>]
            }
            
            for (_, dict) in arrSelectedCategoryForFilter.enumerated() {
                if strCatID == "" {
                    strCatID = dict["con_id"]!
                }
                else{
                    strCatID = strCatID + "," + dict["con_id"]!
                }
            }
            
            dictParam["cateId"] = strCatID
            dictParam["postLimit"] = String(postCount)
            
            if arrPost.count <= 0 {
                self.showSpinner(enableInteraction: true)
            }
            service.callJSONMethod(methodName: "getPost", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                self.isLoadingData = false
                self.tblPost.tableFooterView = UIView()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        let tempArray =  dict?["data"] as! [Dictionary<String,Any>]
                        
                        if self.arrPost.count > 0 {
                            self.arrPost.append(contentsOf: tempArray)
                        }else{
                            self.arrPost = tempArray
                        }
                        if tempArray.count >= 10 {
                            self.isPagingAvailable = true
                        }else{
                            self.isPagingAvailable = false
                        }
                        
                        self.postCount += tempArray.count
                        self.filterPostarray()
                        self.tblPost.reloadData()
                    }
                    else if dict?["status"] as! String == "0" {
                        self.isPagingAvailable = false
                        self.showAlert(string: dict?["message"] as! String)
                    }
                    else{
                        self.isPagingAvailable = false
                        if self.arrPost.count <= 0 {
                            self.showAlert(string: dict?["message"] as! String)
                        }
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func filterPostarray() -> Void {
        for (index, var dictPostAction) in arrPost.enumerated() {
            var arr = [Dictionary<String, Any>]()
            var arrMoreAction = [Dictionary<String, Any>]()
            
            let dictData = dictPostAction["postdetailindiv"]as! Dictionary<String,Any>
            if dictData.keys.contains("need_to_call_agr_dis") {
                
                if dictData.keys.contains("agree_count") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "like_icon_sel"
                    dictTemp["img_icon_unsel"] = "like_icon"
                    dictTemp["agree_count"] = dictData["agree_count"]
                    dictTemp["postActionType"] = PostActionTypeSHARE.LIKE_POST.rawValue
                    arr.append(dictTemp)
                }
                if dictData.keys.contains("dis_agree_count") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "unlike_icon_sel"
                    dictTemp["img_icon_unsel"] = "unlike_icon"
                    dictTemp["dis_agree_count"] = dictData["dis_agree_count"]
                    dictTemp["postActionType"] = PostActionTypeSHARE.DISLIKE_POST.rawValue
                    arr.append(dictTemp)
                }
            }
            
            if dictData.keys.contains("view_count") {
                var  dictTemp = Dictionary<String, Any>()
                dictTemp["img_icon_sel"] = "view_icon_sel"
                dictTemp["img_icon_unsel"] = "view_icon"
                dictTemp["view_count"] = dictData["view_count"]
                dictTemp["postActionType"] = PostActionTypeSHARE.VIEW_POST.rawValue
                arr.append(dictTemp)
            }
            if dictData.keys.contains("comment_count") {
                var  dictTemp = Dictionary<String, Any>()
                dictTemp["img_icon_sel"] = "comm_icon_sel"
                dictTemp["img_icon_unsel"] = "comm_icon_sel"
                dictTemp["comment_count"] = dictData["comment_count"]
                dictTemp["postActionType"] = PostActionTypeSHARE.COMMENT_POST.rawValue
                arr.append(dictTemp)
            }
            
            var  dictTempShare = Dictionary<String, Any>()
            dictTempShare["img_icon"] = "more_share_icon"
            dictTempShare["share"] = "share"
            dictTempShare["moreActionType"] = PostMoreActionTypeSHARE.SHARE_POST.rawValue
            arrMoreAction.append(dictTempShare)
            
            if dictData.keys.contains("need_to_dlt") {
                var  dictEdit = Dictionary<String, Any>()
                dictEdit["img_icon"] = "more_edit_icon"
                dictEdit["need_to_edt"] = dictData["need_to_dlt"]
                dictEdit["moreActionType"] = PostMoreActionTypeSHARE.EDIT_POST.rawValue
                arrMoreAction.append(dictEdit)
                
                var  dictTemp = Dictionary<String, Any>()
                dictTemp["img_icon"] = "more_delete_icon"
                dictTemp["need_to_dlt"] = dictData["need_to_dlt"]
                dictTemp["moreActionType"] = PostMoreActionTypeSHARE.DELETE_POST.rawValue
                arrMoreAction.append(dictTemp)
                
            }
            dictPostAction["arrPostAction"] = arr
            dictPostAction["arrMoreAction"] = arrMoreAction
            
            arrPost[index] = dictPostAction
        }
    }
    
    
    func callWebservicePostForSell() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            dictParam["postType"] = "sell"
            
            if isSearch {
                dictParam["searchKey"] = searchBar.text
            } else{
                dictParam["searchKey"] = ""
            }
            var strCatID = ""
            
            if userDefault.keys.contains("filterArray") {
                arrSelectedCategoryForFilter = userDefault["filterArray"] as! [Dictionary<String,String>]
            }
            
            for (_, dict) in arrSelectedCategoryForFilter.enumerated() {
                if strCatID == "" {
                    strCatID = dict["con_id"]!
                }
                else{
                    strCatID = strCatID + "," + dict["con_id"]!
                }
            }
            
            dictParam["cateId"] = strCatID
            dictParam["postLimit"] = String(postCount)
            
            if arrPost.count <= 0 {
                self.showSpinner(enableInteraction: true)
            }
            service.callJSONMethod(methodName: "getPost", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                self.isLoadingData = false
                self.tblPost.tableFooterView = UIView()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        let tempArray = dict?["data"] as! [Dictionary<String,Any>]
                        
                        if self.arrPost.count > 0 {
                            self.arrPost.append(contentsOf: tempArray)
                        }else{
                            self.arrPost = tempArray
                        }
                        
                        if tempArray.count >= 10 {
                            self.isPagingAvailable = true
                        }else{
                            self.isPagingAvailable = false
                        }
                        
                        self.postCount += tempArray.count
                        self.filterPostarrayForSell()
                        self.tblPost.reloadData()
                    }
                    else{
                        self.isPagingAvailable = false
                        if self.arrPost.count <= 0 {
                            self.showAlert(string: dict?["message"] as! String)
                        }
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func filterPostarrayForSell() -> Void {
        
        for (index, var dictPostAction) in arrPost.enumerated() {
            var arr = [Dictionary<String, Any>]()
            
            let dictData = dictPostAction["postdetailindiv"]as! Dictionary<String,Any>
            var strSold = ""
            if dictData.keys.contains("sold") {
                strSold = dictData["sold"] as! String
            }
            
            if (strSold == "1") {
                var  dictTemp = Dictionary<String, Any>()
                dictTemp["img_icon_sel"] = "ea_icon_sel"
                dictTemp["img_icon_unsel"] = "ea_icon"
                dictTemp["postActionType"] = PostActionTypeSELL.SOLD_POST.rawValue
                arr.append(dictTemp)
            }
            else{
                if dictData.keys.contains("sold_url") {
                    
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "ea_icon_sel"
                    dictTemp["img_icon_unsel"] = "ea_icon"
                    dictTemp["postActionType"] = PostActionTypeSELL.EA_POST.rawValue
                    arr.append(dictTemp)
                    
                }
                
                if dictData.keys.contains("need_to_msg") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "chat_icon_sel"
                    dictTemp["img_icon_unsel"] = "chat_icon"
                    dictTemp["postActionType"] = PostActionTypeSELL.COMMENT_POST.rawValue
                    arr.append(dictTemp)
                }
                if dictData.keys.contains("bid_price") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "price_icon_sel_Home"
                    dictTemp["img_icon_unsel"] = "price_icon_Home"
                    dictTemp["postActionType"] = PostActionTypeSELL.BID_POST.rawValue
                    arr.append(dictTemp)
                }
                
                if dictData.keys.contains("edit_bid") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "price_icon_sel_Home"
                    dictTemp["img_icon_unsel"] = "price_icon_Home"
                    dictTemp["postActionType"] = PostActionTypeSELL.EDIT_BID_POST.rawValue
                    arr.append(dictTemp)
                }
                
                if dictData.keys.contains("view_more_detail") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "more_icon"
                    dictTemp["img_icon_unsel"] = "more_icon"
                    dictTemp["need_to_follow"] = dictData["need_to_follow"]
                    dictTemp["postActionType"] = PostActionTypeSELL.VIEW_MORE_DETAIL_POST.rawValue
                    arr.append(dictTemp)
                }
                
                if dictData.keys.contains("need_to_dlt") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon"] = "delete_icon"
                    dictTemp["need_to_dlt"] = dictData["need_to_dlt"]
                    dictTemp["postActionType"] = PostActionTypeSELL.DELETE_POST.rawValue
                    arr.append(dictTemp)
                }
            }
            dictPostAction["arrPostAction"] = arr
            arrPost[index] = dictPostAction
        }
    }
    
    func callWebserviceForLikeUnlikeSharePost(dictParam : NSMutableDictionary, indexOfObject : NSInteger) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "likeDislike", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        var dictPost = self.arrPost[indexOfObject] as Dictionary<String,Any>
                        let dictPostDetailIndiv = dict?["data"] as! Dictionary<String,Any>
                        dictPost["postdetailindiv"] = dictPostDetailIndiv
                        self.arrPost[indexOfObject] = dictPost
                        //                        self.tblPost.reloadData()
                        self.updateCount(dictPostIndi: dictPostDetailIndiv)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceForFollowUser(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "followUser", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.reloadPostData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceSharedPost(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertSharedData", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.showAlert(string: dict?["message"] as! String)
                        var arr = [Dictionary<String, Any>]()
                        var arrMoreAction = [Dictionary<String, Any>]()
                        
                        let arrTmp = dict?["data"] as! [Dictionary<String,Any>]
                        
                        if arrTmp.count != 0 {
                            var dictPostAction = arrTmp[0]
                            let dictData = dictPostAction["postdetailindiv"]as! Dictionary<String,Any>
                            if dictData.keys.contains("need_to_call_agr_dis") {
                                
                                if dictData.keys.contains("agree_count") {
                                    var  dictTemp = Dictionary<String, Any>()
                                    dictTemp["img_icon_sel"] = "like_icon_sel"
                                    dictTemp["img_icon_unsel"] = "like_icon"
                                    dictTemp["agree_count"] = dictData["agree_count"]
                                    dictTemp["postActionType"] = PostActionTypeSHARE.LIKE_POST.rawValue
                                    arr.append(dictTemp)
                                }
                                if dictData.keys.contains("dis_agree_count") {
                                    var  dictTemp = Dictionary<String, Any>()
                                    dictTemp["img_icon_sel"] = "unlike_icon_sel"
                                    dictTemp["img_icon_unsel"] = "unlike_icon"
                                    dictTemp["dis_agree_count"] = dictData["dis_agree_count"]
                                    dictTemp["postActionType"] = PostActionTypeSHARE.DISLIKE_POST.rawValue
                                    arr.append(dictTemp)
                                }
                            }
                            
                            if dictData.keys.contains("view_count") {
                                var  dictTemp = Dictionary<String, Any>()
                                dictTemp["img_icon_sel"] = "view_icon_sel"
                                dictTemp["img_icon_unsel"] = "view_icon"
                                dictTemp["view_count"] = dictData["view_count"]
                                dictTemp["postActionType"] = PostActionTypeSHARE.VIEW_POST.rawValue
                                arr.append(dictTemp)
                            }
                            if dictData.keys.contains("comment_count") {
                                var  dictTemp = Dictionary<String, Any>()
                                dictTemp["img_icon_sel"] = "comm_icon_sel"
                                dictTemp["img_icon_unsel"] = "comm_icon_sel"
                                dictTemp["comment_count"] = dictData["comment_count"]
                                dictTemp["postActionType"] = PostActionTypeSHARE.COMMENT_POST.rawValue
                                arr.append(dictTemp)
                            }
                            
                            var  dictTempShare = Dictionary<String, Any>()
                            dictTempShare["img_icon"] = "more_share_icon"
                            dictTempShare["share"] = "share"
                            dictTempShare["moreActionType"] = PostMoreActionTypeSHARE.SHARE_POST.rawValue
                            arrMoreAction.append(dictTempShare)
                            
                            if dictData.keys.contains("need_to_dlt") {
                                var  dictEdit = Dictionary<String, Any>()
                                dictEdit["img_icon"] = "more_edit_icon"
                                dictEdit["need_to_edt"] = dictData["need_to_dlt"]
                                dictEdit["moreActionType"] = PostMoreActionTypeSHARE.EDIT_POST.rawValue
                                arrMoreAction.append(dictEdit)
                                
                                var  dictTemp = Dictionary<String, Any>()
                                dictTemp["img_icon"] = "more_delete_icon"
                                dictTemp["need_to_dlt"] = dictData["need_to_dlt"]
                                dictTemp["moreActionType"] = PostMoreActionTypeSHARE.DELETE_POST.rawValue
                                arrMoreAction.append(dictTemp)
                                
                            }
                            dictPostAction["arrMoreAction"] = arrMoreAction
                            
                            print(dictPostAction.count)
                            dictPostAction["arrPostAction"] = arr
                            self.arrPost.insert(dictPostAction, at: 0)
                            self.tblPost.reloadData()
                            //                            self.tblPost.setContentOffset(CGPoint.init(x: 0.0, y: 0.0), animated: true)
                            self.perform(#selector(self.setContentOffsetInitial), with: nil, afterDelay: 1.0)
                        }
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceDeletePost(dictParam : NSMutableDictionary, andIndexOfPost: NSInteger) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "deletePost", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrPost.remove(at: andIndexOfPost)
                        //                        self.tblPost.reloadData()
                        self.reloadPostData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceBidPost(dictParam : NSMutableDictionary, andIndexOfPost: NSInteger) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertDirectBid", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        self.hideBidPriceView()
                        let tempArray = dict?["data"] as! [Dictionary<String,Any>]
                        let dict = tempArray[0]
                        self.arrPost[andIndexOfPost] = dict
                        self.filterPostarrayForSell()
                        self.tblPost.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func callWebserviceEditBidPost(dictParam : NSMutableDictionary, andIndexOfPost: NSInteger) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            service.callJSONMethod(methodName: "updateBidPrice", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        self.hideBidPriceView()
                        //                        self.reloadPostData()
                        let tempArray = dict?["data"] as! [Dictionary<String,Any>]
                        let dict = tempArray[0]
                        self.arrPost[andIndexOfPost] = dict
                        self.filterPostarrayForSell()
                        self.tblPost.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - Scrollview Scrolling Methods
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let y = scrollView.contentOffset.y + scrollView.bounds.height - scrollView.contentInset.bottom
        let height = scrollView.contentSize.height
        if y >= height {
            
            if isPagingAvailable && !isLoadingData {
                //call webservice
                
                if viewForFooter == nil {
                    viewForFooter = TableFooterView.instanceFromNib() as? TableFooterView
                    viewForFooter?.frame = CGRect (x:0, y:0, width:tblPost.frame.size.width, height: 50)
                }
                tblPost.tableFooterView = viewForFooter
                viewForFooter?.indicator.startAnimating()
                isLoadingData = true
                if currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue || currentPostType == CurrentSelectedPostType.BOTH.rawValue {
                    callWebservicePostForHome()
                }
                else{
                    callWebservicePostForSell()
                }
            }
        }
    }
    
    // MARK: - PostDetailScreenDelegate
    
    func deletePostWithIndex(indexOfPost: NSInteger) {
        self.reloadPostData()
    }
    
    func replacePostDataWithIndex(indexOfObject: NSInteger, andPostDict: NSDictionary) {
        self.arrPost[indexOfObject] = andPostDict as! Dictionary<String, Any>
        let contentOffset = self.tblPost.contentOffset as CGPoint
        self.tblPost.reloadRows(at: [IndexPath.init(row: indexOfObject , section: 0)], with: .none)
        self.tblPost.setContentOffset(contentOffset, animated: false)
    }
    
    func addNewSharedPost(indexOfObject: NSInteger, andSharedPostDict: NSDictionary) {
        
        self.arrPost.insert(andSharedPostDict as! Dictionary<String, Any>, at: 0)
        self.tblPost.reloadData()
    }
    
    func updateCountForSamePost(dictPostIndi: Dictionary<String, Any>) {
        updateCount(dictPostIndi: dictPostIndi)
    }
    func updateFollowUnFollowButton(isSetFollow : Bool) -> Void {
        // do nothing
    }
    
    // MARK: - UserProfileDelegate // PostDetailScreenDelegate
    func reloadPostData()->Void {
        postCount = 0
        arrPost.removeAll()
        isPagingAvailable = true
        
        if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
            callWebservicePostForHome()
        }
        else if currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
            callWebservicePostForSell()
        }
    }
    
    // MARK: - Custom Method For Count Update For Same Post
    
    func updateCount(dictPostIndi : Dictionary<String,Any>) -> Void {
        let strPostId = dictPostIndi["post_id"] as! String
        for (index, var dict) in self.arrPost.enumerated() {
            var dictPostDtlIndividual = dict["postdetailindiv"] as! Dictionary<String,Any>
            let strPID = dictPostDtlIndividual["post_id"] as! String
            if strPostId == strPID {
                if dictPostDtlIndividual.keys.contains("need_to_call_agr_dis") {
                    dictPostDtlIndividual["need_to_call_agr_dis"] = dictPostIndi["need_to_call_agr_dis"]
                    if dictPostDtlIndividual.keys.contains("agree_count") {
                        dictPostDtlIndividual["agree_count"] = dictPostIndi["agree_count"]
                        
                    }
                    if dictPostDtlIndividual.keys.contains("dis_agree_count") {
                        dictPostDtlIndividual["dis_agree_count"] = dictPostIndi["dis_agree_count"]
                        
                    }
                }
                
                if dictPostDtlIndividual.keys.contains("ag_cls") {
                    dictPostDtlIndividual["ag_cls"] = dictPostIndi["ag_cls"]
                }
                
                if dictPostDtlIndividual.keys.contains("dag_cls") {
                    dictPostDtlIndividual["dag_cls"] = dictPostIndi["dag_cls"]
                }
                
                if dictPostDtlIndividual.keys.contains("view_count") {
                    dictPostDtlIndividual["dis_agree_count"] = dictPostIndi["dis_agree_count"]
                    
                }
                if dictPostDtlIndividual.keys.contains("comment_count") {
                    dictPostDtlIndividual["dis_agree_count"] = dictPostIndi["dis_agree_count"]
                    
                }
                if dictPostDtlIndividual.keys.contains("need_to_follow") {
                    dictPostDtlIndividual["dis_agree_count"] = dictPostIndi["dis_agree_count"]
                    
                }
                
                dict["postdetailindiv"] = dictPostDtlIndividual
                arrPost[index] = dict
            }
        }
        filterPostarray()
        self.tblPost.reloadData()
    }
    
    func setContentOffsetInitial() -> Void {
        self.tblPost.setContentOffset(CGPoint.init(x: 0.0, y: 0.0), animated: true)
    }
}

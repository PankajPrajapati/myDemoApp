//
//  InviteViewController.swift
//  Oriscene
//
//  Created by Parth on 12/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class InviteViewController: BaseViewController {
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var btnInviteFriends: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.layoutIfNeeded()
        btnInviteFriends.layer.cornerRadius = 3.0
        btnInviteFriends.layer.masksToBounds = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnInviteFriendsAction(_ sender: AnyObject) {
        let myShare = "Welcome to Oriscene (Original scene)- the revolutionary, one-of-a-kind website for buying and selling the world's most valuable commodity...information.\n I'm using Oriscene I recommend it. Click here: "
        let image: UIImage = #imageLiteral(resourceName: "default_img")
        
        let userDefault = UserDefaults.standard.dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            let dictUserData = userDefault["userData"] as! Dictionary<String,Any>
            let strUrl = "http://oriscene.com/Signup/" + (dictUserData["refer_no"] as! String)
            let url : URL = URL.init(string: strUrl)!
            let shareVC: UIActivityViewController = UIActivityViewController(activityItems: [(image), myShare, url], applicationActivities: nil)
            self.present(shareVC, animated: true, completion: nil)
        }
    }
}

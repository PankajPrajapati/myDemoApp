//
//  CategoriesViewController.swift
//  Oriscene
//
//  Created by Parth on 29/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class CategoriesViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource, CategorySectionHeaderDelegate, CategoryDelegate{
    
    var intCurrentLevel : NSInteger = 0
    var dictSelectedCat = Dictionary<String,AnyObject>()
    let service = WebService()
    var arrCategoryList = [Dictionary<String,AnyObject>]()
    var intSelectedRow : NSInteger = -1
    var isNeedToSelect : Bool = false
    
    @IBOutlet var tblCategory: UITableView!
    @IBOutlet var btnSelectCategory: UIButton!
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.lblMessage.isHidden = true
        self.callWebserviceforSelectedCategory()
        setUpUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isNeedToSelect {
            self.btnBack.isHidden = true
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    func setUpUI() -> Void {
        
        tblCategory.register(CategoryTVCell.self, forCellReuseIdentifier: "CategoryTVCell")
        tblCategory.register(UINib.init(nibName: "CategoryTVCell", bundle: nil), forCellReuseIdentifier: "CategoryTVCell")
        
        if !dictSelectedCat.isEmpty {
            lblTitle.text = dictSelectedCat["con_name"] as! String?
        }
        tblCategory.reloadData()
    }
    
    // MARK: - Action Method
    
    @IBAction func btnSelectCategoryAction(_ sender: Any) {
        if arrCategoryList.count > 0 {
            if intCurrentLevel == 0 {
                var intCount = 0
                for (_,dict) in arrCategoryList.enumerated() {
                    if dict["selectStaus"] as? String == "1" {
                        intCount += 1
                    }
                }
                if intCount < 5 {
                    self.showAlert(string: "Please select at least 5 main categories")
                    return
                }else{
                    callWebserviceforInsertCategory()
                }
            }else{
                callWebserviceforInsertCategory()
            }
        }
    }
    
    override func btnBackAction(_ sender: AnyObject) {
        
        if arrCategoryList.count > 0 {
            if intCurrentLevel == 0 {
                var intCount = 0
                for (_,dict) in arrCategoryList.enumerated() {
                    if dict["selectStaus"] as? String == "1" {
                        intCount += 1
                    }
                }
                if intCount < 5 {
                    self.showAlert(string: "Please select at least 5 main categories")
                    return
                }
            }
        }
        
        var isSettingVCAvailable = false
        for (_, element) in (self.navigationController?.viewControllers.enumerated())!{
            if element.isKind(of: SettingsViewController.self) {
                isSettingVCAvailable = true
            }
        }
        if isSettingVCAvailable {
            //simple back action
            self.navigationController!.popViewController(animated: true)
        }else{
            //add homeVC and back to it
            let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            homeVC.currentPostType = CurrentSelectedPostType.BOTH.rawValue
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.menuView?.intSelectedRow = MenuIndex.HOME.rawValue
            appDelegate.menuView?.reloadDataForMenu()
            self.navigationController?.setViewControllers([homeVC], animated: true)
        }
    }
    // MARK: - UITableView DataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        //        return arrCategoryList.count
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCategoryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "CategoryTVCell") as! CategoryTVCell
        cell.delegate = self
        cell.index = indexPath.row
        
        let dict = arrCategoryList[indexPath.row] as Dictionary<String,Any>
        cell.lblCategoryTitle?.text = dict["con_name"] as! String?
        
        if dict["selectStaus"] as? String == "1" {
            cell.btnSelect.isSelected = true
        }
        else{
            cell.btnSelect.isSelected = false
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44.0
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dict = arrCategoryList[indexPath.row] as Dictionary<String,AnyObject>
        let vcCategories = self.storyboard?.instantiateViewController(withIdentifier: "CategoriesViewController") as! CategoriesViewController
        vcCategories.dictSelectedCat = dict
        vcCategories.intCurrentLevel = intCurrentLevel + 1
        self.navigationController?.pushViewController(vcCategories, animated: true)
    }
    
    // MARK: - CategorySectionHeaderDelegate
    
    func btnExpnandColspanClicked(index: NSInteger){
        
        var dict = arrCategoryList[index] as Dictionary
        if dict["expand"] as? String == "0" {
            dict["expand"] = "1" as AnyObject?
        }
        else{
            dict["expand"] = "0" as AnyObject?
        }
        arrCategoryList[index] = dict
        let range = NSMakeRange(0, tblCategory.numberOfSections)
        let sections = NSIndexSet(indexesIn: range)
        tblCategory.reloadSections(sections as IndexSet, with: .automatic)
    }
    
    func btnSelectCategoryClicked(index: NSInteger){
        var dict = arrCategoryList[index] as Dictionary
        if dict["selected"] as? String == "0" {
            dict["selected"] = "1" as AnyObject?
        }
        else{
            dict["selected"] = "0" as AnyObject?
        }
        arrCategoryList[index] = dict
        let range = NSMakeRange(index, 1)
        let sections = NSIndexSet(indexesIn: range)
        tblCategory.reloadSections(sections as IndexSet, with: .automatic)
    }
    
    // MARK: - CategoryDelegate
    
    func btnSelectSubCategoryClicked(index: NSInteger){
        var dict = arrCategoryList[index]
        
        if dict["selectStaus"] as? String == "0" {
            dict["selectStaus"] = "1" as AnyObject?
        }
        else{
            dict["selectStaus"] = "0" as AnyObject?
        }
        arrCategoryList[index] = dict
        tblCategory.reloadRows(at: [IndexPath.init(row: index, section: 0)], with: .none)
    }
    
    // MARK: - Webservice Calling Method
    func callWebserviceforSelectedCategory() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["level"] = String(intCurrentLevel)
            dictParam["listFor"] = "2"
            
            if intCurrentLevel != 0 {
                print(dictSelectedCat)
                if !dictSelectedCat.isEmpty {
                    dictParam["conId"] = dictSelectedCat["con_id"] as! String
                }
            }
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "selectedCategory", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrCategoryList = dict?["data"] as! [ Dictionary<String,AnyObject>]
                        self.tblCategory.reloadData()
                    }
                    else if dict?["status"] as! String == "0" {
                        self.lblMessage.isHidden = false
                        // self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - Webservice Calling Method
    func callWebserviceforInsertCategory() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["level"] = String(intCurrentLevel)
            dictParam["listFor"] = "2"
            
            var strSelectedCategoryId = ""
            for (_,dict) in arrCategoryList.enumerated() {
                if dict["selectStaus"] as? String == "1" {
                    if strSelectedCategoryId == "" {
                        strSelectedCategoryId = (dict["con_id"]! as? String)!
                    }else{
                        strSelectedCategoryId = strSelectedCategoryId + "," + (dict["con_id"]! as? String)!
                    }
                }
            }
            
            dictParam["category"] = strSelectedCategoryId
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertCategory", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        if self.isNeedToSelect {
                            if self.intCurrentLevel == 0 {
                                self.btnBackAction(UIButton.init())
                            }else{
                                self.navigationController!.popViewController(animated: true)
                            }
                        }
                        else{
                            self.navigationController!.popViewController(animated: true)
                        }
                    }
                    else if dict?["status"] as! String == "0" {
                        //self.lblMessage.isHidden = false
                        // self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

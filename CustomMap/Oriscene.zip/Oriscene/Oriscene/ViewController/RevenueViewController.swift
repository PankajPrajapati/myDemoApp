//
//  RevenueViewController.swift
//  Oriscene
//
//  Created by Parth on 12/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

enum RevenueIndex: Int {
    case MY_WALLET = 0, BIDS, STATISTICS
}

class RevenueViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    
    var arrRevenueList = [Dictionary<String,String>]()
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var tblRevenue: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tblRevenue.register(RevenueListTVCell.self, forCellReuseIdentifier: "RevenueListTVCell")
        tblRevenue.register(UINib.init(nibName: "RevenueListTVCell", bundle: nil), forCellReuseIdentifier: "RevenueListTVCell")
        
        self.setUI()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    func setUI() -> Void {
        
        tblRevenue.contentInset = UIEdgeInsetsMake(8.0, 0.0, 0.0, 0.0)
        
        arrRevenueList = [ ["revenueTitle" : "My Wallet" , "revenueImage" : "wallet_icon" ] , ["revenueTitle" : "Bids" , "revenueImage" : "bids_icon" ] , ["revenueTitle" : "Statistics" , "revenueImage" : "statistics_icon" ] ]
        tblRevenue.reloadData()
    }
    
    // MARK: - UITableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRevenueList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "RevenueListTVCell") as! RevenueListTVCell
        cell.index = indexPath.row
        
        let dict = arrRevenueList[indexPath.row] as Dictionary
        
        cell.lblRevenueText.text = dict["revenueTitle"]
        cell.imgRevenue.image = UIImage.init(named: dict["revenueImage"]!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180.0
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case RevenueIndex.MY_WALLET.rawValue:
            let vcWallet = self.storyboard?.instantiateViewController(withIdentifier: "WalletViewController") as! WalletViewController
            self.navigationController?.pushViewController(vcWallet, animated: true)
            break
        case RevenueIndex.BIDS.rawValue:
            let vcBids = self.storyboard?.instantiateViewController(withIdentifier: "BidsViewController") as! BidsViewController
            self.navigationController?.pushViewController(vcBids, animated: true)
            break
        case RevenueIndex.STATISTICS.rawValue:
            let vcStatistics = self.storyboard?.instantiateViewController(withIdentifier: "StatisticsViewController") as! StatisticsViewController
            self.navigationController?.pushViewController(vcStatistics, animated: true)
            break
        default:
            break
        }
    }
    
}

//
//  WithdrawFundsViewController.swift
//  Oriscene
//
//  Created by TriState  on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class WithdrawFundsViewController: BaseViewController, UITableViewDataSource, UITableViewDelegate , WalletPopupDelegate,WithdrawFundsTVCellDelegate,TTTAttributedLabelDelegate,PayPalFuturePaymentDelegate, PayPalPaymentDelegate, FinacialInfoVCDelegate, WithdrawFundsRequestTVCellDelegate, WithdrawFundsViewDelegate {
    
    var viewWithdrawFund : WithdrawFundsView? = nil
    var dictWithDrawFundLayout = Dictionary<String,Any>()
    let service = WebService()
    
    var payPalConfig = PayPalConfiguration() // default
    var arrWithdrawFunds = [Dictionary<String,String>]()
    
    @IBOutlet var viewHeader: UIView!
    
    //@IBOutlet var lblHeaderText: FRHyperLabel!
    
    @IBOutlet var lblHeaderText: TTTAttributedLabel!
    
    @IBOutlet var tblWithdrawFunds: UITableView!
    
    let viewWalletPopup = WalletPopupView.instanceFromNib() as! WalletPopupView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.callWebserviceWithdrawFundLayout()
        // Set up payPalConfig
        payPalConfig.acceptCreditCards = false
        payPalConfig.merchantName = "Oriscene, Inc."
        payPalConfig.merchantPrivacyPolicyURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/privacy-full")
        payPalConfig.merchantUserAgreementURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/useragreement-full")
        
        // Setting the languageOrLocale property is optional.
        //
        // If you do not set languageOrLocale, then the PayPalPaymentViewController will present
        // its user interface according to the device's current language setting.
        //
        // Setting languageOrLocale to a particular language (e.g., @"es" for Spanish) or
        // locale (e.g., @"es_MX" for Mexican Spanish) forces the PayPalPaymentViewController
        // to use that language/locale.
        //
        // For full details, including a list of available languages and locales, see PayPalPaymentViewController.h.
        
        payPalConfig.languageOrLocale = Locale.preferredLanguages[0]
        
        // Setting the payPalShippingAddressOption property is optional.
        //
        // See PayPalConfiguration.h for details.
        
        payPalConfig.payPalShippingAddressOption = .none;
        
        print("PayPal iOS SDK Version: \(PayPalMobile.libraryVersion())")
        
        
        arrWithdrawFunds = [
            [ "Title" : "Add Amount to Wallet","ButtonText" : "ADD MONEY" ],
            [ "Title" : "Withdraw Refers, Bonuses & Sharing Amount","ButtonText" : "WITHDRAW FUNDS" ],
            [ "Title" : "Withdraw Selling amount","ButtonText" : "WITHDRAW FUNDS" ],
        ]
        
        self.setupWithdrawFundsUI()
        //        self.tblWithdrawFunds.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    func setupWithdrawFundsUI() {
        
        let strMain = "Your Paypal Email is Not Verified. Please Click here to Verify your Paypal Email."
        let strSub = "Click here"
        let range = (strMain as NSString).range(of:strSub)
        self.lblHeaderText.delegate = self
        let url = URL(string: "")
        self.lblHeaderText.addLink(to: url, with: range)
        
        self.tblWithdrawFunds.register(WithdrawFundsTVCell.self, forCellReuseIdentifier: "WithdrawFundsTVCell")
        self.tblWithdrawFunds.register(UINib.init(nibName: "WithdrawFundsTVCell", bundle: nil), forCellReuseIdentifier: "WithdrawFundsTVCell")
        
        self.tblWithdrawFunds.register(WithdrawFundsRequestTVCell.self, forCellReuseIdentifier: "WithdrawFundsRequestTVCell")
        self.tblWithdrawFunds.register(UINib.init(nibName: "WithdrawFundsRequestTVCell", bundle: nil), forCellReuseIdentifier: "WithdrawFundsRequestTVCell")
        
        viewWalletPopup.frame = UIScreen.main.bounds
        viewWalletPopup.isHidden = true
        viewWalletPopup.delegate = self
        self.view.addSubview(viewWalletPopup)
        
        self.setUpVerifyPayaplAccountOrNot()
        
        if viewWithdrawFund == nil {
            viewWithdrawFund = WithdrawFundsView.instanceFromNib() as? WithdrawFundsView
            viewWithdrawFund?.frame = UIScreen.main.bounds
            viewWithdrawFund?.isHidden = true
            viewWithdrawFund?.delegate = self
            viewWithdrawFund?.alpha = 0.0
            self.view.addSubview(viewWithdrawFund!)
        }
    }
    
    func setUpVerifyPayaplAccountOrNot() -> Void {
        self.tblWithdrawFunds.setContentOffset(CGPoint.init(x: 0.0, y: 0.0), animated: true)
        let userDefault = UserDefaults.standard.dictionaryRepresentation()
        if userDefault.keys.contains("business_data") {
            let dictUser = userDefault["business_data"] as! Dictionary<String,Any>
            let strpaypal_verify = dictUser["paypal_verify"] as! String
            if (strpaypal_verify == "1") {
                self.tblWithdrawFunds.tableHeaderView = nil
            }
            else{
                self.tblWithdrawFunds.tableHeaderView = self.viewHeader
            }
        }
        self.tblWithdrawFunds.reloadData()
    }
    
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith url: URL!) {
        print("Link click")
        
        let vcFinancial = self.storyboard?.instantiateViewController(withIdentifier: "FinancialInfoViewController") as! FinancialInfoViewController
        vcFinancial.isfromWithDrawForVerifyAccount = true
        vcFinancial.delegate = self
        self.navigationController?.pushViewController(vcFinancial, animated: true)
    }
    
    // MARK: - UITableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dictWithDrawFundLayout.isEmpty {
            return 0
        }
        else{
            return 3
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            let cell = tableView .dequeueReusableCell(withIdentifier: "WithdrawFundsTVCell") as! WithdrawFundsTVCell
            cell.delegate = self
            cell.index = indexPath.row
            cell.selectionStyle = .none
            let dictdata = arrWithdrawFunds[indexPath.row]
            cell.lblHeadertext.text = dictdata["Title"]
            cell.btnWithdrawFundsOption.setTitle(dictdata["ButtonText"],for: .normal)
            cell.btnWithdrawFundsOption.backgroundColor = UIColor.init(red: 16.0/255.0, green: 87.0/255.0, blue: 198.0/255.0, alpha: 1.0)
            return cell
        }
        else if indexPath.row == 1 {
            let dictReferBonus = dictWithDrawFundLayout["refer_bonus_det"] as! Dictionary<String,Any>
            if dictReferBonus.keys.contains("dis_sent_btn") {
                let cell = tableView .dequeueReusableCell(withIdentifier: "WithdrawFundsRequestTVCell") as! WithdrawFundsRequestTVCell
                cell.delegate = self
                cell.index = indexPath.row
                cell.selectionStyle = .none
                let dictdata = arrWithdrawFunds[indexPath.row]
                cell.lblHeadertext.text = dictdata["Title"]
                cell.btnWithdrawFundsOption.setTitle(dictdata["ButtonText"],for: .normal)
                cell.btnWithdrawFundsOption.backgroundColor = UIColor.init(colorLiteralRed: 122.0/255.0, green: 126.0/255.0 , blue: 134.0/255.0 , alpha: 1.0)
                
                let dictrequest_data = dictReferBonus["request_data"] as! Dictionary<String,Any>
                cell.btnWithdrawFundsOption.setTitle("WITHDRAW REQUEST OF " + "\(dictrequest_data["amount"]!)" + " SENT", for: .normal)
                
                cell.btnCancelRequest.setTitle("CANCEL REQUEST", for: .normal)
                cell.btnCancelRequest.backgroundColor = UIColor.init(red: 16.0/255.0, green: 87.0/255.0, blue: 198.0/255.0, alpha: 1.0)
                return cell
            }
            else {
                
                let cell = tableView .dequeueReusableCell(withIdentifier: "WithdrawFundsTVCell") as! WithdrawFundsTVCell
                cell.delegate = self
                cell.index = indexPath.row
                cell.selectionStyle = .none
                let dictdata = arrWithdrawFunds[indexPath.row]
                cell.lblHeadertext.text = dictdata["Title"]
                cell.btnWithdrawFundsOption.setTitle(dictdata["ButtonText"],for: .normal)
                
                if dictReferBonus.keys.contains("share_btn_enable") {
                    cell.btnWithdrawFundsOption.backgroundColor = UIColor.init(red: 16.0/255.0, green: 87.0/255.0, blue: 198.0/255.0, alpha: 1.0)
                }
                else if dictReferBonus.keys.contains("share_btn_disable") {
                    cell.btnWithdrawFundsOption.backgroundColor = UIColor.init(colorLiteralRed: 122.0/255.0, green: 126.0/255.0 , blue: 134.0/255.0 , alpha: 1.0)
                }
                return cell
            }
        }
        else {
            let dictSellDetail = dictWithDrawFundLayout["sell_det"] as! Dictionary<String,Any>
            
            if dictSellDetail.keys.contains("dis_sent_btn") {
                let cell = tableView .dequeueReusableCell(withIdentifier: "WithdrawFundsRequestTVCell") as! WithdrawFundsRequestTVCell
                cell.delegate = self
                cell.index = indexPath.row
                cell.selectionStyle = .none
                let dictdata = arrWithdrawFunds[indexPath.row]
                cell.lblHeadertext.text = dictdata["Title"]
                cell.btnWithdrawFundsOption.setTitle(dictdata["ButtonText"],for: .normal)
                cell.btnWithdrawFundsOption.backgroundColor = UIColor.init(colorLiteralRed: 122.0/255.0, green: 126.0/255.0 , blue: 134.0/255.0 , alpha: 1.0)
                
                let dictrequest_data = dictSellDetail["request_data"] as! Dictionary<String,Any>
                cell.btnWithdrawFundsOption.setTitle("WITHDRAW REQUEST OF " + "\(dictrequest_data["amount"]!)" + " SENT", for: .normal)
                
                cell.btnCancelRequest.setTitle("CANCEL REQUEST", for: .normal)
                cell.btnCancelRequest.backgroundColor = UIColor.init(red: 16.0/255.0, green: 87.0/255.0, blue: 198.0/255.0, alpha: 1.0)
                
                return cell
            }
            else {
                
                let cell = tableView .dequeueReusableCell(withIdentifier: "WithdrawFundsTVCell") as! WithdrawFundsTVCell
                cell.delegate = self
                cell.index = indexPath.row
                cell.selectionStyle = .none
                let dictdata = arrWithdrawFunds[indexPath.row]
                cell.lblHeadertext.text = dictdata["Title"]
                cell.btnWithdrawFundsOption.setTitle(dictdata["ButtonText"],for: .normal)
                cell.btnWithdrawFundsOption.backgroundColor = UIColor.blue
                
                if dictSellDetail.keys.contains("sell_btn_enable") {
                    cell.btnWithdrawFundsOption.backgroundColor = UIColor.init(red: 16.0/255.0, green: 87.0/255.0, blue: 198.0/255.0, alpha: 1.0)
                }
                else if dictSellDetail.keys.contains("sell_btn_disable") {
                    cell.btnWithdrawFundsOption.backgroundColor = UIColor.init(colorLiteralRed: 122.0/255.0, green: 126.0/255.0 , blue: 134.0/255.0 , alpha: 1.0)
                }
                return cell
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 120
        }
        else if indexPath.row == 1 {
            let dictReferBonus = dictWithDrawFundLayout["refer_bonus_det"] as! Dictionary<String,Any>
            if dictReferBonus.keys.contains("dis_sent_btn") {
                return 190
            }
            else {
                
                return 120
            }
        }
        else {
            let dictSellDetail = dictWithDrawFundLayout["sell_det"] as! Dictionary<String,Any>
            
            if dictSellDetail.keys.contains("dis_sent_btn") {
                return 190
            }
            else {
                
                return 120
            }
            
        }
    }
    
    // MARK: - UITableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    // MARK: - WithdrawFundsTVCellDelegate
    
    func btnWithdrawFundsAction(index: NSInteger) {
        if (index == 0)
        {
            self.viewWalletPopup.txtAmount.text = ""
            self.viewWalletPopup.alpha = 0.0
            viewWalletPopup.isHidden = false
            UIView.animate(withDuration: 0.0, animations: {() -> Void in
                self.viewWalletPopup.alpha = 0.0
            }, completion: {(_ finished: Bool) -> Void in
                UIView.animate(withDuration: 0.3, animations: {() -> Void in
                    self.viewWalletPopup.alpha = 1.0
                }, completion: { _ in })
            })
        }
        else if (index == 1) {
            if isVerifiedPaypalAccount() {
                
                let dictReferBonus = dictWithDrawFundLayout["refer_bonus_det"] as! Dictionary<String,Any>
                if dictReferBonus.keys.contains("share_btn_enable") {
                    self.viewWithdrawFund?.txtAmount.text = ""
                    self.viewWithdrawFund?.lblWithdrawAmount.text = ""
                    self.viewWithdrawFund?.lblCommision.text = ""
                    self.viewWithdrawFund?.isForShare = true
                    
                    if self.dictWithDrawFundLayout.keys.contains("site_data") {
                        let dictSiteData = self.dictWithDrawFundLayout["site_data"] as! Dictionary<String,Any>
                        self.viewWithdrawFund?.floatCommisionRate = Float(dictSiteData["site_commission"] as! String)!
                        self.viewWithdrawFund?.lblCommissionTitle.text = "Commission(-" + "\(Float(dictSiteData["site_commission"] as! String)!)" + "%)"
                    }
                    //refer and sharing fund
                    self.viewWithdrawFund?.alpha = 0.0
                    self.viewWithdrawFund?.isHidden = false
                    
                    UIView.animate(withDuration: 0.0, animations: {() -> Void in
                        self.viewWithdrawFund?.alpha = 0.0
                    }, completion: {(_ finished: Bool) -> Void in
                        UIView.animate(withDuration: 0.3, animations: {() -> Void in
                            self.viewWithdrawFund?.alpha = 1.0
                        }, completion: { _ in })
                    })
                }
                else if dictReferBonus.keys.contains("share_btn_disable") {
                    
                }
            }
            else{
                self.showAlert(string: "Unable to Withdraw Amount. Your Paypal Email is not verified.")
            }
        }
        else {
            if isVerifiedPaypalAccount() {
                
                let dictSellDetail = dictWithDrawFundLayout["sell_det"] as! Dictionary<String,Any>
                if dictSellDetail.keys.contains("sell_btn_enable") {
                    self.viewWithdrawFund?.txtAmount.text = ""
                    self.viewWithdrawFund?.lblWithdrawAmount.text = ""
                    self.viewWithdrawFund?.lblCommision.text = ""
                    self.viewWithdrawFund?.isForShare = false
                    
                    if self.dictWithDrawFundLayout.keys.contains("site_data") {
                        let dictSiteData = self.dictWithDrawFundLayout["site_data"] as! Dictionary<String,Any>
                        self.viewWithdrawFund?.floatCommisionRate = Float(dictSiteData["site_commission"] as! String)!
                        self.viewWithdrawFund?.lblCommissionTitle.text = "Commission(-" + "\(Float(dictSiteData["site_commission"] as! String)!)" + "%)"
                    }
                    
                    //refer and sharing fund
                    self.viewWithdrawFund?.alpha = 0.0
                    self.viewWithdrawFund?.isHidden = false
                    
                    UIView.animate(withDuration: 0.0, animations: {() -> Void in
                        self.viewWithdrawFund?.alpha = 0.0
                    }, completion: {(_ finished: Bool) -> Void in
                        UIView.animate(withDuration: 0.3, animations: {() -> Void in
                            self.viewWithdrawFund?.alpha = 1.0
                        }, completion: { _ in })
                    })
                }
                else if dictSellDetail.keys.contains("sell_btn_disable") {
                    
                }
            }
            else{
                self.showAlert(string: "Unable to Withdraw Amount. Your Paypal Email is not verified.")
            }
        }
    }
    
    func isVerifiedPaypalAccount() -> Bool {
        let userDefault = UserDefaults.standard.dictionaryRepresentation()
        if userDefault.keys.contains("business_data") {
            let dictUser = userDefault["business_data"] as! Dictionary<String,Any>
            let strpaypal_verify = dictUser["paypal_verify"] as! String
            if (strpaypal_verify == "1") {
                return true
            }
            else{
                return false
            }
        }
        else{
            return false
        }
    }
    
    // MARK: - WithdrawFundsRequestTVCellDelegate
    
    func btnCancelRequestAction(index: NSInteger) {
        if index == 1 {
            let dictReferBonus = dictWithDrawFundLayout["refer_bonus_det"] as! Dictionary<String,Any>
            if dictReferBonus.keys.contains("request_data") {
                let dictrequest_data = dictReferBonus["request_data"] as! Dictionary<String,Any>
                let dictParam = NSMutableDictionary()
                dictParam["withDrawId"] = dictrequest_data["id"]
                dictParam["forWhat"] = "1"
                self.callWebserviceCancelWithdrawMoney(dictParam: dictParam, forWhat: true)
            }
        }
        else if index == 2 {
            let dictSellDetail = dictWithDrawFundLayout["sell_det"] as! Dictionary<String,Any>
            if dictSellDetail.keys.contains("request_data") {
                let dictrequest_data = dictSellDetail["request_data"] as! Dictionary<String,Any>
                let dictParam = NSMutableDictionary()
                dictParam["withDrawId"] = dictrequest_data["id"]
                dictParam["forWhat"] = "1"
                self.callWebserviceCancelWithdrawMoney(dictParam: dictParam, forWhat: false)
            }
        }
    }
    
    func btnWithdrawFundsConfirmAction(index: NSInteger) {
        
    }
    
    // MARK: - WalletPopupDelegate
    
    func btnAddmoneyClicked(strAmount: String) {
        
        if strAmount == "" {
            self.showAlert(string: "Please enter amount")
            return
        }
        
        self.view.endEditing(true)
        self.AddAmountToWallet(strMoney: strAmount)
    }
    
    func hideWalletPopupView() {
        self.view.endEditing(true)
        
        viewWalletPopup.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewWalletPopup.alpha = 0.0
        }) { (Bool) in
            self.viewWalletPopup.isHidden = true
        }
    }
    
    // MARK: - WithdrawFundDelegate
    func hideWithdrawFundsView() -> Void {
        self.view.endEditing(true)
        
        viewWithdrawFund?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewWithdrawFund?.alpha = 0.0
        }) { (Bool) in
            self.viewWithdrawFund?.isHidden = true
        }
    }
    
    func saveWithdrawFundsView(strEnterAmount: String, strCommisionAmount: String, strWithdrawAmount: String, isForShare: Bool) {
        
        if isForShare {
            //share
            if strEnterAmount == "" {
                self.showAlert(string: "Please Enter Refers & Bonus Amount")
                return
            }
            else{
                let dictParam = NSMutableDictionary()
                dictParam["forWhat"] = "1"
                dictParam["amount"] = strEnterAmount
                dictParam["totalAmount"] = strWithdrawAmount
                self.callWebserviceWithdrawMoney(dictParam: dictParam, forWhat: isForShare)
            }
        }
        else{
            //sell
            if strEnterAmount == "" {
                self.showAlert(string: "Please Enter Selling Amount")
                return
            }
            else{
                let dictParam = NSMutableDictionary()
                dictParam["forWhat"] = "2"
                dictParam["amount"] = strEnterAmount
                dictParam["totalAmount"] = strWithdrawAmount
                self.callWebserviceWithdrawMoney(dictParam: dictParam, forWhat: isForShare)
            }
        }
    }
    
    // MARK: - PayPalPaymentDelegate
    
    func payPalPaymentDidCancel(_ paymentViewController: PayPalPaymentViewController) {
        print("PayPal Payment Cancelled")
        //  resultText = ""
        paymentViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalPaymentViewController(_ paymentViewController: PayPalPaymentViewController, didComplete completedPayment: PayPalPayment) {
        print("PayPal Payment Success !")
        paymentViewController.dismiss(animated: true, completion: { () -> Void in
            // send completed confirmaion to your server
            print("Here is your proof of payment:\n\n\(completedPayment.confirmation)\n\nSend this to your server for confirmation and fulfillment.")
            
            let dictConfirmation = completedPayment.confirmation as! Dictionary<String,Any>
            let dictResponse = dictConfirmation["response"] as! Dictionary<String,Any>
            let dictParam = NSMutableDictionary()
            
            dictParam["paymentTransId"] = dictResponse["id"] as! String
            
            self.callWebserviceConfirmAddMoneyToWallet(dictParam: dictParam)
            //            self.resultText = completedPayment.description
        })
    }
    
    // MARK: Future Payments
    
    func payPalFuturePaymentDidCancel(_ futurePaymentViewController: PayPalFuturePaymentViewController) {
        print("PayPal Future Payment Authorization Canceled")
        futurePaymentViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalFuturePaymentViewController(_ futurePaymentViewController: PayPalFuturePaymentViewController, didAuthorizeFuturePayment futurePaymentAuthorization: [AnyHashable: Any]) {
        print("PayPal Future Payment Authorization Success!")
        // send authorization to your server to get refresh token.
        futurePaymentViewController.dismiss(animated: true, completion: { () -> Void in
            
        })
    }
    
    //MARK:- FinacialInfoVCDelegate
    
    func btnVerifiedPaypalSuccessfully() {
        self.setUpVerifyPayaplAccountOrNot()
    }
    
    //MARK:- Validation Method
    /* func validateFinancialDetail() -> Bool {
     
     if trimString(string: (txtEmail.text)!).characters.count == 0 {
     showAlert(string: Constant.ALERT_MSG_PAYPAL_EMIAL_VALIDATE)
     return false
     }
     else if !self.isValidEmail(testStr: self.trimString(string:(txtEmail.text!))) {
     self.showAlert(string: Constant.ALERT_MSG_EMAIL_VALIDATE_FROMAT)
     return false
     }
     else{
     return true
     }
     }*/
    //MARK:- Webservice Method
    func callWebserviceWithdrawFundLayout() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            self.showSpinnerForChildVC(enableInteraction: false)
            service.callJSONMethod(methodName: "withDrawFundLayout", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        print(dict!)
                        self.dictWithDrawFundLayout = dict?["data"] as! Dictionary<String,Any>
                        self.tblWithdrawFunds.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceConfirmAddMoneyToWallet(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinnerForChildVC(enableInteraction: false)
            
            service.callJSONMethod(methodName: "addAmountToWallet", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.showAlert(string: dict?["message"] as! String)
                        self.hideWalletPopupView()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceWithdrawMoney(dictParam : NSMutableDictionary, forWhat : Bool) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinnerForChildVC(enableInteraction: false)
            
            service.callJSONMethod(methodName: "withDrawRequest", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.showAlert(string: dict?["message"] as! String)
                        self.dictWithDrawFundLayout = dict?["layout"] as! Dictionary<String,Any>
                        self.tblWithdrawFunds.reloadData()
                        self.hideWithdrawFundsView()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceCancelWithdrawMoney(dictParam : NSMutableDictionary, forWhat : Bool) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinnerForChildVC(enableInteraction: false)
            
            service.callJSONMethod(methodName: "cancelWithDrawRequest", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.showAlert(string: dict?["message"] as! String)
                        self.dictWithDrawFundLayout = dict?["layout"] as! Dictionary<String,Any>
                        self.tblWithdrawFunds.reloadData()                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func AddAmountToWallet(strMoney: String) -> Void {
        let item1 = PayPalItem(name: "Oriscene", withQuantity: 1, withPrice: NSDecimalNumber(string: strMoney), withCurrency: "USD", withSku: "Hip-0037")
        
        let items = [item1]
        let subtotal = PayPalItem.totalPrice(forItems: items)
        
        // Optional: include payment details
        let shipping = NSDecimalNumber(string: "0.0")
        let tax = NSDecimalNumber(string: "0.0")
        let paymentDetails = PayPalPaymentDetails(subtotal: subtotal, withShipping: shipping, withTax: tax)
        
        let total = subtotal.adding(shipping).adding(tax)
        
        let payment = PayPalPayment(amount: total, currencyCode: "USD", shortDescription: "Wallet Money", intent: .sale)
        
        payment.items = items
        payment.paymentDetails = paymentDetails
        
        if (payment.processable) {
            let paymentViewController = PayPalPaymentViewController(payment: payment, configuration: payPalConfig, delegate: self)
            present(paymentViewController!, animated: true, completion: nil)
        }
        else {
            // This particular payment will always be processable. If, for
            // example, the amount was negative or the shortDescription was
            // empty, this payment wouldn't be processable, and you'd want
            // to handle that here.
            print("Payment not processalbe: \(payment)")
        }
    }
}

//
//  BaseViewController.swift
//  Oriscene
//
//  Created by Parth on 10/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

extension UIView {
    
    //Start Rotating view
    func startRotating(duration: Double = 1) {
        let kAnimationKey = "rotation"
        
        if self.layer.animation(forKey: kAnimationKey) == nil {
            let animate = CABasicAnimation(keyPath: "transform.rotation")
            animate.duration = duration
            animate.repeatCount = Float.infinity
            
            animate.fromValue = 0.0
            animate.toValue = Float(M_PI * 2.0)
            self.layer.add(animate, forKey: kAnimationKey)
        }
    }
    
    //Stop rotating view
    func stopRotating() {
        let kAnimationKey = "rotation"
        
        if self.layer.animation(forKey: kAnimationKey) != nil {
            self.layer.removeAnimation(forKey: kAnimationKey)
        }
    }
    
}

class BaseViewController: UIViewController {
    
    var ViewSpinner: UIView = UIView()
    var imageView : UIImageView = UIImageView()
    
    // MARK: - OutLet
    @IBOutlet var spinner: UIActivityIndicatorView!
    
    // MARK: - UIView Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Action Method
    @IBAction func btnMenuAction(_ sender: AnyObject) {
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.showMenu()
    }
    
    @IBAction func btnBackAction(_ sender: AnyObject) {
        self.navigationController!.popViewController(animated: true)
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent //or default
    }
    
    //Mark: progressHood method
    
    func showSpinner(enableInteraction : Bool) -> Void {
        //        self.spinner.isHidden = false
        
        imageView.stopRotating()
        ViewSpinner.removeFromSuperview()
        
        self.view.isUserInteractionEnabled = enableInteraction
        ViewSpinner = UIView(frame: CGRect(x:0, y:0, width:80, height: 80))
        //        ViewSpinner.center = self.view.center;
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        ViewSpinner.center = (appdelegate.window?.center)!
        print(ViewSpinner.center)
        print(appdelegate.window?.center as Any)
        
        ViewSpinner.backgroundColor = UIColor.init(red: 51.0/255.0, green: 59.0/255.0, blue: 81.0/255.0, alpha: 1.0)
        ViewSpinner.alpha = 0.5
        ViewSpinner.layer.cornerRadius = 5.0
        ViewSpinner.bringSubview(toFront: ViewSpinner)
        
        let imageName = "img_loader.png"
        let globalImage = UIImage(named: imageName)
        imageView = UIImageView(image: globalImage!)
        imageView.frame = CGRect(x: ViewSpinner.frame.size.width/2-25, y: ViewSpinner.frame.size.height/2-25, width: 50, height: 50)
        
        imageView.startRotating()
        imageView.layer.cornerRadius = imageView.frame.size.height/2
        imageView.layer.masksToBounds = true
        ViewSpinner.addSubview(imageView)
        
        self.view.addSubview(ViewSpinner)
        //        appdelegate.window?.addSubview(ViewSpinner)
    }
    
    func showSpinnerForChildVC(enableInteraction : Bool) -> Void {
        //        self.spinner.isHidden = false
        
        imageView.stopRotating()
        ViewSpinner.removeFromSuperview()
        
        self.view.isUserInteractionEnabled = enableInteraction
        ViewSpinner = UIView(frame: CGRect(x:0, y:0, width:80, height: 80))
        //        ViewSpinner.center = self.view.center;
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        ViewSpinner.center = (appdelegate.window?.center)!
        print(ViewSpinner.center)
        print(appdelegate.window?.center as Any)
        ViewSpinner.frame.origin.y = ViewSpinner.frame.origin.y - 136.0
        ViewSpinner.backgroundColor = UIColor.init(red: 51.0/255.0, green: 59.0/255.0, blue: 81.0/255.0, alpha: 1.0)
        ViewSpinner.alpha = 0.5
        ViewSpinner.layer.cornerRadius = 5.0
        ViewSpinner.bringSubview(toFront: ViewSpinner)
        
        let imageName = "img_loader.png"
        let globalImage = UIImage(named: imageName)
        imageView = UIImageView(image: globalImage!)
        imageView.frame = CGRect(x: ViewSpinner.frame.size.width/2-25, y: ViewSpinner.frame.size.height/2-25, width: 50, height: 50)
        
        imageView.startRotating()
        imageView.layer.cornerRadius = imageView.frame.size.height/2
        imageView.layer.masksToBounds = true
        ViewSpinner.addSubview(imageView)
        
        self.view.addSubview(ViewSpinner)
        //        appdelegate.window?.addSubview(ViewSpinner)
    }
    
    func hideSpinner() -> Void {
        //        self.spinner.isHidden = true
        self.view.isUserInteractionEnabled = true
        
        imageView.stopRotating()
        ViewSpinner.removeFromSuperview()
    }
    
    // MARK: - Recability Method
    func isConnectedToNetwork() -> Bool {
        
        if (currentReachabilityStatus == ReachabilityStatus.reachableViaWiFi)
        {
            return true
        }
        else if (currentReachabilityStatus == ReachabilityStatus.reachableViaWWAN)
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    func trimString(string : String) -> String {
        let trimmedString = string.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        return trimmedString
    }
    
    func showAlert(string : String) -> Void {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: string , delegate: nil, cancelButtonTitle: "OK")
        alertWarning.show()
    }
    
    func showNoNetworkAlert() -> Void {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Please check internet connection." , delegate: nil, cancelButtonTitle: "OK")
        alertWarning.show()
    }
    
    func isValidEmail(testStr:String) -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    func isValidPassword(_ passwordString: String) -> Bool {
        let stricterFilterString = "^(?=.*\\p{Alpha})(?=.*\\p{Digit}).{8,}$"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", stricterFilterString)
        let result = passwordTest.evaluate(with: passwordString)
        return result
    }
    
    func isValidUsername(_ passwordString: String) -> Bool {
        let stricterFilterString = "^(?=.*\\p{Alpha})(?=.*\\p{Digit})(?=.*[!@#$%&*()_+=|<>?{}\\[\\]~-]).{7,}$"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", stricterFilterString)
        let result = passwordTest.evaluate(with: passwordString)
        return result
    }
    
    //MARK:- Random Color Method
    func getRandomColor(index:NSInteger) -> UIColor {
        let arrColors = ["#F44336","#9C27B0","#3F51B5","#2196F3","#4CAF50","#E91E63","#673AB7","#03A9F4","#009688","#00BCD4"]
        
        //let randomIndex = Int(arc4random_uniform(UInt32(arrColors.count)))
        let temp = Float(index)
        let randomIndex = (NSInteger) (temp.truncatingRemainder(dividingBy: 10))
        let hex = arrColors[randomIndex]
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.red
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    //MARK:- Date Function
    func convertStringToDate(strDate : String) -> String {
        
        let dateFormater = DateFormatter()
        dateFormater.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let newDate  =  dateFormater.date(from: strDate)
        
        dateFormater.dateFormat = "MMM dd, yyyy HH:mm a"
        let strNewDate = dateFormater.string(from: newDate!)
        
        return strNewDate
    }
}
extension String {
    
    func fromBase64() -> String? {
        guard let data = Data(base64Encoded: self) else {
            return nil
        }
        
        return String(data: data, encoding: .utf8)
    }
    
    func toBase64() -> String {
        return Data(self.utf8).base64EncodedString()
    }
}
extension Date {
    var timestampString: String? {
        let formatter = DateComponentsFormatter()
        formatter.unitsStyle = .full
        formatter.maximumUnitCount = 1
        formatter.allowedUnits = [.year, .month, .day, .hour, .minute, .second]
        
        guard let timeString = formatter.string(from: self as Date, to: NSDate() as Date) else {
            return nil
        }
        
        let formatString = NSLocalizedString("%@ ago", comment: "")
        return String(format: formatString, timeString)
    }
}

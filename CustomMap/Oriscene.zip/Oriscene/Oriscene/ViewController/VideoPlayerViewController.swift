//
//  VideoPlayerViewController.swift
//  Oriscene
//
//  Created by Tristate on 12/19/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit


class VideoPlayerViewController: BaseViewController,YTPlayerViewDelegate {
    
    
    @IBOutlet weak var ytPlayerView: YTPlayerView!
    var  strVideoLink : NSString?
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    // MARK: - View Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        playYoutubeVideo()
        appDelegate.menuView?.isHidden = true
    }
    override func viewDidAppear(_ animated: Bool) {
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        changeToPotraitMode()
        appDelegate.menuView?.isHidden = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Button Click Actions
    @IBAction func btnBackClickAction(_ sender: Any) {
        self.navigationController!.popViewController(animated: true)
    }
    
    // MARK: - YT Player Methods
    func playYoutubeVideo() -> Void{
        showSpinner(enableInteraction: true)
        ytPlayerView.delegate = self
        ytPlayerView.load(withVideoId: strVideoLink as! String)
    }
    
    func playerViewDidBecomeReady(_ playerView: YTPlayerView) {
        hideSpinner()
        //Allow rotation for this viewcontroller only
        
        appDelegate.shouldRotate = true // or false to disable rotation
    }
    
    func playerView(_ playerView: YTPlayerView, didChangeTo state: YTPlayerState) {
        //modify based on satae if required
    }
    func playerView(_ playerView: YTPlayerView, receivedError error: YTPlayerError) {
        //display if any error
    }
    
    // MARK: - Rotation Methods
    func changeToPotraitMode() -> Void {
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.shouldRotate = false //  false to disable rotation
    }
    
}

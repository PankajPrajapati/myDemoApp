//
//  EcommerceAgreementViewController.swift
//  Oriscene
//
//  Created by Parth on 22/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class EcommerceAgreementViewController: BaseViewController, UIWebViewDelegate {
    
    var dictPostDtl = Dictionary<String,Any>()
    var dictCreatePostData = NSMutableDictionary()
    var dictEcommerceAgreement = Dictionary<String,Any>()
    
    var isFromCreatePost : Bool = false
    var isFromBidVC : Bool = false
    var service = WebService()
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblSubTitle: UILabel!
    
    @IBOutlet var webView: UIWebView!
    @IBOutlet var viewBottom: UIView!
    
    @IBOutlet var btnAgreeTermsAndConditions: UIButton!
    @IBOutlet var btnCheckBoxESign: UIButton!
    
    @IBOutlet var btnFinish: UIButton!
    @IBOutlet var btnCancel: UIButton!
    
    // MARK: - UIView Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setUpUI()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    func setUpUI() -> Void {
        btnFinish.layer.cornerRadius = 3.0
        btnFinish.layer.masksToBounds = true
        
        btnCancel.layer.cornerRadius = 3.0
        btnCancel.layer.masksToBounds = true
        
        webView.delegate = self
        
        if isFromCreatePost {
            btnFinish.setTitle("POST",for: .normal)
            let strAgreement = dictEcommerceAgreement["data"] as! String
            webView.loadHTMLString(strAgreement, baseURL: nil)
        }
        else if isFromBidVC {
            let postId = dictPostDtl["post_id"] as! String;
            callWebserviceGenerateEcommerce(strPostId: postId)
        }
        else
        {   let postId = dictPostDtl["post_id"] as! String;
            callWebserviceGenerateEcommerce(strPostId: postId)
        }
    }
    
    // MARK: - Action Method
    @IBAction func btnFinishAction(_ sender: Any) {
        if !btnAgreeTermsAndConditions.isSelected {
            showAlert(string: Constant.ALERT_MSG_TERMS_AND_CONDITIONS_VALIDATE)
            return
        }
        
        if !btnCheckBoxESign.isSelected {
            showAlert(string: Constant.ALERT_MSG_ESIGN_VALIDATE)
            return
        }
        
        if isFromCreatePost {
            //call webservice here
            callWebserviceCreatePost()
        }
        else{
            let paymentVC : PaymentDetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "PaymentDetailViewController") as! PaymentDetailViewController
            paymentVC.dictPostDtl = dictPostDtl
            paymentVC.isFromBidVC = self.isFromBidVC
            paymentVC.dictEcommerceAgreement = self.dictEcommerceAgreement
            self.navigationController?.pushViewController(paymentVC, animated: true)
        }
    }
    @IBAction func btnCancelAction(_ sender: Any) {
        self.navigationController!.popViewController(animated: true)
    }
    @IBAction func btnCheckBoxESignAction(_ sender: Any) {
        btnCheckBoxESign.isSelected = !btnCheckBoxESign.isSelected
    }
    @IBAction func btnAgreeTermsAndConditionsAction(_ sender: Any) {
        btnAgreeTermsAndConditions.isSelected = !btnAgreeTermsAndConditions.isSelected
    }
    
    // MARK: - UIWebViewDelegate
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        self.showSpinner(enableInteraction: true)
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        self.hideSpinner()
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        self.hideSpinner()
    }
    // MARK: - Webservice methods
    func callWebserviceCreatePost() -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            service.callJSONMethod(methodName: "createPost", parameters: dictCreatePostData, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.showAlert(string: dict?["message"] as! String)
                        //redirect to home and load new data here.
                        for (_, element) in (self.navigationController?.viewControllers.enumerated())!{
                            if element.isKind(of: HomeViewController.self) {
                                let vc = element as! HomeViewController
                                vc.reloadPostData()
                                self.navigationController!.popToViewController(vc, animated: true)
                                return
                            }
                        }
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - Webservice methods
    func callWebserviceGenerateEcommerce(strPostId : String) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = strPostId
            if isFromBidVC {
                dictParam["bidId"] = dictPostDtl["c_id"] as! String
            }
            service.callJSONMethod(methodName: "generate_ecommerce", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.dictEcommerceAgreement = dict!
                        let strAgreement = self.dictEcommerceAgreement["message"] as! String
                        self.webView.loadHTMLString(strAgreement, baseURL: nil)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                        self.navigationController!.popViewController(animated: true)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

//
//  BasicInformationViewController.swift
//  Oriscene
//
//  Created by Parth on 22/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class BasicInformationViewController: BaseViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate, UITextFieldDelegate {
    
    var isCoverPhoto: Bool = false
    var service = WebService()
    var isProfilePicChange: Bool = false
    var isPopAllowed = false
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var viewContent: UIView!
    @IBOutlet var viewProfilePicContainer: UIView!
    @IBOutlet var viewLayer1: UIView!
    @IBOutlet var viewLayer2: UIView!
    @IBOutlet var imgProfilePic: UIImageView!
    @IBOutlet var btnProfilePic: UIButton!
    @IBOutlet var lblProfilePic: UILabel!
    @IBOutlet var viewSothingAboutYouContainer: UIView!
    @IBOutlet var txtViewSomethingAboutYou: UITextView!
    @IBOutlet var viewUsernameContainer: UIView!
    @IBOutlet var imgUserName: UIImageView!
    @IBOutlet var txtUserName: UITextField!
    @IBOutlet var btnUserNameInsteadOfName: UIButton!
    @IBOutlet var viewDOBContainer: UIView!
    @IBOutlet var imgDOB: UIImageView!
    @IBOutlet var txtDOB: UITextField!
    @IBOutlet var imgCalender: UIImageView!
    @IBOutlet var viewDeactivateAccountContainer: UIView!
    @IBOutlet var switchDeactivateAccount: UISwitch!
    @IBOutlet var btnUpdate: UIButton!
    @IBOutlet var viewRadious: [UIView]!
    
    @IBOutlet var viewInputAccessory: UIView!
    @IBOutlet var btnDoneInputAcceesory: UIButton!
    @IBOutlet var viewDatePickerContainer: UIView!
    @IBOutlet var viewDateContainerPickerHeader: UIView!
    @IBOutlet var btnCancelDate: UIButton!
    @IBOutlet var btnSelectDate: UIButton!
    
    @IBOutlet var datePicker: UIDatePicker!
    @IBOutlet var viewTransparent: UIView!
    @IBOutlet var btnChangeCover: UIButton!
    @IBOutlet var imgCoverPhoto: UIImageView!
    
    // MARK: - Constrant Outlet
    @IBOutlet var bottomConstScrollView: NSLayoutConstraint!
    @IBOutlet weak var btnBack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setupUI()
        setUserData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstScrollView?.constant = 0.0
            } else {
                self.bottomConstScrollView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
            if (self.txtViewSomethingAboutYou.isFirstResponder) {
                self.scrollView.scrollRectToVisible(viewSothingAboutYouContainer.frame, animated: true)
            }
        }
    }
    // MARK: - Custom Method
    
    func setupUI(){
        
        viewInputAccessory.layer.borderColor = UIColor.lightGray.cgColor
        viewInputAccessory.layer.borderWidth = 1.0
        
        viewDateContainerPickerHeader.layer.borderColor = UIColor.lightGray.cgColor
        viewDateContainerPickerHeader.layer.borderWidth = 1.0
        
        txtViewSomethingAboutYou.inputAccessoryView = viewInputAccessory
        txtDOB.inputView = viewDatePickerContainer
        
        viewTransparent.isHidden = true
        
        self.view.layoutIfNeeded()
        viewLayer1.layer.masksToBounds = true
        viewLayer1.layer.cornerRadius = CGFloat(viewLayer1.frame.size.height/2)
        viewLayer2.layer.masksToBounds = true
        viewLayer2.layer.cornerRadius = CGFloat(viewLayer2.frame.size.height/2)
        imgProfilePic.layer.masksToBounds = true
        imgProfilePic.layer.cornerRadius = CGFloat(imgProfilePic.frame.size.height/2)
        btnUpdate.layer.cornerRadius = 3.0
        btnUpdate.layer.masksToBounds = true
        
        for (_, element) in viewRadious.enumerated() {
            element.layer.cornerRadius = 5.0
            element.layer.masksToBounds = true
            element.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
            element.layer.borderWidth = 0.5
        }
    }
    
    func setUserData() -> Void {
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            let deactiveStatus = dictUser["deactive_status"] as! String
            if deactiveStatus == "yes" {
                switchDeactivateAccount.setOn(true, animated: false)
                btnBack.isHidden = true
            }else {
                switchDeactivateAccount.setOn(false, animated: false)
                btnBack.isHidden = false
            }
            txtUserName.text = (dictUser["reporter_name"] as! String)
            txtDOB.text = (dictUser["dob"] as! String)
            let dateString = (dictUser["dob"] as! String)
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date = dateFormatter.date(from: dateString)
            datePicker.date = date!
            
            lblProfilePic.isHidden = true
            btnProfilePic.setImage(nil, for: UIControlState.normal)
            imgProfilePic.clipsToBounds = true
            imgProfilePic.contentMode = UIViewContentMode.redraw
            
            if dictUser.keys.contains("overview") {
                let overview = dictUser["overview"] as! String
                if overview.characters.count > 0 {
                    txtViewSomethingAboutYou.text = overview
                }
                else{
                    txtViewSomethingAboutYou.text = "Something about you"
                }
            }
            
            if dictUser.keys.contains("usenickname") {
                let usenickname = dictUser["usenickname"] as! String
                if usenickname == "1" {
                    btnUserNameInsteadOfName.isSelected = true
                }
                else{
                    btnUserNameInsteadOfName.isSelected = false
                }
            }
            
            if dictUser.keys.contains("photo") {
                let strPhotoName = dictUser["photo"] as! String
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictUser["photo"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    imgProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    imgProfilePic.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                imgProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
            
            if dictUser.keys.contains("cover_img") {
                let strPhotoName = dictUser["cover_img"] as! String
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictUser["cover_img"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    imgCoverPhoto.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    imgCoverPhoto.image = nil
                }
            }
            else{
                imgCoverPhoto.image = nil
            }
        }
    }
    
    func getDataFromUrl(url: URL, completion: @escaping (_ data: Data?, _  response: URLResponse?, _ error: Error?) -> Void) {
        URLSession.shared.dataTask(with: url) {
            (data, response, error) in
            completion(data, response, error)
            }.resume()
    }
    
    func downloadImage(url: URL) {
        print("Download Started")
        getDataFromUrl(url: url) { (data, response, error)  in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download Finished")
            DispatchQueue.main.async() { () -> Void in
                self.imgProfilePic.image = UIImage(data: data)
            }
        }
    }
    
    // MARK: - Action Method
    @IBAction func btnUserNameInsteadOfOriginalNameAction(_ sender: Any) {
        btnUserNameInsteadOfName.isSelected = !btnUserNameInsteadOfName.isSelected
    }
    @IBAction func btnUpdateAction(_ sender: Any) {
        
        if txtViewSomethingAboutYou.text == "Something about you" {
            self.showAlert(string: Constant.ALERT_MSG_SOMETHING_ABOUT_YOU_VALIDATE)
            return
        }
        
        if isProfilePicChange {
            self.callWebserviceToUpdateProfileWithImage()
        }
        else{
            self.callWebserviceToUpdateProfileWithoutImage()
        }
    }
    
    @IBAction func btnProfilePicAction(_ sender: AnyObject) {
        self.selectImage()
    }
    
    @IBAction func btnDoneInputAcceesoryAction(_ sender: Any) {
        txtViewSomethingAboutYou .resignFirstResponder()
        if txtViewSomethingAboutYou.text.characters.count>0 {
        }
        else{
            txtViewSomethingAboutYou.text = "Something about you"
        }
    }
    
    @IBAction func btnSelectDateAction(_ sender: Any) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: datePicker.date)
        txtDOB.text = dateString
        txtDOB.resignFirstResponder()
        viewTransparent.isHidden = true
    }
    @IBAction func btnCancelDateAction(_ sender: Any) {
        txtDOB .resignFirstResponder()
        viewTransparent.isHidden = true
    }
    
    @IBAction func btnChangeCoverImageAction(_ sender: Any) {
        isCoverPhoto = true
        self.selectImage()
    }
    
    @IBAction func switchDeactiveAccountValueChanged(_ sender: Any) {
        callWebserviceDeactiveAccount()
    }
    
    override func btnBackAction(_ sender: AnyObject) {
        
        if isPopAllowed {
            self.navigationController!.popViewController(animated: true)
            return
        }else{
            let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            homeVC.currentPostType = CurrentSelectedPostType.BOTH.rawValue
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.menuView?.intSelectedRow = MenuIndex.HOME.rawValue
            appDelegate.menuView?.reloadDataForMenu()
            self.navigationController?.setViewControllers([homeVC], animated: true)
        }
    }
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField .resignFirstResponder()
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        viewTransparent.isHidden = true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == txtDOB {
            viewTransparent.isHidden = false
        }
        
        return true
    }
    
    // MARK: - UITextViewDelegate
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        if txtViewSomethingAboutYou.text == "Something about you" {
            txtViewSomethingAboutYou.text = ""
            textView.textColor = UIColor.black
        }
        
        return true
    }
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        
        if txtViewSomethingAboutYou.text.characters.count>0 {
            textView.textColor = UIColor.black
        }
        else{
            txtViewSomethingAboutYou.text = "Something about you"
            textView.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        }
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        
        let length = textView.text.characters.count as Int
        
        if length > 0 {
            textView.textColor = UIColor.black
        }
        else{
            textView.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        
    }
    
    // MARK: - Select Image
    
    func selectImage() {
        
        let alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openCamera()
        }
        let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openGallary()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
        }
        
        // Add the actions
        
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func openCamera()
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            picker.sourceType = UIImagePickerControllerSourceType.camera
            picker.allowsEditing = true
            self .present(picker, animated: true, completion: nil)
        }
        else
        {
            let alertWarning = UIAlertView(title: "Warning", message: "You don't have camera", delegate: nil, cancelButtonTitle: "OK")
            alertWarning.show()
        }
    }
    func openGallary()
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        picker.allowsEditing = true
        self.present(picker, animated: true, completion: nil)
    }
    
    // MARK: - PickerView Delegate Methods
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        picker .dismiss(animated: true, completion: nil)
        
        if isCoverPhoto {
            imgCoverPhoto.image=info[UIImagePickerControllerEditedImage] as? UIImage
            callWebserviceForUploadCoverImage()
        }
        else{
            isProfilePicChange = true
            imgProfilePic.image=info[UIImagePickerControllerEditedImage] as? UIImage
            lblProfilePic.isHidden = true
            btnProfilePic.setImage(nil, for: UIControlState.normal)
        }
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        isCoverPhoto = false
        picker .dismiss(animated: true, completion: nil)
        print("picker cancel.")
    }
    
    // MARK: - Call Webservice
    
    func callWebserviceForUploadCoverImage() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            var imageData = NSData()
            if (imgCoverPhoto.image != nil) {
                dictParam["profilePic"] = "profilePic";
                imageData = (UIImagePNGRepresentation(imgCoverPhoto.image!) as NSData?)!
            }
            DispatchQueue.main.async {
                self.showSpinner(enableInteraction: false)
            }
            service.callJSONMethod(methodName: "setCoverImg", imageData: imageData as NSData?, attachmentKey: "profilePic", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse:  { (_ dict:Dictionary<String, Any>?) in
                DispatchQueue.main.async {
                    self.hideSpinner()
                }
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        let userDefault = UserDefaults.standard
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                    }
                    else  {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                DispatchQueue.main.async {
                    self.hideSpinner()
                }
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            }, onProgressResponse: { (_ progress:Float?) in
                print(progress ?? "")
            })
            
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceToUpdateProfileWithoutImage() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            dictParam["overView"] = self.txtViewSomethingAboutYou.text
            if btnUserNameInsteadOfName.isSelected {
                dictParam["useNickName"] = "1"
            }
            else{
                dictParam["useNickName"] = "0"
            }
            
            dictParam["dob"] = self.txtDOB.text
            dictParam["forWhat"] = "1"
            
            DispatchQueue.main.async {
                self.showSpinner(enableInteraction: false)
            }
            
            service.callJSONMethod(methodName: "updateProfile", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                DispatchQueue.main.async {
                    self.hideSpinner()
                }
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        let userDefault = UserDefaults.standard
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        self.navigationController!.popViewController(animated: true)
                    }
                    else  {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                DispatchQueue.main.async {
                    self.hideSpinner()
                }
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            })
            
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceToUpdateProfileWithImage() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            var imageData = NSData()
            if (imgProfilePic.image != nil) {
                dictParam["profilePic"] = "profilePic";
                imageData = (UIImagePNGRepresentation(imgProfilePic.image!) as NSData?)!
            }
            
            dictParam["overView"] = self.txtViewSomethingAboutYou.text
            if btnUserNameInsteadOfName.isSelected {
                dictParam["useNickName"] = "1"
            }
            else{
                dictParam["useNickName"] = "0"
            }
            
            dictParam["dob"] = self.txtDOB.text
            dictParam["forWhat"] = "1"
            
            DispatchQueue.main.async {
                self.showSpinner(enableInteraction: false)
            }
            
            service.callJSONMethod(methodName: "updateProfile", imageData: imageData as NSData?, attachmentKey: "profilePic", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse:  { (_ dict:Dictionary<String, Any>?) in
                DispatchQueue.main.async {
                    self.hideSpinner()
                }
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        let userDefault = UserDefaults.standard
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        self.navigationController!.popViewController(animated: true)
                    }
                        // else if dict?["status"] as! String == "0" {
                    else  {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                DispatchQueue.main.async {
                    self.hideSpinner()
                }
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            }, onProgressResponse: { (_ progress:Float?) in
                print(progress ?? "")
            })
            
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceDeactiveAccount() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            if userDefault.keys.contains("userData") {
                //switchDeactivateAccount.setOn(false, animated: false)
                let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
                dictParam["deactiveStatus"] = dictUser["deactive_status"] as! String
            }
            
            DispatchQueue.main.async {
                self.showSpinner(enableInteraction: false)
            }
            
            service.callJSONMethod(methodName: "updateUserStatus", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                DispatchQueue.main.async {
                    self.hideSpinner()
                }
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        let userDefault = UserDefaults.standard
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        userDefault.synchronize()
                        let deActiveStatus = dictData["deactive_status"] as! String
                        if deActiveStatus == "yes" {
                            //hide back button
                            self.btnBack.isHidden = true
                        }else{
                            self.btnBack.isHidden = false
                        }
                    }
                    else {
                        self.switchDeactivateAccount.setOn(!self.switchDeactivateAccount.isOn, animated: true)
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                DispatchQueue.main.async {
                    self.hideSpinner()
                }
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
                self.switchDeactivateAccount.setOn(!self.switchDeactivateAccount.isOn, animated: true)
            })
            
        }
        else{
            self.showNoNetworkAlert()
            self.switchDeactivateAccount.setOn(!self.switchDeactivateAccount.isOn, animated: true)
        }
    }
    
    func setActiveDeActiveData() -> Void {
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            let deactiveStatus = dictUser["deactive_status"] as! String
            if deactiveStatus == "yes" {
                switchDeactivateAccount.setOn(true, animated: false)
                btnBack.isHidden = true
            }else {
                switchDeactivateAccount.setOn(false, animated: false)
                btnBack.isHidden = false
            }
            
        }
    }
}

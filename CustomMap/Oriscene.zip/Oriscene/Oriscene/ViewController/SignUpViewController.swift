//
//  SignUpViewController.swift
//  Oriscene
//
//  Created by Parth on 07/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

extension UIToolbar {
    
    func ToolbarDOBPiker(mySelect : Selector) -> UIToolbar {
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.barTintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        doneButton.tintColor = UIColor.white
        //        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        return toolBar
    }
    
}

class SignUpViewController: BaseViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, UIAlertViewDelegate {
    var service = WebService()
    var dictFBData : NSDictionary?
    var isFromFacebook = false
    var arrCountry = [ Dictionary<String,String>]()
    var arrCountryBackup = [ Dictionary<String,String>]()
    var arrState = [ Dictionary<String,String>]()
    var arrStateBackup = [ Dictionary<String,String>]()
    var dictCountry = Dictionary<String,String>()
    var dictState = Dictionary<String,String>()
    
    // MARK: - Control OutLet
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var btnBack: UIButton!
    
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var viewContent: UIView!
    @IBOutlet var viewProfilePicContainer: UIView!
    @IBOutlet var viewLayer1: UIView!
    @IBOutlet var viewLayer2: UIView!
    @IBOutlet var imgProfilePic: UIImageView!
    @IBOutlet var btnProfilePic: UIButton!
    @IBOutlet var lblProfilePic: UILabel!
    
    @IBOutlet var viewRadious: [UIView]!
    @IBOutlet var imgFirstName: UIImageView!
    @IBOutlet var txtFirstName: UITextField!
    @IBOutlet var imgLastName: UIImageView!
    @IBOutlet var txtLastName: UITextField!
    @IBOutlet var imgGender: UIImageView!
    @IBOutlet var btnMale: UIButton!
    @IBOutlet var btnFemale: UIButton!
    @IBOutlet var imgEmail: UIImageView!
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var imgPassword: UIImageView!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var imgRepeatPassword: UIImageView!
    @IBOutlet var txtRepeatPassword: UITextField!
    @IBOutlet var imgCountry: UIImageView!
    @IBOutlet var lblCountry: UILabel!
    @IBOutlet var btnCountry: UIButton!
    @IBOutlet var imgState: UIImageView!
    @IBOutlet var lblState: UILabel!
    @IBOutlet var btnState: UIButton!
    @IBOutlet var imgZipcode: UIImageView!
    @IBOutlet var txtZipcode: UITextField!
    
    @IBOutlet var imgUserName: UIImageView!
    @IBOutlet var txtUserName: UITextField!
    
    @IBOutlet var imgDOB: UIImageView!
    @IBOutlet var txtDOB: UITextField!
    @IBOutlet var imgCalender: UIImageView!
    @IBOutlet var txtCaptcha: UITextField!
    @IBOutlet var viewCaptchaContainer: UIView!
    @IBOutlet var btnRefreshCaptcha: UIButton!
    @IBOutlet var viewBottom: UIView!
    @IBOutlet var btnCheckTermAndCondition: UIButton!
    @IBOutlet var btnTermsAndConditions: UIButton!
    @IBOutlet var btnSignUp: UIButton!
    @IBOutlet var btnLogin: UIButton!
    
    @IBOutlet var viewCountryList: UIView!
    @IBOutlet var viewStateList: UIView!
    
    @IBOutlet var tblStateList: UITableView!
    @IBOutlet var tblCountryList: UITableView!
    
    @IBOutlet var txtCountry: UITextField!
    @IBOutlet var txtState: UITextField!
    @IBOutlet var lblCaptcha: UILabel!
    
    let datePickerView:UIDatePicker = UIDatePicker()
    
    // MARK: - Constrant Outlet
    @IBOutlet var bottomConstScrollView: NSLayoutConstraint!
    @IBOutlet var heightConstCountryList: NSLayoutConstraint!
    @IBOutlet var heightConstStateList: NSLayoutConstraint!
    
    // MARK: - UIView Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        lblCaptcha.text = generateCaptch()
        callWebserviceforGettingCountry()
        self.setupUI()
        if isFromFacebook {
            setupDataOfFacebook()
        }
        // Do any additional setup after loading the view.
        
        datePickerView.datePickerMode = UIDatePickerMode.date
        datePickerView.addTarget(self, action: #selector(datePickerChanged(sender:)), for: .valueChanged)
        let toolBar = UIToolbar().ToolbarDOBPiker(mySelect: #selector(self.dismissPicker))
        
        let gregorian: NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
        let currentDate: NSDate = NSDate()
        let components: NSDateComponents = NSDateComponents()
        
        components.year = -150
        let minDate: NSDate = gregorian.date(byAdding: components as DateComponents, to: currentDate as Date, options: NSCalendar.Options(rawValue: 0))! as NSDate
        
        //        components.year = -100
        //        let maxDate: NSDate = gregorian.date(byAdding: components as DateComponents, to: currentDate as Date, options: NSCalendar.Options(rawValue: 0))! as NSDate
        
        self.datePickerView.minimumDate = minDate as Date
        self.datePickerView.maximumDate = Date()
        
        txtDOB.inputView = datePickerView
        txtDOB.inputAccessoryView = toolBar
        
        txtZipcode.inputAccessoryView = toolBar
        
        btnCountry.isUserInteractionEnabled = true
        btnState.isUserInteractionEnabled = true
        
        lblCaptcha.layer.shadowColor = UIColor.black.cgColor
        lblCaptcha.layer.shadowOpacity = 1
        lblCaptcha.layer.shadowOffset = CGSize.zero
        lblCaptcha.layer.shadowRadius = 10
        lblCaptcha.layer.shouldRasterize = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstScrollView?.constant = 0.0
                //                self.scrollView.setContentOffset(CGPoint(x: 0.0, y: 0.0), animated: true)
            } else {
                
                self.bottomConstScrollView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - Custom Method
    
    func setupUI(){
        
        tblCountryList.register(CountryStateListTVCell.self, forCellReuseIdentifier: "CountryStateListTVCell")
        tblCountryList.register(UINib.init(nibName: "CountryStateListTVCell", bundle: nil), forCellReuseIdentifier: "CountryStateListTVCell")
        
        tblStateList.register(CountryStateListTVCell.self, forCellReuseIdentifier: "CountryStateListTVCell")
        tblStateList.register(UINib.init(nibName: "CountryStateListTVCell", bundle: nil), forCellReuseIdentifier: "CountryStateListTVCell")
        
        self.view.layoutIfNeeded()
        viewLayer1.layer.masksToBounds = true
        viewLayer1.layer.cornerRadius = CGFloat(viewLayer1.frame.size.height/2)
        viewLayer2.layer.masksToBounds = true
        viewLayer2.layer.cornerRadius = CGFloat(viewLayer2.frame.size.height/2)
        imgProfilePic.layer.masksToBounds = true
        imgProfilePic.layer.cornerRadius = CGFloat(imgProfilePic.frame.size.height/2)
        
        btnSignUp.layer.cornerRadius = 3.0
        btnSignUp.layer.masksToBounds = true
        
        for (_, element) in viewRadious.enumerated() {
            element.layer.cornerRadius = 5.0
            element.layer.masksToBounds = true
            element.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
            element.layer.borderWidth = 0.5
        }
        
        viewCountryList.isHidden = true
        viewStateList.isHidden = true
        heightConstCountryList.constant = 0.0
        heightConstStateList.constant = 0.0
        
        btnCountry.isUserInteractionEnabled = false
        btnState.isUserInteractionEnabled = false
        
        viewCountryList.layer.borderWidth = 2.0
        viewCountryList.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewCountryList.layer.cornerRadius = 3.0
        viewCountryList.layer.shadowColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewCountryList.layer.shadowOpacity = 1.0
        viewCountryList.layer.shadowOffset = CGSize.zero
        viewCountryList.layer.shadowRadius = 5.0
        
        viewStateList.layer.borderWidth = 2.0
        viewStateList.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewStateList.layer.cornerRadius = 3.0
        viewStateList.layer.shadowColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewStateList.layer.shadowOpacity = 1.0
        viewStateList.layer.shadowOffset = CGSize.zero
        viewStateList.layer.shadowRadius = 5.0
    }
    
    func setupDataOfFacebook() {
        
        if dictFBData?["picture"] != nil {
            print(dictFBData ?? "")
            let dictPicture : NSDictionary = dictFBData?["picture"] as! NSDictionary
            let dictData : NSDictionary = dictPicture["data"] as! NSDictionary
            let fileUrl = NSURL(string: dictData["url"] as! String)
            self.imgProfilePic.sd_setImage(with: fileUrl as URL!)
            lblProfilePic.isHidden = true
            btnProfilePic.setImage(nil, for: UIControlState.normal)
        }
        
        txtEmail.text = dictFBData?["email"] as? String;
        
        let dict = (dictFBData as! Dictionary<String, Any>)
        if dict.keys.contains("email") {
            txtEmail.isEnabled = false;
        }
        else{
            txtEmail.isEnabled = true;
        }
        txtFirstName.text = dictFBData?["first_name"] as? String;
        txtFirstName.isEnabled = false;
        
        txtLastName.text = dictFBData?["last_name"] as? String;
        txtLastName.isEnabled = false;
        
        if dictFBData?["gender"] as? String == "male" {
            btnMale.isSelected = true;
            btnFemale.isSelected = false;
            btnMale.isUserInteractionEnabled = false;
            btnFemale.isUserInteractionEnabled = false;
        }
        else if dictFBData?["gender"] as? String == "female"{
            btnMale.isSelected = false;
            btnFemale.isSelected = true;
            btnMale.isUserInteractionEnabled = false;
            btnFemale.isUserInteractionEnabled = false;
        }
        else{
            btnMale.isSelected = false;
            btnFemale.isSelected = false;
            btnMale.isUserInteractionEnabled = true;
            btnFemale.isUserInteractionEnabled = true;
        }
        
    }
    
    // MARK: - Action Method
    //    @IBAction func btnBackAction(_ sender: AnyObject) {
    //        self.navigationController!.popViewController(animated: true)
    //    }
    @IBAction func btnProfilePicAction(_ sender: AnyObject) {
        self.selectImage()
    }
    
    @IBAction func btnMaleAction(_ sender: AnyObject) {
        btnMale.isSelected = true
        btnFemale.isSelected = false
    }
    @IBAction func btnFemaleAction(_ sender: AnyObject) {
        btnMale.isSelected = false
        btnFemale.isSelected = true
    }
    @IBAction func btnCountryAction(_ sender: AnyObject) {
        txtCountry.becomeFirstResponder()
    }
    @IBAction func btnStateAction(_ sender: AnyObject) {
        txtState.becomeFirstResponder()
    }
    @IBAction func btnRefreshCaptchaAction(_ sender: AnyObject) {
        lblCaptcha.text = generateCaptch()
    }
    @IBAction func btnLoginAction(_ sender: AnyObject) {
        self.navigationController!.popViewController(animated: true)
    }
    @IBAction func btnSignUpAction(_ sender: AnyObject) {
        
        if validateProfileData() {
            if isFromFacebook {
                callWebserviceSignupFacebook()
            }
            else{
                callWebserviceSignupManually()
            }
        }
    }
    @IBAction func btnTermsAndConditionsAction(_ sender: AnyObject) {
        
        let vcAboutUS = self.storyboard?.instantiateViewController(withIdentifier: "AboutUsViewController") as! AboutUsViewController
        vcAboutUS.isForTermsAndConditions = true
        self.navigationController?.present(vcAboutUS, animated: true, completion: nil)
    }
    @IBAction func btnCheckTermsAndConditionsAction(_ sender: AnyObject) {
        btnCheckTermAndCondition.isSelected = !sender.isSelected;
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        
        if textField == txtCountry {
            viewCountryList.isHidden = true
            heightConstCountryList.constant = 0.0
            self.view.updateConstraintsIfNeeded()
        }
        else if textField == txtState {
            viewStateList.isHidden = true
            heightConstStateList.constant = 0.0
            self.view.updateConstraintsIfNeeded()
        }
        else{
        }
        
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == txtCountry {
            let point = CGPoint.init(x: 0.0, y: viewCountryList.frame.origin.y - 50.0)
            self.perform(#selector(setContentOffsetForList(point:)), with:point , afterDelay: 0.5)
            viewCountryList.isHidden = false
            viewStateList.isHidden = true
            
            heightConstStateList.constant = 0.0
            
            let searchString = txtCountry.text
            
            
            if searchString != "" {
                let predicate = NSPredicate(format: "name contains[cd] %@", searchString!)
                arrCountry = arrCountryBackup.filter { predicate.evaluate(with: $0) }
            }
            else{
                arrCountry = arrCountryBackup;
            }
            if arrCountry.count > 3 {
                heightConstCountryList.constant = 135.0
                self.view.updateConstraintsIfNeeded()
                viewCountryList.isHidden = false
            }
            else{
                heightConstCountryList.constant =  CGFloat(44*arrCountry.count)
                self.view.updateConstraintsIfNeeded()
            }
            
            tblCountryList.reloadData()
        }
        else if textField == txtState {
            let point = CGPoint.init(x: 0.0, y: viewStateList.frame.origin.y - 50.0)
            self.perform(#selector(setContentOffsetForList(point:)), with:point , afterDelay: 0.5)
            viewCountryList.isHidden = true
            viewStateList.isHidden = false
            heightConstCountryList.constant = 0.0
            
            let searchString = txtState.text
            if searchString != "" {
                let predicate = NSPredicate(format: "name contains[cd] %@", searchString!)
                arrState = arrStateBackup.filter { predicate.evaluate(with: $0) }
            }
            else{
                arrState = arrStateBackup;
            }
            if arrState.count > 3 {
                heightConstStateList.constant = 135.0
                self.view.updateConstraintsIfNeeded()
            }
            else{
                heightConstStateList.constant = CGFloat(44*arrState.count)
                self.view.updateConstraintsIfNeeded()
            }
            tblStateList.reloadData()
        }
        else{
            viewCountryList.isHidden = true
            viewStateList.isHidden = true
            heightConstCountryList.constant = 0.0
            heightConstStateList.constant = 0.0
            self.view.updateConstraintsIfNeeded()
        }
        
        return true
    }
    
    func setContentOffsetForList(point : CGPoint) -> Void {
        scrollView.setContentOffset(CGPoint.init(x: 0.0, y: viewCountryList.frame.origin.y - 50.0), animated: true)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == txtCountry {
            
            var searchString = txtCountry.text
            
            if string == "" && range.location == 0 {
                searchString = ""
            }
            if searchString != "" {
                let predicate = NSPredicate(format: "name contains[cd] %@", searchString!)
                arrCountry = arrCountryBackup.filter { predicate.evaluate(with: $0) }
            }
            else{
                arrCountry = arrCountryBackup;
            }
            if arrCountry.count > 3 {
                heightConstCountryList.constant = 135.0
                viewCountryList.updateConstraintsIfNeeded()
                viewCountryList.layoutIfNeeded()
                self.view.updateConstraintsIfNeeded()
            }
            else{
                heightConstCountryList.constant =  CGFloat(44*arrCountry.count)
                viewCountryList.updateConstraintsIfNeeded()
                viewCountryList.layoutIfNeeded()
                self.view.updateConstraintsIfNeeded()
            }
            tblCountryList.reloadData()
            arrState = [ Dictionary<String,String>]()
            arrStateBackup = [ Dictionary<String,String>]()
            dictState = Dictionary<String,String>()
            txtState.text = ""
            
        }
        else if textField == txtState {
            
            let searchString = txtState.text
            if searchString != "" {
                let predicate = NSPredicate(format: "name contains[cd] %@", searchString!)
                arrState = arrStateBackup.filter { predicate.evaluate(with: $0) }
            }
            else{
                arrState = arrStateBackup;
            }
            
            if arrState.count > 3 {
                heightConstStateList.constant = 135.0
                self.view.updateConstraintsIfNeeded()
            }
            else{
                heightConstStateList.constant = CGFloat(44*arrState.count)
                self.view.updateConstraintsIfNeeded()
            }
            
            tblStateList.reloadData()
            
        }
        else{
        }
        
        return true
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent //or default
    }
    
    // MARK: - Select Image
    
    func selectImage() {
        
        let alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openCamera()
        }
        let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openGallary()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
        }
        
        // Add the actions
        
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func openCamera()
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            picker.sourceType = UIImagePickerControllerSourceType.camera
            picker.allowsEditing = true
            self .present(picker, animated: true, completion: nil)
        }
        else
        {
            let alertWarning = UIAlertView(title: "Warning", message: "You don't have camera", delegate: nil, cancelButtonTitle: "OK")
            alertWarning.show()
        }
    }
    func openGallary()
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        picker.allowsEditing = true
        self.present(picker, animated: true, completion: nil)
    }
    
    // MARK: - PickerView Delegate Methods
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        picker .dismiss(animated: true, completion: nil)
        imgProfilePic.image=info[UIImagePickerControllerEditedImage] as? UIImage
        lblProfilePic.isHidden = true
        btnProfilePic.setImage(nil, for: UIControlState.normal)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker .dismiss(animated: true, completion: nil)
        print("picker cancel.")
    }
    
    // MARK: - Captach Generation Custom Methods
    func generateCaptch() -> String {
        
        let letters = "ABCDEF012GHIJKL345MNOPQR678STUVWXYZ9".characters.map { String($0) }
        
        var strCaptcha = String()
        for index in 1...6 {
            
            let randomIndex = Int(arc4random_uniform(UInt32(letters.count)))
            let randomItem = letters[randomIndex]
            strCaptcha = strCaptcha + randomItem
            if index == 3
            {
                strCaptcha.append(" ");
            }
        }
        
        return strCaptcha
    }
    
    // MARK: - Webservice Calling Method
    func callWebserviceforGettingCountry() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            service.callJSONMethod(methodName: "getAllCountry", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrCountry = dict?["data"] as! [ Dictionary<String,String>]
                        self.arrCountryBackup = self.arrCountry
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                print(error as Any)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceforGettingState() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["cId"] = dictCountry["id"];
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getState", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrState = dict?["data"] as! Array
                        self.arrStateBackup = self.arrState
                        self.tblStateList.reloadData()
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
            })
            
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceSignupFacebook() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["username"] = txtUserName.text
            dictParam["email"] = txtEmail.text
            dictParam["location"] = dictCountry["id"]
            dictParam["zipcode"] = txtZipcode.text
            dictParam["dob"] = txtDOB.text
            dictParam["state"] = dictState["name"]
            
            if btnMale.isSelected {
                dictParam["gender"] = "male"
            }
            else if btnFemale.isSelected {
                dictParam["gender"] = "female"
            }
            
            dictParam["password"] = txtPassword.text
            
            var imageData = NSData()
            if (imgProfilePic.image != nil) {
                dictParam["profilePic"] = "profilePic";
                imageData = (UIImagePNGRepresentation(imgProfilePic.image!) as NSData?)!
            }
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertRemainingData", imageData:imageData as NSData? , attachmentKey: "profilePic",parameters: dictParam,isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        
                        if (dict?.keys.contains("data"))! {
                            let userDefault = UserDefaults.standard
                            
                            let dictData = dict?["data"] as! NSDictionary
                            let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                            for (_, element) in dictMutable.allKeys.enumerated() {
                                let tmpValue = dictMutable[element]
                                if (tmpValue is NSNull) {
                                    dictMutable[element] = ""
                                }
                            }
                            userDefault.set(dictMutable, forKey: "userData")
                        }
                        //                self.showAlert(string: dict?["message"] as! String)
                        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: dict?["message"] as? String , delegate: self, cancelButtonTitle: "OK")
                        alertWarning.tag = 1;
                        alertWarning.show()
                    }
                    else if dict?["status"] as! String == "2" {
                        let userDefault = UserDefaults.standard
                        
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        userDefault.set(dictMutable, forKey: "userData")
                        self.showAlert(string: dict?["message"] as! String)
                        let vcCategoryFirst = self.storyboard?.instantiateViewController(withIdentifier: "CategoryFirstViewController") as! CategoryFirstViewController
                        self.navigationController?.pushViewController(vcCategoryFirst, animated: true)
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            }, onProgressResponse: { (_ progress:Float?) in
                print(progress ?? "")
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceSignupManually() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["fName"] = txtFirstName.text
            dictParam["lName"] = txtLastName.text
            dictParam["username"] = txtUserName.text
            dictParam["email"] = txtEmail.text
            dictParam["location"] = dictCountry["id"]
            dictParam["zipcode"] = txtZipcode.text
            dictParam["dob"] = txtDOB.text
            dictParam["userId"] = ""
            dictParam["state"] = dictState["name"]
            
            if btnMale.isSelected {
                dictParam["gender"] = "male"
            }
            else if btnFemale.isSelected {
                dictParam["gender"] = "female"
            }
            
            dictParam["password"] = txtPassword.text
            
            var imageData = NSData()
            if (imgProfilePic.image != nil) {
                dictParam["profilePic"] = "profilePic";
                imageData = (UIImagePNGRepresentation(imgProfilePic.image!) as NSData?)!
            }
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "createNewUser", imageData:imageData as NSData? ,attachmentKey: "profilePic", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        self.navigationController!.popViewController(animated: true)
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            }, onProgressResponse: { (_ progress:Float?) in
                print(progress ?? "")
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - UITableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblCountryList {
            return arrCountry.count
        }
        else if tableView == tblStateList {
            return arrState.count
        }
        else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "CountryStateListTVCell") as! CountryStateListTVCell
        cell.tag = indexPath.row
        
        if tableView == tblCountryList {
            let dict = arrCountry[indexPath.row]
            cell.lblTitle.text = dict["name"]
        }
        else if tableView == tblStateList {
            let dict = arrState[indexPath.row]
            cell.lblTitle.text = dict["name"]
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44.0
    }
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tblCountryList {
            viewCountryList.isHidden = true
            heightConstCountryList .constant = 0.0
            viewCountryList.updateConstraintsIfNeeded()
            viewCountryList.layoutIfNeeded()
            self.view.updateConstraintsIfNeeded()
            dictCountry = arrCountry[indexPath.row]
            dictState = Dictionary<String,String>()
            txtState.text = ""
            txtCountry.text = dictCountry["name"]
            txtCountry.resignFirstResponder()
            callWebserviceforGettingState()
            
        }
        else if tableView == tblStateList {
            viewStateList.isHidden = true
            heightConstStateList .constant = 0.0
            self.view.updateConstraintsIfNeeded()
            dictState = arrState[indexPath.row]
            txtState.text = dictState["name"]
            txtState.resignFirstResponder()
        }
    }
    
    // MARK: - Validate Data
    
    func validateProfileData() -> Bool {
        
        if trimString(string: (txtFirstName.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_FIRSTNAME_VALIDATE)
            return false
        }
        if trimString(string: (txtLastName.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_LASTNAME_VALIDATE)
            return false
        }
        if btnMale.isSelected == false && btnFemale.isSelected == false {
            showAlert(string: Constant.ALERT_MSG_GENDER_VALIDATE)
            return false
        }
        if trimString(string: (txtEmail.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_EMAIL_VALIDATE)
            return false
        }
        if !self.isValidEmail(testStr: self.trimString(string:(txtEmail.text!))) {
            self.showAlert(string: Constant.ALERT_MSG_EMAIL_VALIDATE_FROMAT)
            return false
        }
        if trimString(string: (txtUserName.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_USERNAME_VALIDATE)
            return false
        }
        
        if isValidUsername(txtUserName.text!) == false {
            showAlert(string: Constant.ALERT_MSG_USERNAME_VALIDATE_FORMAT)
            return false
        }
        
        if trimString(string: (txtPassword.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_PASSWORD_VALIDATE)
            return false
        }
        
        if isValidPassword(txtPassword.text!) == false {
            showAlert(string: Constant.ALERT_MSG_PASSWORD_VALIDATE_FORMAT)
            return false
        }
        
        if trimString(string: (txtRepeatPassword.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_REPEAT_PASSWORD_VALIDATE)
            return false
        }
        /*
         if isValidPassword(txtRepeatPassword.text!) == false {
         showAlert(string: Constant.ALERT_MSG_PASSWORD_VALIDATE_FORMAT)
         return false
         }*/
        
        if trimString(string: (txtPassword.text)!) != trimString(string: (txtRepeatPassword.text)!) {
            showAlert(string: Constant.ALERT_MSG_BOTH_PASSWORD_SAME_VALIDATE)
            return false
        }
        
        if dictCountry.count == 0 {
            showAlert(string: Constant.ALERT_MSG_SELECT_COUNTRY_VALIDATE)
            return false
        }
        if dictState.count == 0 {
            showAlert(string: Constant.ALERT_MSG_SELECT_STATE_VALIDATE)
            return false
        }
        if trimString(string: (txtZipcode.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_ZIPCODE_VALIDATE)
            return false
        }
        if trimString(string: (txtDOB.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_BIRTHDATE_VALIDATE)
            return false
        }
        if trimString(string: (txtCaptcha.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_CAPTCHA_VALIDATE)
            return false
        }
        if txtCaptcha.text != lblCaptcha.text {
            showAlert(string: Constant.ALERT_MSG_CAPTCHA_INVALIDATE)
            return false
        }
        if btnCheckTermAndCondition.isSelected == false {
            showAlert(string: Constant.ALERT_MSG_TERMS_AND_CONDITIONS)
            return false
        }
        
        return true
    }
    
    // MARK: - DatePicker Method
    func datePickerChanged(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from:sender.date)
        txtDOB.text = dateString
    }
    func dismissPicker() {
        view.endEditing(true)
    }
    
    // MARK: - UIAlertViewDelegate
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        switch alertView.tag{
        case 1:
            for (_, element) in self.navigationController!.viewControllers.enumerated(){
                if element.isKind(of: LoginViewController.self) {
                    self.navigationController!.popToViewController(element, animated: true)
                    return
                }
            }
            
            let vcLogin = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            self.navigationController?.setViewControllers([vcLogin], animated: true)
            
            break
        case 2:
            break
        default: break
            
        }
    }
}

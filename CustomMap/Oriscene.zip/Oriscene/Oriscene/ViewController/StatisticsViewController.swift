//
//  StatisticsViewController.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

enum ENUM_STATISTICS: Int {
    case FOLLOWERS = 0, VIEWS, AGREES, DISAGREES, COMMENTS, REVIEWS
}

class StatisticsViewController: BaseViewController, UICollectionViewDelegate, UICollectionViewDataSource, StatisticDataCellDelegate{
    
    @IBOutlet weak var cvStatistics: UICollectionView!
    @IBOutlet weak var cvStatisticsData: UICollectionView!
    
    let service = WebService()
    var selectIndexPath = 0
    var selectedTimForFollowers = 0
    var selectedTimForViews = 0
    var selectedTimForAgrees = 0
    var selectedTimForDisagrees = 0
    var selectedTimForComments = 0
    var dictFollowers  = Dictionary<String,Any> ()
    var dictViews  = Dictionary<String,Any> ()
    var dictAgree  = Dictionary<String,Any> ()
    var dictDisAgree  = Dictionary<String,Any> ()
    var dictComments  = Dictionary<String,Any> ()
    var dictReview  = Dictionary<String,Any> ()
    
    var arrReview = [ Dictionary<String,Any>]()
    var arrStatisticsType = ["Followers", "Views", "Agrees", "Disagrees", "Comments", "Review"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.cvStatistics.register(UINib(nibName: "StatisticsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "StatisticsCell")
        self.cvStatisticsData.register(UINib(nibName: "StatisticDataCell", bundle: nil), forCellWithReuseIdentifier: "StatisticDataCell")
        self.cvStatisticsData.register(UINib(nibName: "ReviewCvCell", bundle: nil), forCellWithReuseIdentifier: "ReviewCvCell")
        
        NotificationCenter.default.addObserver(self, selector: #selector(StatisticsViewController.methodOfReceivedNotification(notification:)), name: Notification.Name("NotificationIdentifier"), object: nil)
        
        // Do any additional setup after loading the view.
        
        self.callWebserviceGetStatisticsForFollowers(strTime: "1")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillLayoutSubviews()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func methodOfReceivedNotification(notification: Notification){
        //Take Action on Notification
        let vcLikeUnlike = self.storyboard?.instantiateViewController(withIdentifier: "LikeUnlikeViewController") as! LikeUnlikeViewController
        self.navigationController?.pushViewController(vcLikeUnlike, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrStatisticsType.count
    }
    
    private func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.cvStatistics {
            let cell : StatisticsCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StatisticsCell", for: indexPath as IndexPath) as! StatisticsCollectionViewCell
            cell.lblStatisticsTypes.text = arrStatisticsType[indexPath.row]
            if selectIndexPath == indexPath.row {
                cell.lblDivider.isHidden = false
                cell.lblStatisticsTypes.alpha = 1
            } else {
                cell.lblDivider.isHidden = true
                cell.lblStatisticsTypes.alpha = 0.3
            }
            
            return cell
        } else {
            
            if indexPath.row == ENUM_STATISTICS.FOLLOWERS.rawValue {
                let cell : StatisticDataCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StatisticDataCell", for: indexPath as IndexPath) as! StatisticDataCell
                cell.delegate = self
                cell.lblTypeHeader.text = arrStatisticsType[indexPath.row]
                cell.lblTypeGraph.text = arrStatisticsType[indexPath.row]
                cell.index = indexPath.row
                cell.dictStatistics = self.dictFollowers
                cell.intStatisticType = indexPath.row
                cell.indexOfSelectedTime = selectedTimForFollowers
                if self.dictFollowers.keys.contains("category_related_data") {
                    let dict = self.dictFollowers["category_related_data"]
                    if dict is [Dictionary<String,Any>] {
                        cell.arrUserList = dict as! [Dictionary<String,Any>]
                    }
                    else{
                        cell.arrUserList = [Dictionary<String,Any>]()
                    }
                }
                else{
                    cell.arrUserList = [Dictionary<String,Any>]()
                }
                if !self.dictFollowers.isEmpty {
                    cell.setupGraph()
                }
                else{
                    cell.clearGraph()
                }
                cell.cvUserLIst.reloadData()
                return cell
            }
            else if indexPath.row == ENUM_STATISTICS.VIEWS.rawValue {
                let cell : StatisticDataCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StatisticDataCell", for: indexPath as IndexPath) as! StatisticDataCell
                cell.delegate = self
                cell.lblTypeHeader.text = arrStatisticsType[indexPath.row]
                cell.lblTypeGraph.text = arrStatisticsType[indexPath.row]
                cell.index = indexPath.row
                cell.dictStatistics = self.dictViews
                cell.intStatisticType = indexPath.row
                cell.indexOfSelectedTime = selectedTimForViews
                if self.dictViews.keys.contains("category_related_data") {
                    let dict = self.dictViews["category_related_data"]
                    if dict is [Dictionary<String,Any>] {
                        cell.arrUserList = dict as! [Dictionary<String,Any>]
                    }
                    else{
                        cell.arrUserList = [Dictionary<String,Any>]()
                    }
                }
                else{
                    cell.arrUserList = [Dictionary<String,Any>]()
                }
                
                if !self.dictViews.isEmpty {
                    cell.setupGraph()
                }
                else{
                    cell.clearGraph()
                }
                
                cell.cvUserLIst.reloadData()
                return cell
            }
            else if indexPath.row == ENUM_STATISTICS.AGREES.rawValue {
                let cell : StatisticDataCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StatisticDataCell", for: indexPath as IndexPath) as! StatisticDataCell
                cell.delegate = self
                cell.lblTypeHeader.text = arrStatisticsType[indexPath.row]
                cell.lblTypeGraph.text = arrStatisticsType[indexPath.row]
                cell.index = indexPath.row
                cell.dictStatistics = self.dictAgree
                cell.intStatisticType = indexPath.row
                cell.indexOfSelectedTime = selectedTimForAgrees
                if self.dictAgree.keys.contains("category_related_data") {
                    let dict = self.dictAgree["category_related_data"]
                    if dict is [Dictionary<String,Any>] {
                        cell.arrUserList = dict as! [Dictionary<String,Any>]
                    }
                    else{
                        cell.arrUserList = [Dictionary<String,Any>]()
                    }
                }
                else{
                    cell.arrUserList = [Dictionary<String,Any>]()
                }
                if !self.dictAgree.isEmpty {
                    cell.setupGraph()
                }
                else{
                    cell.clearGraph()
                }
                
                cell.cvUserLIst.reloadData()
                return cell
            }
            else if indexPath.row == ENUM_STATISTICS.DISAGREES.rawValue {
                let cell : StatisticDataCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StatisticDataCell", for: indexPath as IndexPath) as! StatisticDataCell
                cell.delegate = self
                cell.lblTypeHeader.text = arrStatisticsType[indexPath.row]
                cell.lblTypeGraph.text = arrStatisticsType[indexPath.row]
                cell.index = indexPath.row
                cell.dictStatistics = self.dictDisAgree
                cell.intStatisticType = indexPath.row
                cell.indexOfSelectedTime = selectedTimForDisagrees
                if self.dictDisAgree.keys.contains("category_related_data") {
                    let dict = self.dictDisAgree["category_related_data"]
                    if dict is [Dictionary<String,Any>] {
                        cell.arrUserList = dict as! [Dictionary<String,Any>]
                    }
                    else{
                        cell.arrUserList = [Dictionary<String,Any>]()
                    }
                }
                else{
                    cell.arrUserList = [Dictionary<String,Any>]()
                }
                if !self.dictDisAgree.isEmpty {
                    cell.setupGraph()
                }
                else{
                    cell.clearGraph()
                }
                cell.cvUserLIst.reloadData()
                return cell
            }
            else if indexPath.row == ENUM_STATISTICS.COMMENTS.rawValue {
                let cell : StatisticDataCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StatisticDataCell", for: indexPath as IndexPath) as! StatisticDataCell
                cell.delegate = self
                cell.lblTypeHeader.text = arrStatisticsType[indexPath.row]
                cell.lblTypeGraph.text = arrStatisticsType[indexPath.row]
                cell.index = indexPath.row
                cell.dictStatistics = self.dictComments
                cell.intStatisticType = indexPath.row
                cell.indexOfSelectedTime = selectedTimForComments
                if self.dictComments.keys.contains("category_related_data") {
                    let dict = self.dictComments["category_related_data"]
                    if dict is [Dictionary<String,Any>] {
                        cell.arrUserList = dict as! [Dictionary<String,Any>]
                    }
                    else{
                        cell.arrUserList = [Dictionary<String,Any>]()
                    }
                }
                else{
                    cell.arrUserList = [Dictionary<String,Any>]()
                }
                if !self.dictComments.isEmpty {
                    cell.setupGraph()
                }
                else{
                    cell.clearGraph()
                }
                cell.cvUserLIst.reloadData()
                return cell
            }
            else {
                let cell : ReviewCvCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ReviewCvCell", for: indexPath as IndexPath) as! ReviewCvCell
                cell.arrReview = self.arrReview
                cell.tblReview.reloadData()
                return cell
            }
        }
    }
    
    // MARK: - UICollectionViewDelegate -
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectIndexPath = (indexPath.row)
        self.cvStatistics.reloadData()
        if collectionView == self.cvStatistics {
            self.cvStatisticsData.scrollToItem(at: indexPath, at: UICollectionViewScrollPosition.centeredHorizontally, animated: true)
            if indexPath.row == ENUM_STATISTICS.FOLLOWERS.rawValue {
                self.callWebserviceGetStatisticsForFollowers(strTime: "1")
            }
            else if indexPath.row == ENUM_STATISTICS.VIEWS.rawValue {
                self.callWebserviceGetStatisticsForViews(strTime: "1")
            }
            else if indexPath.row == ENUM_STATISTICS.AGREES.rawValue {
                self.callWebserviceGetStatisticsForAgrees(strTime: "1")
            }
            else if indexPath.row == ENUM_STATISTICS.DISAGREES.rawValue {
                self.callWebserviceGetStatisticsForDisAgrees(strTime: "1")
            }
            else if indexPath.row == ENUM_STATISTICS.COMMENTS.rawValue {
                self.callWebserviceGetStatisticsForComments(strTime: "1")
            }
            else {
                self.callWebserviceGetReview(strTime: "")
            }
        } else {
            
        }
    }
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        
        if collectionView == self.cvStatistics {
            return UIEdgeInsetsMake(0, 10, 0, 10);
        } else {
            return UIEdgeInsetsMake(0, 0, 0, 0);
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize
    {
        if collectionView == self.cvStatistics {
            return CGSize(width: 90, height: collectionView.frame.size.height)
        } else {
            return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        if scrollView.tag == 2 {
            
            let width: CGFloat = scrollView.frame.size.width
            let page = (scrollView.contentOffset.x + (0.5 * width)) / width
            
            let indexPath = IndexPath.init(row: Int(page), section: 0)
            selectIndexPath = Int(page)
            self.cvStatistics.reloadData()
            
            cvStatistics.scrollToItem(at: indexPath, at: UICollectionViewScrollPosition.centeredHorizontally, animated: true)
            if selectIndexPath == ENUM_STATISTICS.FOLLOWERS.rawValue {
                self.callWebserviceGetStatisticsForFollowers(strTime: "1")
            }
            else if selectIndexPath == ENUM_STATISTICS.VIEWS.rawValue {
                self.callWebserviceGetStatisticsForViews(strTime: "1")
            }
            else if selectIndexPath == ENUM_STATISTICS.AGREES.rawValue {
                self.callWebserviceGetStatisticsForAgrees(strTime: "1")
            }
            else if selectIndexPath == ENUM_STATISTICS.DISAGREES.rawValue {
                self.callWebserviceGetStatisticsForDisAgrees(strTime: "1")
            }
            else if selectIndexPath == ENUM_STATISTICS.COMMENTS.rawValue {
                self.callWebserviceGetStatisticsForComments(strTime: "1")
            }
            else {
                self.callWebserviceGetReview(strTime: "")
            }
        }
    }
    
    //MARK:- Webservice
    func callWebserviceGetStatisticsForFollowers(strTime : String) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["forWhat"] = "1"
            dictParam["filterState"] = strTime
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getStatistics", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.dictFollowers = dict?["data"] as! Dictionary<String,Any>
                        self.cvStatisticsData.reloadData()
                    }
                    else{
                        self.dictFollowers = Dictionary<String,Any>()
                        self.cvStatisticsData.reloadData()
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceGetStatisticsForViews(strTime : String) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["forWhat"] = "2"
            dictParam["filterState"] = strTime
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getStatistics", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.dictViews = dict?["data"] as! Dictionary<String,Any>
                        self.cvStatisticsData.reloadData()
                    }
                    else{
                        self.dictViews = Dictionary<String,Any>()
                        self.cvStatisticsData.reloadData()
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceGetStatisticsForAgrees(strTime : String) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["forWhat"] = "3"
            dictParam["filterState"] = strTime
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getStatistics", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.dictAgree = dict?["data"] as! Dictionary<String,Any>
                        self.cvStatisticsData.reloadData()
                    }
                    else{
                        self.dictAgree = Dictionary<String,Any>()
                        self.cvStatisticsData.reloadData()
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceGetStatisticsForDisAgrees(strTime : String) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["forWhat"] = "4"
            dictParam["filterState"] = strTime
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getStatistics", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.dictDisAgree = dict?["data"] as! Dictionary<String,Any>
                        self.cvStatisticsData.reloadData()
                    }
                    else{
                        self.dictDisAgree = Dictionary<String,Any>()
                        self.cvStatisticsData.reloadData()
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceGetStatisticsForComments(strTime : String) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["forWhat"] = "5"
            dictParam["filterState"] = strTime
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getStatistics", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.dictComments = dict?["data"] as! Dictionary<String,Any>
                        self.cvStatisticsData.reloadData()
                    }
                    else{
                        self.dictComments = Dictionary<String,Any>()
                        self.cvStatisticsData.reloadData()
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceGetReview(strTime : String) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["forWhat"] = "5"
            dictParam["filterState"] = strTime
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getMonthlyReview", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrReview = dict?["data"] as! [Dictionary<String,Any>]
                        self.cvStatisticsData.reloadData()
                    }
                    else{
                        self.arrReview = [Dictionary<String,Any>]()
                        self.cvStatisticsData.reloadData()
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    //MARK:- StatisticDataCellDelegate
    func btnTimeClicked(indexOfStatistics: NSInteger, strTime: String, indexOfTime: NSInteger) {
        if indexOfStatistics == ENUM_STATISTICS.FOLLOWERS.rawValue {
            self.callWebserviceGetStatisticsForFollowers(strTime: strTime)
            selectedTimForFollowers = indexOfTime
        }
        else if indexOfStatistics == ENUM_STATISTICS.VIEWS.rawValue {
            self.callWebserviceGetStatisticsForViews(strTime: strTime)
            selectedTimForViews = indexOfTime
        }
        else if indexOfStatistics == ENUM_STATISTICS.AGREES.rawValue {
            self.callWebserviceGetStatisticsForAgrees(strTime: strTime)
            selectedTimForAgrees = indexOfTime
        }
        else if indexOfStatistics == ENUM_STATISTICS.DISAGREES.rawValue {
            self.callWebserviceGetStatisticsForDisAgrees(strTime: strTime)
            selectedTimForDisagrees = indexOfTime
        }
        else if indexOfStatistics == ENUM_STATISTICS.COMMENTS.rawValue {
            self.callWebserviceGetStatisticsForComments(strTime: strTime)
            selectedTimForComments = indexOfTime
        }
        else {
        }
    }
}

//
//  BidsViewController.swift
//  Oriscene
//
//  Created by Parth on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class BidsViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource, BidListDelegate ,BidPriceDelegate,RecivedBidsCellDelegate,RecivedBidsViewDelegate,FinalisedBidListDelegate {
    
    var arrBidTypeOption = [Dictionary<String,String>]()
    var service = WebService()
    var arrBidList = [Dictionary<String,Any>]()
    var selecteBidType = 0
    var viewBidPrice : BidPriceView? = nil
    var viewRecivedBid : RecivedBidsView? = nil
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var tblBids: UITableView!
    
    @IBOutlet var viewBidsTypeContainer: UIView!
    @IBOutlet var viewBidType: UIView!
    @IBOutlet var btnBids: UIButton!
    
    @IBOutlet var viewBidTypeOptionContainer: UIView!
    @IBOutlet var tblBidTypeOption: UITableView!
    @IBOutlet var viewTransparent: UIView!
    @IBOutlet var btnTransparent: UIButton!
    
    @IBOutlet weak var viewApprovedCheckBoxContainer: UIView!
    
    @IBOutlet weak var heightViewApprovedCheckBoxContainer: NSLayoutConstraint!
    
    @IBOutlet weak var btnApprovedBidsByMe: UIButton!
    @IBOutlet weak var btnApprovedBidsToMe: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setUpUI()
        selecteBidType = BidType.RECEIVED_BIDS.rawValue
        callWebserviceShowBids()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    deinit {
        //        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                // self.bottomConstEditBidContainer?.constant = 0.0
                //                self.scrollView.setContentOffset(CGPoint(x: 0.0, y: 0.0), animated: true)
            } else {
                // self.bottomConstEditBidContainer?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - Custom DataSource
    
    func setUpUI() -> Void {
        
        heightViewApprovedCheckBoxContainer.constant = 0.0
        viewApprovedCheckBoxContainer.isHidden = true
        
        viewBidTypeOptionContainer.isHidden = true
        viewTransparent.isHidden = true
        
        tblBids.register(BidsTVCell.self, forCellReuseIdentifier: "BidsTVCell")
        tblBids.register(UINib.init(nibName: "BidsTVCell", bundle: nil), forCellReuseIdentifier: "BidsTVCell")
        
        tblBids.register(UINib.init(nibName: "RecivedBidsTVCell", bundle: nil), forCellReuseIdentifier: "RecivedBidsTVCell")
        
        tblBids.register(UINib.init(nibName: "FinalisedBidTVCell", bundle: nil), forCellReuseIdentifier: "FinalisedBidTVCell")
        
        tblBidTypeOption.register(BidTypeOptionTVCell.self, forCellReuseIdentifier: "BidTypeOptionTVCell")
        tblBidTypeOption.register(UINib.init(nibName: "BidTypeOptionTVCell", bundle: nil), forCellReuseIdentifier: "BidTypeOptionTVCell")
        
        viewBidType.layer.cornerRadius = 3.0
        viewBidType.layer.masksToBounds = true
        viewBidType.layer.borderColor = UIColor.lightGray.cgColor
        viewBidType.layer.borderWidth = 1.0
        
        viewBidTypeOptionContainer.layer.borderColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.5).cgColor
        viewBidTypeOptionContainer.layer.borderWidth = 1.0
        
        viewBidTypeOptionContainer.layer.shadowColor = UIColor.lightGray.cgColor
        viewBidTypeOptionContainer.layer.shadowOpacity = 1.0
        viewBidTypeOptionContainer.layer.shadowOffset = CGSize.zero
        viewBidTypeOptionContainer.layer.shadowRadius = 7.0
        viewBidTypeOptionContainer.layer.cornerRadius = 3.0
        viewBidTypeOptionContainer.layer.masksToBounds = true
        
        arrBidTypeOption = [ [ "bidOptionTitle" : "RECEIVED BIDS" ] , [ "bidOptionTitle" : "PROPOSED BIDS" ] , [ "bidOptionTitle" : "APPROVED BIDS" ] , [ "bidOptionTitle" : "FINALISED PURCHASES" ] ]
        tblBidTypeOption.reloadData()
        tblBids.reloadData()
        
        if viewBidPrice == nil {
            viewBidPrice = BidPriceView.instanceFromNib() as? BidPriceView
            viewBidPrice?.frame = UIScreen.main.bounds
            viewBidPrice?.isHidden = true
            viewBidPrice?.delegate = self
            viewBidPrice?.alpha = 0.0
            self.view.addSubview(viewBidPrice!)
        }
        if viewRecivedBid == nil {
            viewRecivedBid = RecivedBidsView.instanceFromNib() as? RecivedBidsView
            viewRecivedBid?.frame = UIScreen.main.bounds
            viewRecivedBid?.isHidden = true
            viewRecivedBid?.delegate = self
            viewRecivedBid?.alpha = 0.0
            self.view.addSubview(viewRecivedBid!)
        }
        let dict = arrBidTypeOption[0]
        btnBids.setTitle(dict["bidOptionTitle"], for: UIControlState.normal)
    }
    
    // MARK: - UITableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblBidTypeOption {
            return arrBidTypeOption.count
        }
        else{
            return arrBidList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == tblBidTypeOption {
            let cell = tableView .dequeueReusableCell(withIdentifier: "BidTypeOptionTVCell") as! BidTypeOptionTVCell
            cell.index = indexPath.row
            let dict = arrBidTypeOption[indexPath.row]
            cell.lblBidTypeOptionTitle.text = dict["bidOptionTitle"]
            return cell
        }
        else{
            switch selecteBidType {
                
            case BidType.RECEIVED_BIDS.rawValue :
                let cell = tableView .dequeueReusableCell(withIdentifier: "RecivedBidsTVCell") as! RecivedBidsTVCell
                cell.delegate = self
                cell.index = indexPath.row
                let dictBidData = arrBidList[indexPath.row]
                cell.lblTitle.text = dictBidData["title_text"] as? String
                cell.lblDescription.text = dictBidData["desc_text"] as? String
                print(dictBidData)
                return cell
                
            case  BidType.PROPOSED_BIDS.rawValue , BidType.APPROVED_BIDS.rawValue :
                
                let cell = tableView .dequeueReusableCell(withIdentifier: "BidsTVCell") as! BidsTVCell
                cell.index = indexPath.row
                cell.delegate = self
                
                let dictBidData = arrBidList[indexPath.row]
                let dictUserData = dictBidData["user_data"] as! Dictionary<String,Any>
                
                if dictUserData.keys.contains("photo") {
                    
                    let strStringNameId = dictUserData["photo"]
                    if strStringNameId is String {
                        let strPhotoName = strStringNameId as! String
                        
                        if strPhotoName.characters.count != 0 {
                            let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                            let fileUrl = NSURL(string: strUrl)
                            
                            cell.imgUserPic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                                if error != nil {
                                    print("Failed: \(error)")
                                } else {
                                    print("Success")
                                }
                            }
                        }
                        else{
                            cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                        }
                    }else {
                        cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                    }
                }
                else{
                    cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                }
                
                let strusenickname = dictUserData["usenickname"] as! String
                if strusenickname == "1" {
                    cell.lblUserName.text = dictUserData["reporter_name"] as? String
                }
                else{
                    cell.lblUserName.text = (dictUserData["firstname"] as! String) + " " + (dictUserData["lastname"] as! String)
                }
                cell.lblComment.text = dictBidData["title_text"] as? String
                
                if dictBidData.keys.contains("desc_text") {
                    if selecteBidType == BidType.PROPOSED_BIDS.rawValue  || selecteBidType == BidType.APPROVED_BIDS.rawValue{
                        cell.lblDescription.text = dictBidData["desc_text"] as? String
                    }
                    else{
                        cell.lblDescription.text = "$" + (dictBidData["desc_text"] as! String)
                    }
                }else{
                    cell.lblDescription.text = ""
                }
                
                let strDate = dictBidData["edit_date"] as? String
                cell.lblTime.text = convertDate(strDate: strDate!)
                if selecteBidType == BidType.APPROVED_BIDS.rawValue {
                    cell.btnPending.isHidden = false
                    cell.btnEditBid.isHidden = false
                    
                    if dictBidData.keys.contains("dis_approved_btn"){
                        cell.btnPending.setTitle("APPROVED",for: .normal)
                        cell.btnPending.isEnabled = false
                    }else{
                        cell.btnPending.isHidden = true
                    }
                    if dictBidData.keys.contains("dis_disApprove_btn_enable"){
                        cell.btnEditBid.setTitle("DISAPPROVE",for: .normal)
                        cell.btnEditBid.isEnabled = true
                        cell.btnEditBid.isHidden = false
                    }else{
                        cell.btnEditBid.setTitle("DISAPPROVE",for: .normal)
                        cell.btnEditBid.isEnabled = false
                        cell.btnEditBid.isHidden = true
                    }
                }else{
                    cell.btnPending.setTitle("PENDING",for: .normal)
                    cell.btnEditBid.setTitle("EDIT BID",for: .normal)
                    if dictBidData.keys.contains("dis_pend_edit_btn"){
                        cell.btnPending.isHidden = false
                        cell.btnEditBid.isHidden = false
                    }else{
                        cell.btnPending.isHidden = true
                        cell.btnEditBid.isHidden = true
                    }
                }
                if dictBidData.keys.contains("dis_buy_it_btn") {
                    if dictBidData["dis_buy_it_btn"] as! String  == "1" {
                        cell.btnPending.setTitle("BUY IT",for: .normal)
                        cell.btnPending.isEnabled = true
                        cell.btnPending.isHidden = false
                    }
                }
                return cell
                
            case  BidType.FINALISED_PURCHASES_BIDS.rawValue :
                
                let cell = tableView .dequeueReusableCell(withIdentifier: "FinalisedBidTVCell") as! FinalisedBidTVCell
                cell.index = indexPath.row
                cell.delegate = self
                let dictBidData = arrBidList[indexPath.row]
                let dictUserData = dictBidData["user_data"] as! Dictionary<String,Any>
                
                if dictUserData.keys.contains("photo") {
                    
                    let strStringNameId = dictUserData["photo"]
                    if strStringNameId is String {
                        let strPhotoName = strStringNameId as! String
                        
                        if strPhotoName.characters.count != 0 {
                            let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                            let fileUrl = NSURL(string: strUrl)
                            
                            cell.imgUserPic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                                if error != nil {
                                    print("Failed: \(error)")
                                } else {
                                    print("Success")
                                }
                            }
                        }
                        else{
                            cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                        }
                    }else {
                        cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                    }
                }
                else{
                    cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                }
                
                let strusenickname = dictUserData["usenickname"] as! String
                if strusenickname == "1" {
                    cell.lblUserName.text = dictUserData["reporter_name"] as? String
                }
                else{
                    cell.lblUserName.text = (dictUserData["firstname"] as! String) + " " + (dictUserData["lastname"] as! String)
                }
                
                if dictBidData.keys.contains("dis_down_btn") {
                    if dictBidData["dis_down_btn"] as! String  == "1" {
                        cell.btnDownload.isHidden = false
                        cell.topSpaceConstBtnDownload.constant = 12.0
                        cell.heightConstBtnDownload.constant = 25.0
                    }else{
                        cell.btnDownload.isHidden = true
                        cell.topSpaceConstBtnDownload.constant = 0.0
                        cell.heightConstBtnDownload.constant = 0.0
                    }
                }else{
                    cell.btnDownload.isHidden = true
                    cell.topSpaceConstBtnDownload.constant = 0.0
                    cell.heightConstBtnDownload.constant = 0.0
                }
                
                cell.lblTitle.text = dictBidData["title_text"] as? String
                cell.lblPostDesc.text = dictBidData["post_desc"] as? String
                cell.lblDesc.text = dictBidData["desc_text"] as? String
                
                let strDate = dictBidData["payed_date"] as? String
                cell.lblTime.text = convertDate(strDate: strDate!)
                return cell
                
            default :
                fatalError("Unexpected Bid type \(indexPath.row) in section \(indexPath.section)")
                break
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tblBidTypeOption {
            return 44.0
        }
        else{
            //            return 140.0
            return UITableViewAutomaticDimension
        }
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tblBidTypeOption {
            return 44.0
        }
        else{
            return UITableViewAutomaticDimension
        }
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if viewBidTypeOptionContainer.isHidden {
            
        }
        else{
            UIView.animate(withDuration: 0.3, animations: {
                self.viewBidTypeOptionContainer.alpha = 0.0
                self.viewTransparent.alpha = 0.0
            }) { (Bool) in
                self.viewBidTypeOptionContainer.isHidden = true
                self.viewTransparent.isHidden = true
            }
        }
        
        if tableView == tblBidTypeOption {
            
            let dict = arrBidTypeOption[indexPath.row]
            btnBids.setTitle(dict["bidOptionTitle"], for: UIControlState.normal)
            selecteBidType = indexPath.row
            if selecteBidType == BidType.APPROVED_BIDS.rawValue {
                btnApprovedBidsByMe.setTitle("Approved Bids by Me", for: .normal)
                btnApprovedBidsToMe.setTitle("Approved Bids to Me", for: .normal)
                viewApprovedCheckBoxContainer.isHidden = false
                UIView.animate(withDuration: 0.0, animations: {() -> Void in
                    self.viewApprovedCheckBoxContainer.alpha = 0
                }, completion: {(_ finished: Bool) -> Void in
                    UIView.animate(withDuration: 0.3, animations: {() -> Void in
                        self.viewApprovedCheckBoxContainer.alpha = 1.0
                        self.heightViewApprovedCheckBoxContainer.constant = 50.0
                    }, completion: { _ in })
                })
            }else if selecteBidType == BidType.FINALISED_PURCHASES_BIDS.rawValue {
                btnApprovedBidsByMe.setTitle("Sold Posts", for: .normal)
                btnApprovedBidsToMe.setTitle("Bought Posts", for: .normal)
                
                viewApprovedCheckBoxContainer.isHidden = false
                UIView.animate(withDuration: 0.0, animations: {() -> Void in
                    self.viewApprovedCheckBoxContainer.alpha = 0
                }, completion: {(_ finished: Bool) -> Void in
                    UIView.animate(withDuration: 0.3, animations: {() -> Void in
                        self.viewApprovedCheckBoxContainer.alpha = 1.0
                        self.heightViewApprovedCheckBoxContainer.constant = 50.0
                    }, completion: { _ in })
                })
                
            }
            else{
                heightViewApprovedCheckBoxContainer.constant = 0.0
                viewApprovedCheckBoxContainer.isHidden = true
            }
            arrBidList.removeAll()
            tblBids.reloadData()
            callWebserviceShowBids()
        }
        else{
            
        }
    }
    
    // MARK: - UITableView Delegate
    
    @IBAction func btnBidsAction(_ sender: Any) {
        
        if viewBidTypeOptionContainer.isHidden {
            self.viewBidTypeOptionContainer.alpha = 0.0
            self.viewBidTypeOptionContainer.isHidden = false
            self.viewTransparent.alpha = 0.0
            self.viewTransparent.isHidden = false
            UIView.animate(withDuration: 0.0, animations: {() -> Void in
                self.viewBidTypeOptionContainer.alpha = 0.0
                self.viewTransparent.alpha = 0.0
                
            }, completion: {(_ finished: Bool) -> Void in
                UIView.animate(withDuration: 0.3, animations: {() -> Void in
                    self.viewBidTypeOptionContainer.alpha = 1.0
                    self.viewTransparent.alpha = 1.0
                }, completion: { _ in })
            })
        }
        else{
            UIView.animate(withDuration: 0.3, animations: {
                self.viewBidTypeOptionContainer.alpha = 0.0
                self.viewTransparent.alpha = 0.0
            }) { (Bool) in
                self.viewBidTypeOptionContainer.isHidden = true
                self.viewTransparent.isHidden = true
            }
        }
    }
    @IBAction func btnTransparentAction(_ sender: Any) {
        UIView.animate(withDuration: 0.3, animations: {
            self.viewBidTypeOptionContainer.alpha = 0.0
            self.viewTransparent.alpha = 0.0
        }) { (Bool) in
            self.viewBidTypeOptionContainer.isHidden = true
            self.viewTransparent.isHidden = true
        }
    }
    
    // MARK: - Button Action
    @IBAction func btnApprovedBidsToMeClickAction(_ sender: Any) {
        btnApprovedBidsToMe.isSelected = !btnApprovedBidsToMe.isSelected
        arrBidList.removeAll()
        tblBids.reloadData()
        callWebserviceShowBids()
    }
    @IBAction func btnApprovedByMeClickAction(_ sender: Any) {
        btnApprovedBidsByMe.isSelected = !btnApprovedBidsByMe.isSelected
        arrBidList.removeAll()
        tblBids.reloadData()
        callWebserviceShowBids()
    }
    
    // MARK: - BidListDelegate
    
    func btnEditBidClicked(index: NSInteger) {
        
        if selecteBidType == BidType.PROPOSED_BIDS.rawValue {
            let dictBidData = arrBidList[index]
            viewBidPrice?.index = index
            viewBidPrice?.dictBidDtl = dictBidData
            
            viewBidPrice?.txtPrice.text = dictBidData["amount"] as! String?
            viewBidPrice?.lblTitle.text = "Edit Bid"
            viewBidPrice?.btnPlaceBid.setTitle("EDIT BID", for: .normal)
            
            viewBidPrice?.isHidden = false
            UIView.animate(withDuration: 0.0, animations: {() -> Void in
                self.viewBidPrice?.alpha = 0.0
            }, completion: {(_ finished: Bool) -> Void in
                UIView.animate(withDuration: 0.3, animations: {() -> Void in
                    self.viewBidPrice?.alpha = 1.0
                }, completion: { _ in })
            })
        }
        if selecteBidType == BidType.APPROVED_BIDS.rawValue {
            //DisApprove Bid Functionality
            callWebserviceDisApproveRecivedBid(index: index)
        }
    }
    
    func btnPendingBidClicked(index: NSInteger) {
        if selecteBidType == BidType.APPROVED_BIDS.rawValue || selecteBidType == BidType.PROPOSED_BIDS.rawValue {
            let dictData = arrBidList[index]
            if dictData.keys.contains("dis_buy_it_btn"){
                let eCommerceVC = self.storyboard?.instantiateViewController(withIdentifier: "EcommerceAgreementViewController") as! EcommerceAgreementViewController
                eCommerceVC.isFromBidVC = true
                eCommerceVC.dictPostDtl = dictData
                self.navigationController!.pushViewController(eCommerceVC, animated: true)
            }
        }
    }
    
    // MARK: - Edit BidPrice Delegate
    func hideBidPriceView() {
        self.view.endEditing(true)
        
        viewBidPrice?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewBidPrice?.alpha = 0.0
        }) { (Bool) in
            self.viewBidPrice?.isHidden = true
        }
    }
    func insertUpdateBidPriceClick(strAmount: String, indexOfObject: NSInteger) {
        print (strAmount)
        
        let dictBidData = arrBidList[indexOfObject]
        print(dictBidData)
        
        let dictParam = NSMutableDictionary()
        dictParam["postId"] = dictBidData["post_id"] as! String;
        dictParam["bidId"] = dictBidData["c_id"] as! String;
        dictParam["amount"] = strAmount
        self.callWebserviceEditBidPost(dictParam: dictParam, andIndexOfPost: indexOfObject)
        
    }
    
    // MARK: - RecivedBidCell Delegate
    func btnViewBidClicked(index : NSInteger) -> Void {
        let dictBidData = arrBidList[index]
        viewRecivedBid?.index = index
        viewRecivedBid?.dictBidData = dictBidData
        viewRecivedBid?.callWebserviceShowAndUpdateRecivedBids(isForView : true,status:0)
        viewRecivedBid?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewRecivedBid?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewRecivedBid?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    // MARK: - RecivedBidView Delegate
    func btnApproveClicked(index : NSInteger) -> Void {
        
    }
    func hideRecivedBidView(index : NSInteger) -> Void {
        self.view.endEditing(true)
        viewRecivedBid?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewRecivedBid?.alpha = 0.0
        }) { (Bool) in
            self.viewRecivedBid?.isHidden = true
        }
    }
    // MARK: - FinalisedBidListDelegate
    
    func btnDownloadClicked(index: NSInteger) {
        //        let dict = arrBidList[index] as! Dictionary<String,Any>
        self.callWebserviceDownloadPost(index: index)
    }
    
    // MARK: - UITextFieldDelegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //MARK:- Webservice
    func callWebserviceShowBids() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            if selecteBidType == BidType.RECEIVED_BIDS.rawValue {
                dictParam["bidType"] = "received"
            }
            else if selecteBidType == BidType.PROPOSED_BIDS.rawValue {
                dictParam["bidType"] = "proposed"
            }
            else if selecteBidType == BidType.APPROVED_BIDS.rawValue{
                dictParam["bidType"] = "approved"
                
                if btnApprovedBidsToMe.isSelected {
                    dictParam["approvedToMe"] = "true"
                }else{
                    dictParam["approvedToMe"] = "false"
                }
                if btnApprovedBidsByMe.isSelected {
                    dictParam["approvedByMe"] = "true"
                }else{
                    dictParam["approvedByMe"] = "false"
                }
                
            } else if selecteBidType == BidType.FINALISED_PURCHASES_BIDS.rawValue{
                dictParam["bidType"] = "finalised"
                if btnApprovedBidsToMe.isSelected {
                    dictParam["boughtItems"] = "true"
                }else{
                    dictParam["boughtItems"] = "false"
                }
                if btnApprovedBidsByMe.isSelected {
                    dictParam["soldItems"] = "true"
                }else{
                    dictParam["soldItems"] = "false"
                }
            }
            dictParam["bidLimit"] = String(arrBidList.count)
            
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "showBids", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        print(dict!)
                        self.arrBidList = dict?["data"] as! [Dictionary<String,Any>]
                        self.tblBids.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceEditBidPost(dictParam : NSMutableDictionary, andIndexOfPost: NSInteger) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            service.callJSONMethod(methodName: "updateBidPrice", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        var dictBidDate = self.arrBidList[andIndexOfPost]
                        dictBidDate["amount"] = dictParam["amount"]
                        self.arrBidList[andIndexOfPost] = dictBidDate
                        self.hideBidPriceView()
                        self.tblBids.reloadData()
                        self.showAlert(string: dict?["message"] as! String)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceDisApproveRecivedBid(index : NSInteger) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            dictParam["forView"] = "0"
            dictParam["forStatusChange"] = "1"
            let dictData = arrBidList[index] as Dictionary<String,Any>
            dictParam["cId"] = dictData["c_id"] as! String
            dictParam["status"] = "disapprove"
            dictParam["postId"] = dictData["post_id"] as! String
            
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "viewReceivedBidOrStatusChange", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrBidList.remove(at: index)
                        self.tblBids.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceDownloadPost(index : NSInteger) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            let dictData = arrBidList[index] as Dictionary<String,Any>
            dictParam["postId"] = dictData["post_id"] as! String
            
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "downloadAttach", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    //MARK:- Custom Method
    func convertDate(strDate:String) -> String {
        let formater = DateFormatter()
        formater.dateFormat = "yyyy-MM-dd HH:mm:ss"
        //let strTrasDate = dictData["payed_date"] as? String
        let trasDate = formater.date(from: strDate)
        
        formater.dateFormat = "MMM dd, yyyy"
        let strTrasDate = formater.string(from: trasDate!)
        return strTrasDate
    }
}


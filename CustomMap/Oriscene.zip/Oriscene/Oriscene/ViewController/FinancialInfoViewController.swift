//
//  FinancialInfoViewController.swift
//  Oriscene
//
//  Created by Parth on 18/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol FinacialInfoVCDelegate {
    func btnVerifiedPaypalSuccessfully() -> Void
}

class FinancialInfoViewController: BaseViewController, UITextFieldDelegate, PayPalFuturePaymentDelegate, PayPalPaymentDelegate {
    
    var delegate : FinacialInfoVCDelegate?
    var isfromWithDrawForVerifyAccount : Bool = false
    var resultText = "" // empty
    var payPalConfig = PayPalConfiguration() // default
    var selectedAccountOption = ""
    var service = WebService()
    
    // MARK: - Control Outlet
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var viewContent: UIView!
    @IBOutlet var btnBuyer: UIButton!
    @IBOutlet var btnSeller: UIButton!
    @IBOutlet var btnBoth: UIButton!
    @IBOutlet var viewEmailHeaderContainer: UIView!
    @IBOutlet var lblEmailHeader: UILabel!
    @IBOutlet var viewEmailContainer: UIView!
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var imgEmail: UIImageView!
    @IBOutlet var btnUpdate: UIButton!
    @IBOutlet var btnVerifyPaypalEmail: UIButton!
    
    
    // MARK: - UIView Constrant Outlet
    @IBOutlet var bottomConstScrollView: NSLayoutConstraint!
    
    
    // MARK: - UIView Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up payPalConfig
        payPalConfig.acceptCreditCards = false
        payPalConfig.merchantName = "Oriscene, Inc."
        payPalConfig.merchantPrivacyPolicyURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/privacy-full")
        payPalConfig.merchantUserAgreementURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/useragreement-full")
        
        // Setting the languageOrLocale property is optional.
        //
        // If you do not set languageOrLocale, then the PayPalPaymentViewController will present
        // its user interface according to the device's current language setting.
        //
        // Setting languageOrLocale to a particular language (e.g., @"es" for Spanish) or
        // locale (e.g., @"es_MX" for Mexican Spanish) forces the PayPalPaymentViewController
        // to use that language/locale.
        //
        // For full details, including a list of available languages and locales, see PayPalPaymentViewController.h.
        
        payPalConfig.languageOrLocale = Locale.preferredLanguages[0]
        
        // Setting the payPalShippingAddressOption property is optional.
        //
        // See PayPalConfiguration.h for details.
        
        payPalConfig.payPalShippingAddressOption = .none;
        
        print("PayPal iOS SDK Version: \(PayPalMobile.libraryVersion())")
        
        // Do any additional setup after loading the view.
        setUserData()
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstScrollView?.constant = 0.0
            } else {
                self.bottomConstScrollView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    // MARK: - Action Method
    
    @IBAction func btnUpdateAction(_ sender: Any) {
        if validateFinancialDetail() {
            //call webservice
            callWebserviceUpdateAccountDetail()
        }
    }
    @IBAction func btnBuyerAction(_ sender: Any) {
        btnBuyer.isSelected = true
        btnSeller.isSelected = false
        btnBoth.isSelected = false
        selectedAccountOption = "Buyer"
    }
    @IBAction func btnSellerAction(_ sender: Any) {
        btnBuyer.isSelected = false
        btnSeller.isSelected = true
        btnBoth.isSelected = false
        selectedAccountOption = "Seller"
    }
    @IBAction func btnBothAction(_ sender: Any) {
        btnBuyer.isSelected = false
        btnSeller.isSelected = false
        btnBoth.isSelected = true
        selectedAccountOption = "Both"
    }
    
    
    @IBAction func btnVerifyPaypalEmailAction(_ sender: Any) {
        
        self.callWebserviceGetCommonSiteSetting()
        
    }
    
    func verifyPaypalAccount(strVerificationCharge : String) -> Void {
        
        // Remove our last completed payment, just for demo purposes.
        resultText = ""
        
        let item1 = PayPalItem(name: "Oriscene", withQuantity: 1, withPrice: NSDecimalNumber(string: strVerificationCharge), withCurrency: "USD", withSku: "Hip-0037")
        
        let items = [item1]
        let subtotal = PayPalItem.totalPrice(forItems: items)
        
        // Optional: include payment details
        let shipping = NSDecimalNumber(string: "0.0")
        let tax = NSDecimalNumber(string: "0.0")
        let paymentDetails = PayPalPaymentDetails(subtotal: subtotal, withShipping: shipping, withTax: tax)
        
        let total = subtotal.adding(shipping).adding(tax)
        
        let payment = PayPalPayment(amount: total, currencyCode: "USD", shortDescription: "Verification Charge", intent: .sale)
        
        payment.items = items
        payment.paymentDetails = paymentDetails
        
        if (payment.processable) {
            let paymentViewController = PayPalPaymentViewController(payment: payment, configuration: payPalConfig, delegate: self)
            present(paymentViewController!, animated: true, completion: nil)
        }
        else {
            // This particular payment will always be processable. If, for
            // example, the amount was negative or the shortDescription was
            // empty, this payment wouldn't be processable, and you'd want
            // to handle that here.
            print("Payment not processalbe: \(payment)")
        }
    }
    
    // MARK: - Set UI and User Data
    
    func setupUI() -> Void {
        viewEmailContainer.layer.cornerRadius = 3.0
        viewEmailContainer.layer.borderColor = UIColor.lightGray.cgColor
        viewEmailContainer.layer.borderWidth = 1.0
        viewEmailContainer.layer.masksToBounds = true
        
        btnUpdate.layer.cornerRadius = 3.0
        btnUpdate.layer.masksToBounds = true
    }
    
    func setUserData() -> Void {
        let userDefault = UserDefaults.standard.dictionaryRepresentation()
        if userDefault.keys.contains("business_data") {
            let dictUser = userDefault["business_data"] as! Dictionary<String,Any>
            print(dictUser)
            //should be Buyer,Seller,Both
            
            let strAccountType = dictUser["accountoptions"] as! String
            
            if strAccountType.characters.count > 0 {
                if strAccountType == "Buyer" {
                    selectedAccountOption = "Buyer"
                    btnBuyer.isSelected = true
                    btnBoth.isSelected = false
                    btnSeller.isSelected = false
                }
                else if strAccountType == "Seller" {
                    selectedAccountOption = "Seller"
                    btnBuyer.isSelected = false
                    btnBoth.isSelected = false
                    btnSeller.isSelected = true
                }
                else if strAccountType == "Both" {
                    selectedAccountOption = "Both"
                    btnBuyer.isSelected = false
                    btnBoth.isSelected = true
                    btnSeller.isSelected = false
                }
                else{
                    selectedAccountOption = ""
                }
            }else {
                selectedAccountOption = ""
            }
            
            let strEmail = dictUser["paypalemail"] as! String
            if strEmail.characters.count > 0 {
                txtEmail.text = strEmail
            }else {
                txtEmail.text = ""
            }
            
            let strpaypal_verify = dictUser["paypal_verify"] as! String
            if (strpaypal_verify == "1") {
                self.lblEmailHeader.text = "Paypal Email"
                self.btnVerifyPaypalEmail.isHidden = true
            }
            else{
                self.lblEmailHeader.text = "Paypal Email (Email Not Verified)"
                self.btnVerifyPaypalEmail.isHidden = false
            }
        }
    }
    
    // MARK: - PayPalPaymentDelegate
    
    func payPalPaymentDidCancel(_ paymentViewController: PayPalPaymentViewController) {
        print("PayPal Payment Cancelled")
        resultText = ""
        paymentViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalPaymentViewController(_ paymentViewController: PayPalPaymentViewController, didComplete completedPayment: PayPalPayment) {
        print("PayPal Payment Success !")
        paymentViewController.dismiss(animated: true, completion: { () -> Void in
            // send completed confirmaion to your server
            print("Here is your proof of payment:\n\n\(completedPayment.confirmation)\n\nSend this to your server for confirmation and fulfillment.")
            
            let dictConfirmation = completedPayment.confirmation as! Dictionary<String,Any>
            let dictResponse = dictConfirmation["response"] as! Dictionary<String,Any>
            let dictParam = NSMutableDictionary()
            
            dictParam["paymentTransId"] = dictResponse["id"] as! String
            
            self.callWebserviceConfirmVerify(dictParam: dictParam)
            self.resultText = completedPayment.description
        })
    }
    // MARK: Future Payments
    
    func payPalFuturePaymentDidCancel(_ futurePaymentViewController: PayPalFuturePaymentViewController) {
        print("PayPal Future Payment Authorization Canceled")
        futurePaymentViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalFuturePaymentViewController(_ futurePaymentViewController: PayPalFuturePaymentViewController, didAuthorizeFuturePayment futurePaymentAuthorization: [AnyHashable: Any]) {
        print("PayPal Future Payment Authorization Success!")
        // send authorization to your server to get refresh token.
        futurePaymentViewController.dismiss(animated: true, completion: { () -> Void in
            self.resultText = futurePaymentAuthorization.description
            self.showAlert(string: self.resultText)
        })
    }
    
    //MARK:- Validation Method
    func validateFinancialDetail() -> Bool {
        if selectedAccountOption == "" {
            showAlert(string: Constant.ALERT_MSG_ACCOUNT_OPTION_VALIDATE)
            return false
        }
        else if trimString(string: (txtEmail.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_PAYPAL_EMIAL_VALIDATE)
            return false
        }
        else if !self.isValidEmail(testStr: self.trimString(string:(txtEmail.text!))) {
            self.showAlert(string: Constant.ALERT_MSG_EMAIL_VALIDATE_FROMAT)
            return false
        }
        else{
            return true
        }
    }
    
    //MARK:- Webservice Method
    func callWebserviceUpdateAccountDetail() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            dictParam["forWhat"] = "5"
            dictParam["accountOption"] = selectedAccountOption
            dictParam["paypalEmail"] = txtEmail.text
            let userDefault = UserDefaults.standard.dictionaryRepresentation()
            if userDefault.keys.contains("business_data") {
                let dictUser = userDefault["business_data"] as! Dictionary<String,Any>
                let strEmail = dictUser["paypalemail"] as! String
                dictParam["priviousPaypalEmail"] = strEmail
            }
            else{
                dictParam["priviousPaypalEmail"] = ""
            }
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "updateProfile", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        let userDefault = UserDefaults.standard
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                            userDefault.synchronize()
                            self.setUserData()
                        }
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            })
            
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceConfirmVerify(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            service.callJSONMethod(methodName: "verifyPaypalAccount", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.showAlert(string: dict?["message"] as! String)
                        let userDefault = UserDefaults.standard
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                            userDefault.synchronize()
                            self.setUserData()
                            if self.isfromWithDrawForVerifyAccount {
                                self.delegate?.btnVerifiedPaypalSuccessfully()
                                self.navigationController!.popViewController(animated: true)
                            }
                        }
                    }
                    else if dict?["status"] as! String == "4" {
                        let alert:UIAlertController=UIAlertController(title: Constant.APP_NAME , message: dict?["message"] as? String, preferredStyle: UIAlertControllerStyle.alert)
                        let okAction = UIAlertAction(title: "YES", style: UIAlertActionStyle.default)
                        {
                            UIAlertAction in
                            dictParam["forYes"] = "1"
                            dictParam["forNo"] = ""
                            self.callWebserviceConfirmVerify(dictParam: dictParam)
                        }
                        let cancelAction = UIAlertAction(title: "NO", style: UIAlertActionStyle.default)
                        {
                            UIAlertAction in
                            dictParam["forYes"] = ""
                            dictParam["forNo"] = "1"
                            self.callWebserviceConfirmVerify(dictParam: dictParam)
                        }
                        alert.addAction(okAction)
                        alert.addAction(cancelAction)
                        self.present(alert, animated: true, completion: nil)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceGetCommonSiteSetting() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "getCommonSiteSetting", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        let dictSite = dict?["data"] as! Dictionary<String,Any>
                        let strAmount = dictSite["paypal_verify_amt"] as! String
                        self.verifyPaypalAccount(strVerificationCharge: strAmount)
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                else{
                    self.hideSpinner()
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            })
            
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

//
//  SettingsViewController.swift
//  Oriscene
//
//  Created by Parth on 12/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

enum SettingsIndex: Int {
    case BASIC_INFORMATION = 0, EDIT_PASSWORD, ACCOUNT_DETAILS, CONTACT_INFORMATION, FINANCIAL_INFORMATION, CATEGORIES
}

class SettingsViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    
    var arrSettingList = [Dictionary<String,String>]()
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var tblSettings: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        tblSettings.register(SettingsListTVCell.self, forCellReuseIdentifier: "SettingsListTVCell")
        tblSettings.register(UINib.init(nibName: "SettingsListTVCell", bundle: nil), forCellReuseIdentifier: "SettingsListTVCell")
        
        self.setUI()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK: - Custom Method
    
    func setUI() -> Void {
        arrSettingList = [ [ "settingTitle" : "Basic Information" ] , [ "settingTitle" : "Edit Password" ] , [ "settingTitle" : "Account Details" ] , [ "settingTitle" : "Contact Information" ] , [ "settingTitle" : "Financial Information" ] , [ "settingTitle" : "Categories" ] ]
        tblSettings.reloadData()
    }
    
    // MARK: - UITableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSettingList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "SettingsListTVCell") as! SettingsListTVCell
        cell.index = indexPath.row
        
        let dict = arrSettingList[indexPath.row] as Dictionary
        
        cell.lblSetting.text = dict["settingTitle"]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65.0
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case SettingsIndex.BASIC_INFORMATION.rawValue:
            let vcBasicInfo = self.storyboard?.instantiateViewController(withIdentifier: "BasicInformationViewController") as! BasicInformationViewController
            vcBasicInfo.isPopAllowed = true
            self.navigationController?.pushViewController(vcBasicInfo, animated: true)
            break
        case SettingsIndex.EDIT_PASSWORD.rawValue:
            let vcEditPassword = self.storyboard?.instantiateViewController(withIdentifier: "EditPasswordViewController") as! EditPasswordViewController
            self.navigationController?.pushViewController(vcEditPassword, animated: true)
            break
        case SettingsIndex.ACCOUNT_DETAILS.rawValue:
            let vcAccountDtl = self.storyboard?.instantiateViewController(withIdentifier: "AccountDetailViewController") as! AccountDetailViewController
            self.navigationController?.pushViewController(vcAccountDtl, animated: true)
            break
        case SettingsIndex.CONTACT_INFORMATION.rawValue:
            let vcContactInfo = self.storyboard?.instantiateViewController(withIdentifier: "ContactInfoViewController") as! ContactInfoViewController
            self.navigationController?.pushViewController(vcContactInfo, animated: true)
            break
        case SettingsIndex.FINANCIAL_INFORMATION.rawValue:
            let vcContactInfo = self.storyboard?.instantiateViewController(withIdentifier: "FinancialInfoViewController") as! FinancialInfoViewController
            self.navigationController?.pushViewController(vcContactInfo, animated: true)
            break
        case SettingsIndex.CATEGORIES.rawValue:
            let vcCategory = self.storyboard?.instantiateViewController(withIdentifier: "CategoriesViewController") as! CategoriesViewController
            self.navigationController?.pushViewController(vcCategory, animated: true)
            break
            
        default:
            break
            
        }
    }
}

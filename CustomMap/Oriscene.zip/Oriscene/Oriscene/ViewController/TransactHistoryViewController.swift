//
//  TransactHistoryViewController.swift
//  Oriscene
//
//  Created by TriState  on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

extension UIToolbar {
    
    func ToolbarPiker(mySelect : Selector) -> UIToolbar {
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.barTintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        doneButton.tintColor = UIColor.white
        //        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        return toolBar
    }
}

class TransactHistoryViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate{

    var service = WebService()
    var arrTranHistory = [Dictionary<String,Any>]()
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var viewRedius: [UIView]!
    @IBOutlet var btnSearch: UIButton!
    @IBOutlet var tblTransactHistory: UITableView!
    
    @IBOutlet var txtStartDate: UITextField!
    @IBOutlet var txtToDate: UITextField!
    @IBOutlet var txtBuyerName: UITextField!
    let datePickerView:UIDatePicker = UIDatePicker()
    var isFromDate:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupTransactionHistoryUI()
        // Do any additional setup after loading the view.
        let dictParam = NSMutableDictionary()
        dictParam["forSearch"] = ""
        dictParam["fromTxn"] = ""
        dictParam["toTxn"] = ""
        dictParam["buyerName"] = ""
        callWebserviceTransactionHistory(dictParam: dictParam)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupTransactionHistoryUI() {
        self.tblTransactHistory.register(TransactHistoryTVCell.self, forCellReuseIdentifier: "TransactHistoryTVCell")
        self.tblTransactHistory.register(UINib.init(nibName: "TransactHistoryTVCell", bundle: nil), forCellReuseIdentifier: "TransactHistoryTVCell")
        
        btnSearch.layer.cornerRadius = 3.0
        btnSearch.layer.masksToBounds = true
        
        self.tblTransactHistory.tableHeaderView = self.viewHeader
        
        for (_, element) in viewRedius.enumerated() {
            element.layer.cornerRadius = 5.0
            element.layer.masksToBounds = true
            element.layer.borderColor = UIColor.lightGray.cgColor
            element.layer.borderWidth = 0.5
        }
    }
    
    
    // MARK: - UITableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTranHistory.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "TransactHistoryTVCell") as! TransactHistoryTVCell
        let dictData = arrTranHistory[indexPath.row] 
        cell.lblOrderNumber.text = dictData["pp_txnid"] as? String
        cell.lblBuyerName.text = dictData["buyer_name"] as? String
        cell.lblPrice.text = dictData["payed_amount"] as? String
        if dictData["payment_status"] as? String == "yes" {
             cell.lblStatus.text = "Successful"
        }else{
             cell.lblStatus.text = "Pending"
        }
        let formater = DateFormatter()
        formater.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let strTrasDate = dictData["payed_date"] as? String
        let trasDate = formater.date(from: strTrasDate!)
        
        formater.dateFormat = "MMM dd, yyyy"
        let strNewDate = formater.string(from: trasDate!)
        cell.lblOrderDate.text = strNewDate
       
        cell.selectionStyle = .none
 
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 192.0
    }
    
    // MARK: - UITableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
 
    // MARK: - Navigation UITextFieldDelegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        datePickerView.datePickerMode = UIDatePickerMode.date
        datePickerView.maximumDate = NSDate() as Date
//        datePickerView.minimumDate = NSDate().addingTimeInterval(-(60 * 60 * 24 * 365)) as Date
        datePickerView.addTarget(self, action: #selector(datePickerChanged(sender:)), for: .valueChanged)
        let toolBar = UIToolbar().ToolbarPiker(mySelect: #selector(self.dismissPicker))
        
        if(textField == self.txtStartDate)
        {
            isFromDate = 1;
            txtStartDate.inputView = datePickerView
            txtStartDate.inputAccessoryView = toolBar
        }
        else if (textField == self.txtToDate)
        {
            isFromDate = 0;
            txtToDate.inputView = datePickerView
            txtToDate.inputAccessoryView = toolBar
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    // MARK: - Button Action 
    @IBAction func btnSearchClickAction(_ sender: Any) {
        view.endEditing(true)
        if validateDateSelection() {
            let dateFormater = DateFormatter()
            dateFormater.dateFormat = "dd/MM/yyyy"
            
            let dictParam = NSMutableDictionary()
            if (txtBuyerName.text?.characters.count)! > 0 {
                dictParam["buyerName"] = txtBuyerName.text
            }else{
                dictParam["buyerName"] = ""
            }
            if (txtStartDate.text?.characters.count)! > 0 {
                let newDate = dateFormater.date(from: txtStartDate.text!)
                dateFormater.dateFormat = "yyyy-MM-dd"
                let strDate = dateFormater.string(from: newDate!)
                dictParam["fromTxn"] = strDate
            }else{
                dictParam["fromTxn"] = ""
            }
            if (txtToDate.text?.characters.count)! > 0 {
                dateFormater.dateFormat = "dd/MM/yyyy"
                let newDate = dateFormater.date(from: txtToDate.text!)
                dateFormater.dateFormat = "yyyy-MM-dd"
                let strDate = dateFormater.string(from: newDate!)
                dictParam["toTxn"] = strDate
            }else {
                dictParam["toTxn"] = ""
            }
            dictParam["forSearch"] = "1"
            callWebserviceTransactionHistory(dictParam: dictParam)
        }
     
    }
  
    // MARK: - DatePicker Method
    func datePickerChanged(sender: UIDatePicker) {
        setSelectedDate()
    }
    func dismissPicker() {
        setSelectedDate()
        view.endEditing(true)
    }
    func setSelectedDate() -> Void {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        let dateString = dateFormatter.string(from:datePickerView.date)
        
        if(isFromDate == 1)
        {
            txtStartDate.text = dateString
        }
        else{
            txtToDate.text = dateString
        }
    }
    func validateDateSelection() -> Bool {
        if (txtStartDate.text?.characters.count)! <= 0 && (txtToDate.text?.characters.count)! > 0 {
            self.showAlert(string: Constant.ALERT_MSG_TRANS_START_DATE_VALIDATE)
            return false
        }
        else if (txtToDate.text?.characters.count)! <= 0 && (txtStartDate.text?.characters.count)! > 0 {
            self.showAlert(string: Constant.ALERT_MSG_TRANS_TO_DATE_VALIDATE)
            return false
        }
        
        if (txtStartDate.text?.characters.count)! > 0 {
            if (txtToDate.text?.characters.count)! > 0 {
                let dateFormater = DateFormatter()
                dateFormater.dateFormat = "dd/MM/yyyy"
                let startDate = dateFormater.date(from: txtStartDate.text!)
                let toDate = dateFormater.date(from: txtToDate.text!)
                if startDate! > toDate! {
                    self.showAlert(string: "invalid to date")
                    return false
                }
            }
        }
        return true;
    }
    
    //MARK:- Webservice Method
    func callWebserviceTransactionHistory(dictParam : NSMutableDictionary ) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinnerForChildVC(enableInteraction: false)
            service.callJSONMethod(methodName: "getTransactionHistory", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        print(dict!)
                        self.arrTranHistory = dict?["data"] as! [Dictionary<String,Any>]
                        self.tblTransactHistory.reloadData()
                    }
                    else{
                        if self.arrTranHistory.count > 0 {
                            self.arrTranHistory.removeAll()
                            self.tblTransactHistory.reloadData()
                        }
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

//
//  PostDetailViewController.swift
//  Oriscene
//
//  Created by Parth on 14/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

protocol PostDetailScreenDelegate {
    func deletePostWithIndex(indexOfPost : NSInteger) -> Void
    func replacePostDataWithIndex(indexOfObject : NSInteger, andPostDict: NSDictionary) -> Void
    func addNewSharedPost(indexOfObject: NSInteger, andSharedPostDict: NSDictionary) -> Void
    func reloadPostData() -> Void
    func updateCountForSamePost(dictPostIndi: Dictionary<String,Any>)
    func updateFollowUnFollowButton(isSetFollow : Bool) -> Void
}

class PostDetailViewController: BaseViewController , UIScrollViewDelegate , UITableViewDelegate , UITableViewDataSource , PostCommentViewDelegate , PostCommentSectionViewDelegate, SharePostDelegate, UICollectionViewDelegate, UICollectionViewDataSource, BidPriceDelegate, PostListingDelegate, UISearchBarDelegate, CreatePostCategoryDelegate, AudioPlayViewDelegate, DocumentViewerViewDelegate, PostImageViewDelegate, PostDetailViewDelegate,PostCommentReplyDelegate,CommentEditViewDelegate,UIAlertViewDelegate,UITextViewDelegate{
    
    var delegate : PostDetailScreenDelegate?
    
    let service = WebService()
    var dictPostDetail = Dictionary<String, Any>()
    var arrPostImages = [Dictionary<String,Any>]()
    var arrPostAction = [Dictionary<String,Any>]()
    var arrMoreAction = [Dictionary<String,Any>]()
    var arrPost = [Dictionary<String,Any>]()
    var arrComment = [Dictionary<String,Any>]()
    var arrReply = [Dictionary<String,Any>]()
    var isFromNotification: NSInteger = 0
    var strPostId: String = ""
    var viewAudioPlay : AudioPlayView? = nil
    var viewDocumentViewer : DocumentViewerView? = nil
    var viewPostComments : PostCommentView? = nil
    var viewPostShare : PostShareView? = nil
    var viewBidPrice : BidPriceView? = nil
    var viewPostImage : PostImageView? = nil
    var viewPostDetail : PostDetailView? = nil
    var viewCommentEdit : CommentEditView? = nil
    var player : AVPlayer?
    var iDeleteIndex = NSInteger()
    var intSelectedRowForComment : NSInteger = -1
    var intSelectedSectionForComment : NSInteger = -1
    
    var isNeedToReloadData = false
    
    @IBOutlet var btnSendComment: UIButton!
    @IBOutlet var txtViewWriteComment: UITextView!
    
    @IBOutlet var lblComment: UILabel!
    @IBOutlet var bottomConstContainerView: NSLayoutConstraint!
    @IBOutlet var viewShadowOfWriteCommentContainer: UIView!
    @IBOutlet var viewWriteCommentContainer: UIView!
    @IBOutlet weak var lblLocation: UILabel!
    
    var intCurrentRow : NSInteger = -1
    var currentPostType : NSInteger = -1
    var textviewCheck: NSInteger = 0
    
    var dictSelectedCatgeroy : Dictionary<String, String>?
    var arrSelectedCategoryForFilter = [Dictionary<String,String>]()
    
    @IBOutlet var tblPostDetails: UITableView!
    @IBOutlet var viewHeaderPostDetail: UIView!
    @IBOutlet var viewTopBar: UIView!
    @IBOutlet var btnBack: UIButton!
    @IBOutlet var viewProfileDataContainer: UIView!
    @IBOutlet var imgProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblCategory: UILabel!
    @IBOutlet var lblPostDetail: UILabel!
    @IBOutlet var lblShareText: UILabel!
    @IBOutlet var lblOrgText: UILabel!
    @IBOutlet var lblSeperaterPostDtlOrgText: UILabel!
    
    
    @IBOutlet var viewCommentCnt: UIView!
    @IBOutlet var lblCommentCnt: UILabel!
    @IBOutlet var viewButton: UIView!
    
    @IBOutlet var btnLike: UIButton!
    @IBOutlet var btnUnlike: UIButton!
    @IBOutlet var btnView: UIButton!
    @IBOutlet var btnComment: UIButton!
    @IBOutlet var btnShare: UIButton!
    
    @IBOutlet var cvPostImages: UICollectionView!
    @IBOutlet weak var cvPostAction: UICollectionView!
    
    @IBOutlet var viewTypeContainer: UIView!
    @IBOutlet var imgTypeContainer: UIImageView!
    @IBOutlet var imgVideoSnapshot: UIImageView!
    
    @IBOutlet var viewButtonForSell: UIView!
    @IBOutlet var btnEA: UIButton!
    @IBOutlet var btnChat: UIButton!
    @IBOutlet var btnBid: UIButton!
    
    @IBOutlet var lblDetailsTitle: UILabel!
    
    @IBOutlet var bottomConstTableView: NSLayoutConstraint!
    
    @IBOutlet weak var heightConstHeaderview: NSLayoutConstraint!
    @IBOutlet var searchBar: UISearchBar!
    
    @IBOutlet weak var viewMoreActionContainer: UIView!
    @IBOutlet weak var btnMore: UIButton!
    @IBOutlet weak var cvMoreAction: UICollectionView!
    
    @IBOutlet weak var btnFollow: UIButton!
    @IBOutlet weak var btnPrimePost: UIButton!
    
    @IBOutlet weak var topSpaceLblUserName: NSLayoutConstraint!
    
    @IBOutlet var leadingSpaceViewMoreConst: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupUI()
        
        if isFromNotification == 1{
            self.callgetSingleObjectWebservice()
        }else{
            self.setupUIData()
            self.commentWebservieccall()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if viewPostComments == nil {
            viewPostComments = (PostCommentView.instanceFromNib() as? PostCommentView)!
            viewPostComments?.frame = UIScreen.main.bounds
            viewPostComments?.isHidden = true
            viewPostComments?.delegate = self
            viewPostComments?.alpha = 0.0
            self.view.addSubview(viewPostComments!)
        }
        
        if viewPostShare == nil {
            viewPostShare = (PostShareView.instanceFromNib() as! PostShareView)
            viewPostShare?.frame = UIScreen.main.bounds
            viewPostShare?.isHidden = true
            viewPostShare?.delegate = self
            viewPostShare?.alpha = 0.0
            self.view.addSubview(viewPostShare!)
        }
        
        if viewBidPrice == nil {
            viewBidPrice = (BidPriceView.instanceFromNib() as? BidPriceView)!
            viewBidPrice?.frame = UIScreen.main.bounds
            viewBidPrice?.isHidden = true
            viewBidPrice?.delegate = self
            viewBidPrice?.alpha = 0.0
            self.view.addSubview(viewBidPrice!)
        }
        
        if viewAudioPlay == nil {
            viewAudioPlay = AudioPlayView.instanceFromNib() as? AudioPlayView
            viewAudioPlay?.frame = UIScreen.main.bounds
            viewAudioPlay?.isHidden = true
            viewAudioPlay?.delegate = self
            viewAudioPlay?.alpha = 0.0
            self.view.addSubview(viewAudioPlay!)
        }
        
        if viewDocumentViewer == nil {
            viewDocumentViewer = DocumentViewerView.instanceFromNib() as? DocumentViewerView
            viewDocumentViewer?.frame = UIScreen.main.bounds
            viewDocumentViewer?.isHidden = true
            viewDocumentViewer?.delegate = self
            viewDocumentViewer?.alpha = 0.0
            self.view.addSubview(viewDocumentViewer!)
        }
        
        if viewPostImage == nil {
            viewPostImage = PostImageView.instanceFromNib() as? PostImageView
            viewPostImage?.frame = UIScreen.main.bounds
            viewPostImage?.isHidden = true
            viewPostImage?.delegate = self
            viewPostImage?.alpha = 0.0
            self.view.addSubview(viewPostImage!)
        }
        
        if viewPostDetail == nil {
            viewPostDetail = PostDetailView.instanceFromNib() as? PostDetailView
            viewPostDetail?.frame = UIScreen.main.bounds
            viewPostDetail?.isHidden = true
            viewPostDetail?.delegate = self
            viewPostDetail?.alpha = 0.0
            self.view.addSubview(viewPostDetail!)
        }
        
        if viewCommentEdit == nil {
            viewCommentEdit = CommentEditView.instanceFromNib() as? CommentEditView
            viewCommentEdit?.frame = UIScreen.main.bounds
            viewCommentEdit?.isHidden = true
            viewCommentEdit?.delegate = self
            viewCommentEdit?.alpha = 0.0
            self.view.addSubview(viewCommentEdit!)
        }
    }
    // MARK: - Custom Method
    func setupUIData() -> Void {
        
        self.arrPostAction = dictPostDetail["arrPostAction"] as! [Dictionary<String, Any>]
        self.cvPostAction.reloadData()
        
        let dictPostDtlIndividual = dictPostDetail["postdetailindiv"] as! Dictionary<String,Any>
        let dictPostCategory = dictPostDtlIndividual["categoryindiv"] as! Dictionary<String,Any>
        let dictUserData = dictPostDtlIndividual["postuserdata"] as! Dictionary<String,Any>
        
        if dictUserData.keys.contains("photo") {
            let strPhotoName = dictUserData["photo"] as! String
            if strPhotoName.characters.count != 0 {
                let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                let fileUrl = NSURL(string: strUrl)
                
                self.imgProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                    if error != nil {
                        print("Failed: \(error)")
                    } else {
                        print("Success")
                    }
                }
            }
            else{
                self.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        else{
            self.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
        }
        
        self.lblPostDetail.text = dictPostDtlIndividual["post_content"] as? String
        
        self.lblOrgText.text = dictPostDtlIndividual["share_org_text"] as? String
        self.lblShareText.text = dictPostDtlIndividual["share_text"] as? String
        self.lblLocation.text = dictPostDtlIndividual["cp_loc"] as? String
        
        if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
            let strOrgText = dictPostDtlIndividual["share_org_text"] as? String
            if strOrgText != nil {
                self.lblSeperaterPostDtlOrgText.isHidden = false
            }
            else{
                self.lblSeperaterPostDtlOrgText.isHidden = true
            }
        }
        else{
            self.lblSeperaterPostDtlOrgText.isHidden = true
        }
        
        self.lblShareText.sizeToFit()
        self.lblOrgText.sizeToFit()
        
        self.lblCategory.text = "" + (dictPostCategory["con_name"] as? String)! + "   "
        let strusenickname = dictUserData["usenickname"] as! String
        if strusenickname == "1" {
            lblUserName.text = dictUserData["reporter_name"] as? String
        }
        else{
            lblUserName.text = (dictUserData["firstname"] as! String) + " " + (dictUserData["lastname"] as! String)
        }
        self.lblPostDetail.sizeToFit()
        
        self.viewHeaderPostDetail.frame = CGRect(x: self.viewHeaderPostDetail.frame.origin.x, y: self.viewHeaderPostDetail.frame.origin.y, width: self.viewHeaderPostDetail.frame.size.width, height: 430 + self.lblPostDetail.frame.size.height + self.lblShareText.frame.size.height + self.lblOrgText.frame.size.height + self.lblLocation.frame.size.height)
        
        if dictPostDtlIndividual.keys.contains("is_prime") || dictPostDtlIndividual.keys.contains("need_to_follow") {
            topSpaceLblUserName.constant = 5.0
        }else{
            topSpaceLblUserName.constant = 15.0
        }
        
        if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
            //New Change By Pankaj
            var arrTemp = dictPostDetail["arrMoreAction"] as! [Dictionary<String, Any>]
            for (index, var dictMoreAction) in arrTemp.enumerated() {
                if dictMoreAction.keys.contains("need_to_edt") {
                    arrTemp.remove(at: index)
                }
            }
            
            arrMoreAction = arrTemp
            btnMore.isHidden = false
            if dictPostDtlIndividual.keys.contains("need_to_follow") {
                btnFollow.isHidden = false
            }else{
                btnFollow.isHidden = true
            }
            if dictPostDtlIndividual.keys.contains("is_prime") {
                btnPrimePost.isHidden = false
            }else{
                btnPrimePost.isHidden = true
            }
        }
        else{
            //cell.lblSeperaterForDtlOrgText.isHidden = true
            btnFollow.isHidden = true
            btnPrimePost.isHidden = true
            btnMore.isHidden = true
        }
        self.viewButtonForSell.isHidden = true
        
        if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_IMAGE {
            self.imgVideoSnapshot.isHidden = true
            self.cvPostImages.isHidden = false
            self.imgTypeContainer.isHidden = true
            self.imgTypeContainer.image = #imageLiteral(resourceName: "play_bt")
            self.imgTypeContainer.backgroundColor = UIColor.init(colorLiteralRed: 243.0/255.0, green: 247.0/255.0, blue: 250.0/255.0, alpha: 1.0)
            self.arrPostImages = dictPostDtlIndividual["att_detail"] as! [Dictionary<String,Any>]
            cvPostImages.reloadData()
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_VIDEO {
            
            self.imgVideoSnapshot.contentMode = .redraw
            let arrAttachment = dictPostDtlIndividual["att_detail"] as! [Dictionary<String,Any>]
            if arrAttachment.count != 0 {
                
                DispatchQueue.global().async {
                    let dictAttachment = arrAttachment[0]
                    var strBaseUrl = ""
                    if self.currentPostType == CurrentSelectedPostType.BOTH.rawValue || self.currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                        strBaseUrl = VIDEO_ATTACHMENT_BASE_URL
                    }
                    else if self.currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
                        strBaseUrl = SELL_VIDEO_ATTACHMENT_BASE_URL
                    }
                    
                    let strUrl = strBaseUrl + (dictAttachment["attachment_name"] as! String)
                    let sourceURL = URL(string: strUrl)
                    let asset = AVAsset(url: sourceURL!)
                    let imageGenerator = AVAssetImageGenerator(asset: asset)
                    let time = CMTimeMake(1, 1)
                    
                    do{
                        let imageRef = try imageGenerator.copyCGImage(at: time, actualTime: nil)
                        DispatchQueue.main.async {
                            self.imgVideoSnapshot.image = UIImage(cgImage:imageRef)
                        }
                    }
                    catch{
                    }
                }
            }
            
            self.imgVideoSnapshot.isHidden = false
            
            self.cvPostImages.isHidden = true
            self.imgTypeContainer.isHidden = false
            self.imgTypeContainer.image = #imageLiteral(resourceName: "play_bt")
            self.imgTypeContainer.backgroundColor = UIColor.clear
            self.arrPostImages = [Dictionary<String,Any>]()
            cvPostImages.reloadData()
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_AUDIO {
            self.imgVideoSnapshot.isHidden = true
            self.cvPostImages.isHidden = true
            self.imgTypeContainer.isHidden = false
            self.imgTypeContainer.image = #imageLiteral(resourceName: "audio_img")
            self.imgTypeContainer.backgroundColor = UIColor.init(colorLiteralRed: 243.0/255.0, green: 247.0/255.0, blue: 250.0/255.0, alpha: 1.0)
            self.arrPostImages = [Dictionary<String,Any>]()
            cvPostImages.reloadData()
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_DOCUMENT {
            self.imgVideoSnapshot.isHidden = true
            self.cvPostImages.isHidden = true
            self.imgTypeContainer.isHidden = false
            self.imgTypeContainer.image = #imageLiteral(resourceName: "doc_img")
            self.imgTypeContainer.backgroundColor = UIColor.init(colorLiteralRed: 243.0/255.0, green: 247.0/255.0, blue: 250.0/255.0, alpha: 1.0)
            self.arrPostImages = [Dictionary<String,Any>]()
            cvPostImages.reloadData()
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_LOCATION {
            
            self.arrPostImages = [Dictionary<String,Any>]()
            cvPostImages.reloadData()
            self.cvPostImages.isHidden = true
            self.imgTypeContainer.isHidden = true
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_YOUTUBE {
            //YouTube Video Link Redirect to video player
            
            var strPostContent = dictPostDtlIndividual["post_content"] as! String
            
            let detector = try! NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
            let matches = detector.matches(in: strPostContent , options: [], range: NSRange(location: 0, length: (strPostContent.utf16.count)))
            if matches.count != 0 {
                let match = matches[0]
                let url = (strPostContent as NSString).substring(with: match.range)
                strPostContent = strPostContent.replacingOccurrences(of: url, with: "")
                self.lblPostDetail.text = strPostContent
                let array = url.components(separatedBy: "?")
                if array.count != 0 {
                    var strYouTubeID = array[1]
                    strYouTubeID = strYouTubeID.replacingOccurrences(of: "v=", with: "")
                    let strUrl = "http://img.youtube.com/vi/" + strYouTubeID + "/0.jpg"
                    
                    let fileUrl = NSURL(string: strUrl)
                    
                    self.imgVideoSnapshot.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    self.imgVideoSnapshot.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                self.imgVideoSnapshot.image = #imageLiteral(resourceName: "default_img")
            }
            self.imgVideoSnapshot.isHidden = false
            self.imgTypeContainer.backgroundColor = UIColor.clear
            self.cvPostImages.isHidden = true
            self.imgTypeContainer.isHidden = false
            self.imgTypeContainer.image = #imageLiteral(resourceName: "play_bt")
            self.imgVideoSnapshot.layoutIfNeeded()
            self.arrPostImages = [Dictionary<String,Any>]()
            cvPostImages.reloadData()
        }
        else {
            self.arrPostImages = [Dictionary<String,Any>]()
            cvPostImages.reloadData()
            self.cvPostImages.isHidden = true
            self.imgTypeContainer.image = nil
            self.imgTypeContainer.isHidden = false
            self.imgVideoSnapshot.isHidden = true
            self.imgTypeContainer.backgroundColor = UIColor.lightGray
        }
    }
    func callgetSingleObjectWebservice() -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = strPostId;
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            dictParam["forSingleObject"] = "1";
            self.tblPostDetails.isHidden = true
            
            service.callJSONMethod(methodName: "getSingleObject", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                self.tblPostDetails.isHidden = false
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrPost = dict?["data"] as! [Dictionary<String,Any>]
                        if self.arrPost.count > 0 {
                            self.filterPostarray()
                            self.dictPostDetail = self.arrPost[0]
                            self.setupUIData()
                            self.commentWebservieccall()
                        }else{
                            self.showAlert(string: "Post details not found")
                            self.navigationController!.popViewController(animated: true)
                        }
                        
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
        
    }
    func commentWebservieccall() -> Void {
        let dictPostDtlIndividual = dictPostDetail["postdetailindiv"] as! Dictionary<String,Any>
        
        let dictParam = NSMutableDictionary()
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        dictParam["type"] = "view";
        callWebserviceViewCommentsSharePost(dictParam: dictParam)
    }
    func setupUI() -> Void {
        self.automaticallyAdjustsScrollViewInsets = false
        
        self.viewMoreActionContainer.transform = CGAffineTransform(translationX: 500, y: 0)
        
        tblPostDetails.register(PostCommentTVCell.self, forCellReuseIdentifier: "PostCommentTVCell")
        tblPostDetails.register(UINib.init(nibName: "PostCommentTVCell", bundle: nil), forCellReuseIdentifier: "PostCommentTVCell")
        
        tblPostDetails.register(PostCommentReplyTVCell.self, forCellReuseIdentifier: "PostCommentReplyTVCell")
        tblPostDetails.register(UINib.init(nibName: "PostCommentReplyTVCell", bundle: nil), forCellReuseIdentifier: "PostCommentReplyTVCell")
        
        cvPostImages.register(PostImagesCVCell.self, forCellWithReuseIdentifier: "PostImagesCVCell")
        cvPostImages.register(UINib.init(nibName: "PostImagesCVCell", bundle: nil), forCellWithReuseIdentifier: "PostImagesCVCell")
        
        self.cvPostAction.register(UINib(nibName: "PostActionCVCell", bundle: nil), forCellWithReuseIdentifier: "PostActionCVCell")
        
        cvMoreAction.register(UINib.init(nibName: "PostMoreActionCVCell", bundle: nil), forCellWithReuseIdentifier: "PostMoreActionCVCell")
        let tapForLabel = UITapGestureRecognizer(target: self, action: #selector(tapFunction))
        tapForLabel.numberOfTapsRequired = 1
        lblUserName.isUserInteractionEnabled = true
        lblUserName.addGestureRecognizer(tapForLabel)
        
        let tapForImage = UITapGestureRecognizer(target: self, action: #selector(tapFunction))
        tapForImage.numberOfTapsRequired = 1
        lblUserName.isUserInteractionEnabled = true
        lblUserName.addGestureRecognizer(tapForImage)
        
        let tapForImageAttachment = UITapGestureRecognizer(target: self, action: #selector(tapImageAttachment))
        tapForImageAttachment.numberOfTapsRequired = 1
        imgTypeContainer.isUserInteractionEnabled = true
        imgTypeContainer.addGestureRecognizer(tapForImageAttachment)
        
        self.view.layoutIfNeeded()
        btnBack.layer.cornerRadius = btnBack.frame.size.height/2
        btnBack.layer.masksToBounds = true
        
        btnLike.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnLike.layer.borderWidth = 1.0
        btnLike.layer.cornerRadius = 12.0
        btnLike.layer.masksToBounds = true
        
        btnUnlike.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnUnlike.layer.borderWidth = 1.0
        btnUnlike.layer.cornerRadius = 12.0
        btnUnlike.layer.masksToBounds = true
        
        btnView.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnView.layer.borderWidth = 1.0
        btnView.layer.cornerRadius = 12.0
        btnView.layer.masksToBounds = true
        
        btnComment.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnComment.layer.borderWidth = 1.0
        btnComment.layer.cornerRadius = 12.0
        btnComment.layer.masksToBounds = true
        
        btnShare.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnShare.layer.borderWidth = 1.0
        btnShare.layer.cornerRadius = 12.0
        btnShare.layer.masksToBounds = true
        
        btnEA.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnEA.layer.borderWidth = 1.0
        btnEA.layer.cornerRadius = 12.0
        btnEA.layer.masksToBounds = true
        
        btnChat.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnChat.layer.borderWidth = 1.0
        btnChat.layer.cornerRadius = 12.0
        btnChat.layer.masksToBounds = true
        
        btnBid.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnBid.layer.borderWidth = 1.0
        btnBid.layer.cornerRadius = 12.0
        btnBid.layer.masksToBounds = true
        
        lblCategory.layer.cornerRadius = 3.0
        lblCategory.layer.masksToBounds = true
        
        imgProfilePic.layer.cornerRadius = imgProfilePic.frame.size.height / 2.0
        imgProfilePic.layer.masksToBounds = true
        
        btnSendComment.layer.cornerRadius = btnSendComment.frame.size.height / 2
        btnSendComment.layer.masksToBounds = true
        
        viewShadowOfWriteCommentContainer.layer.shadowColor = UIColor.lightGray.cgColor
        viewShadowOfWriteCommentContainer.layer.shadowOpacity = 1
        viewShadowOfWriteCommentContainer.layer.shadowOffset = CGSize.zero
        viewShadowOfWriteCommentContainer.layer.shadowRadius = 10
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
        
        viewButtonForSell.isHidden = true
        if intCurrentRow % 2 == 0 && intCurrentRow % 4 != 0 {
            cvPostImages.isHidden = true
            imgTypeContainer.isHidden = false
            imgTypeContainer.image = #imageLiteral(resourceName: "play_bt")
        }
        else if intCurrentRow % 3 == 0 {
            cvPostImages.isHidden = true
            imgTypeContainer.isHidden = false
            imgTypeContainer.image = #imageLiteral(resourceName: "map_icon_sel_create_post")
        }
        else if intCurrentRow % 4 == 0 {
            cvPostImages.isHidden = true
            imgTypeContainer.isHidden = false
            imgTypeContainer.image = #imageLiteral(resourceName: "doc_img")
        }
        else if intCurrentRow % 5 == 0 {
            cvPostImages.isHidden = true
            imgTypeContainer.isHidden = false
            imgTypeContainer.image = #imageLiteral(resourceName: "audio_img")
        }
        else{
            cvPostImages.isHidden = false
            imgTypeContainer.isHidden = true
            
            switch currentPostType {
            case CurrentSelectedPostType.SHARE_POST.rawValue:
                viewButtonForSell.isHidden = true
                break
            case CurrentSelectedPostType.SELL_POST.rawValue:
                viewButtonForSell.isHidden = false
                break
            case CurrentSelectedPostType.BOTH.rawValue:
                if intCurrentRow % 2 == 0 {
                    viewButtonForSell.isHidden = true
                }
                else{
                    viewButtonForSell.isHidden = false
                }
                break
            default:
                break
            }
        }
        
        reloadImages()
        
        lblDetailsTitle.layer.cornerRadius = 5.0
        lblDetailsTitle.layer.masksToBounds = true
    }
    // MARK: - TapGesture Method
    func tapFunction(sender:UITapGestureRecognizer) {
        print("tap working")
        self.openUserProfileScreen(indexOfPost: self.intCurrentRow)
    }
    
    func tapImageAttachment(sender:UITapGestureRecognizer) {
        self.openPostAttachment(indexOfPost: self.intCurrentRow)
    }
    
    // MARK: - UIScrollViewDelegate
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let scrollOffset: Float = -(Float)(scrollView.contentOffset.y)
        let alpha = abs(scrollOffset) / 250
        self.viewTopBar.backgroundColor = UIColor.init(colorLiteralRed: 31.0/255.0, green: 36.0/255.0, blue: 48.0/255.0, alpha: alpha)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.viewWriteCommentContainer.isHidden = false
                self.viewShadowOfWriteCommentContainer.isHidden = false
                self.bottomConstContainerView?.constant = 0.0
                self.bottomConstTableView?.constant = 0.0
                
            } else {
                if textviewCheck == 1 {
                    self.viewWriteCommentContainer.isHidden = false
                    self.viewShadowOfWriteCommentContainer.isHidden = false
                    self.bottomConstContainerView?.constant = endFrame?.size.height ?? 0.0
                    
                } else {
                    self.viewWriteCommentContainer.isHidden = true
                    self.viewShadowOfWriteCommentContainer.isHidden = true
                    self.bottomConstContainerView?.constant = (endFrame?.size.height)! - self.viewWriteCommentContainer.frame.size.height
                }
            }
            
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - UITableView DataSource -
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.arrComment.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if intSelectedSectionForComment == section {
            return arrReply.count
        }
        else{
            return 0
        }
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let viewCommentSectionView = PostCommentSectionView.instanceFromNib() as! PostCommentSectionView
        viewCommentSectionView.lblComment.text = "Header"
        viewCommentSectionView.index = section
        viewCommentSectionView.delegate = self
        
        if section == intSelectedSectionForComment {
            viewCommentSectionView.viewReplyContainer.isHidden = false
        }
        else{
            viewCommentSectionView.viewReplyContainer.isHidden = true
        }
        
        viewCommentSectionView.txtViewReply.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewCommentSectionView.txtViewReply.layer.borderWidth = 1.0
        viewCommentSectionView.txtViewReply.layer.cornerRadius = 3.0
        viewCommentSectionView.txtViewReply.layer.masksToBounds = true
        viewCommentSectionView.txtViewReply.tag = section
        
        let dictComment = arrComment[section] as Dictionary<String,Any>
        viewCommentSectionView.lblUserName.text = dictComment["name"] as! String?
        viewCommentSectionView.lblComment.text = dictComment["comment"] as! String?
        
        viewCommentSectionView.lblComment.sizeToFit()
        
        viewCommentSectionView.txtViewReply.text = "Your Reply"
        viewCommentSectionView.txtViewReply.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        
        var reply = "\(dictComment["replies_count"]!)"
        if reply.characters.count > 0  && reply != "0" {
            reply = " reply" + "(\(reply))"
        } else {
            reply = " reply"
        }
        viewCommentSectionView.btnReply.setTitle( reply , for: .normal )
        
        if let keyEditAllow = dictComment["edit_delete_allow"]  {
            
            if  keyEditAllow as! String == "1" {
                viewCommentSectionView.btnEdit.isHidden = false;
                viewCommentSectionView.btnDelete.isHidden = false;
            }
            else{
                viewCommentSectionView.btnEdit.isHidden = true;
                viewCommentSectionView.btnDelete.isHidden = true;
            }
        }
        else{
            viewCommentSectionView.btnEdit.isHidden = true;
            viewCommentSectionView.btnDelete.isHidden = true;
        }
        if let strDate = dictComment["commented_date"] {
            viewCommentSectionView.lblTime.text = convertStringToDate(strDate: strDate as! String)
        }else{
            viewCommentSectionView.lblTime.text = ""
        }
        let dictUserData = dictComment["user_data"] as! Dictionary<String,Any>
        if dictUserData.keys.contains("photo") {
            let strPhotoName = dictUserData["photo"] as! String
            if strPhotoName.characters.count != 0 {
                let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                let fileUrl = NSURL(string: strUrl)
                
                viewCommentSectionView.imgUserProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                    if error != nil {
                        print("Failed: \(error)")
                    } else {
                        print("Success")
                    }
                }
            }
            else{
                viewCommentSectionView.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        else{
            viewCommentSectionView.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
        }
        return viewCommentSectionView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "PostCommentReplyTVCell") as! PostCommentReplyTVCell
        cell.index = indexPath.row
        cell.delegate = self
        let dictReply = arrReply[indexPath.row] as Dictionary<String,Any>
        cell.lblUserName.text = dictReply["name"] as! String?
        cell.lblComment.text = dictReply["reply"] as! String?
        
        if let keyEditAllow = dictReply["edit_delete_allow"]  {
            
            if  keyEditAllow as! String == "1" {
                cell.btnEdit.isHidden = false;
                cell.btnDelete.isHidden = false;
                cell.heightConstEditDeleteButton.constant = 31.0
            }
            else{
                cell.btnEdit.isHidden = true;
                cell.btnDelete.isHidden = true;
                cell.heightConstEditDeleteButton.constant = 0
            }
        }
        else{
            cell.btnEdit.isHidden = true;
            cell.btnDelete.isHidden = true;
            cell.heightConstEditDeleteButton.constant = 0
            cell.layoutIfNeeded()
        }
        if let strDate = dictReply["reply_date"] {
            cell.lblTime.text = convertStringToDate(strDate: strDate as! String)
        }else{
            cell.lblTime.text = ""
        }
        let dictUserData = dictReply["user_data"] as! Dictionary<String,Any>
        if dictUserData.keys.contains("photo") {
            let strPhotoName = dictUserData["photo"] as! String
            if strPhotoName.characters.count != 0 {
                let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                let fileUrl = NSURL(string: strUrl)
                
                cell.imgUserProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                    if error != nil {
                        print("Failed: \(error)")
                    } else {
                        print("Success")
                    }
                }
            }
            else{
                cell.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        else{
            cell.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
        }
        cell.contentView.setNeedsLayout()
        cell.contentView.layoutIfNeeded()
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        let dictComment = arrComment[section] as Dictionary<String,Any>
        let height = self.tableSectionHeightCelculate(widths: tableView.frame.size.width - 54, strText: dictComment["comment"] as! String)
        
        if section == intSelectedSectionForComment {
            return 116 + height
        }
        else{
            return 86 + height
        }
    }
    func tableSectionHeightCelculate(widths : CGFloat,strText : String) -> CGFloat {
        
        let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: widths, height: 0))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = UIFont.init(name: "HelveticaNeueCyr-Light", size: 14)
        label.text = strText
        label.sizeToFit()
        var labelHeight = self.lines(yourLabel: label)
        labelHeight = labelHeight * 13
        return CGFloat(labelHeight)
    }
    func lines(yourLabel:UILabel) -> Int{
        var lineCount = 0;
        let textSize = CGSize(width: yourLabel.frame.size.width, height: CGFloat(Float.infinity));
        let rHeight = lroundf(Float(yourLabel.sizeThatFits(textSize).height))
        let charSize = lroundf(Float(yourLabel.font.lineHeight));
        lineCount = rHeight/charSize
        return lineCount
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForFooterInSection section: Int) -> CGFloat {
        return 0.0
    }
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    // MARK: - Action Method
    @IBAction func btnLikeAction(_ sender: AnyObject) {
        btnLike.isSelected = !btnLike.isSelected
    }
    @IBAction func btnUnlikeAction(_ sender: AnyObject) {
        btnUnlike.isSelected = !btnUnlike.isSelected
    }
    @IBAction func btnViewAction(_ sender: AnyObject) {
        btnView.isSelected = !btnView.isSelected
    }
    @IBAction func btnCommentAction(_ sender: AnyObject) {
        
        btnComment.isSelected = !btnComment.isSelected
        viewPostComments?.intSelectedRowForComment = -1
        viewPostComments?.intSelectedSectionForComment = -1
        viewPostComments?.reloadComments()
        viewPostComments?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostComments?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostComments?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    @IBAction func btnShareAction(_ sender: AnyObject) {
        btnShare.isSelected = !btnShare.isSelected
        self.viewPostShare?.txtMessage.text = ""
        self.viewPostShare?.alpha = 0.0
        viewPostShare?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostShare?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostShare?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    @IBAction func btnEAAction(_ sender: Any) {
        let vcEcommerce = self.storyboard?.instantiateViewController(withIdentifier: "EcommerceAgreementViewController") as! EcommerceAgreementViewController
        self.navigationController?.pushViewController(vcEcommerce, animated: true)
        
    }
    @IBAction func btnChatAction(_ sender: Any) {
        let vcChatMsg = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        self.navigationController?.pushViewController(vcChatMsg, animated: true)
    }
    
    @IBAction func btnBidAction(_ sender: Any) {
        viewBidPrice?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewBidPrice?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewBidPrice?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    @IBAction func btnBackClickAction(_ sender: Any) {
        self.navigationController!.popViewController(animated: true)
    }
    
    @IBAction func btnMoreClickAction(_ sender: Any) {
        self.cvMoreAction.reloadData()
        UIView.animate(withDuration: 0.7, delay: 0.0, usingSpringWithDamping: 0.8,
                       initialSpringVelocity: 0.8, options: [], animations: {
                        self.viewMoreActionContainer.transform = CGAffineTransform(scaleX: 1, y: 1)
        }, completion: {(_ finished : Bool) -> Void in
            self.viewMoreActionContainer.layoutIfNeeded()
            
        })
    }
    
    @IBAction func btnCloseMoreClickAction(_ sender: Any) {
        UIView.animate(withDuration: 0.7, delay: 0.0, usingSpringWithDamping: 0.8,
                       initialSpringVelocity: 0.8, options: [], animations: {
                        self.viewMoreActionContainer.transform =  CGAffineTransform(translationX: 500, y: 0)
        })
    }
    
    @IBAction func btnFollowClickAction(_ sender: Any) {
        self.postFollowClicked(indexOfPost: 1)
    }
    // MARK: - PostCommentDelegate
    
    func btnCommentReplyClicked(index: NSInteger) {
        
        intSelectedRowForComment = index
        tblPostDetails.reloadData()
    }
    
    func btnSubmitReplyClicked(index: NSInteger) {
        intSelectedRowForComment = -1
        let indexPath = IndexPath.init(row: index, section: 0) as IndexPath
        tblPostDetails.reloadRows(at: [indexPath], with: UITableViewRowAnimation.fade)
        self.view.endEditing(true)
    }
    // MARK: - PostCommentSectionViewDelegate -
    
    func btnCommentSectionViewReplyClicked(index: NSInteger) {
        self.view .endEditing(true)
        intSelectedSectionForComment = index
        self.arrReply.removeAll()
        let dictComment = arrComment[index] as Dictionary<String,Any>
        self.arrReply = dictComment["reply_arr"] as! [Dictionary<String,Any>]
        tblPostDetails.reloadData()
    }
    
    func btnSubmitSectionViewReplyClicked(index: NSInteger, strReply: String) {
        
        self.view.endEditing(true)
        if strReply == "Your Reply" || strReply == ""{
            return
        }
        let dictComment = arrComment[index] as Dictionary<String,Any>
        
        let dictParam = NSMutableDictionary()
        dictParam["postId"] = dictComment["post_id"] as! String;
        dictParam["comId"] = dictComment["com_id"] as! String;
        dictParam["reply"] = strReply
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertReply", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        let dictComment = dict?["data"] as! Dictionary<String,Any>
                        self.arrReply = dictComment["reply_arr"] as! [Dictionary<String,Any>]
                        self.arrComment[index] = dictComment
                        self.tblPostDetails.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func btnCommentSectionDeleteClicked(index: NSInteger) {
        
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Sure want to delete comment?", delegate:self, cancelButtonTitle: "No")
        alertWarning.addButton(withTitle: "Yes")
        alertWarning.tag = 1
        iDeleteIndex = index
        alertWarning.show()
    }
    //MARK:- AlertView Delegate Method
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if buttonIndex == 0 {
            //No
        }
        else{
            //yes
            if alertView.tag == 1 {
                callWebserviceDeleteSectionCommentPost(index:iDeleteIndex)
            }
            else {
                callWebserviceDeleteReplyCommentPost(index:iDeleteIndex)
            }
        }
    }
    func callWebserviceDeleteSectionCommentPost(index: NSInteger) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            let dictComment = arrComment[index] as Dictionary<String,Any>
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            let dictParam = NSMutableDictionary()
            dictParam["forEdite"] = "0"
            dictParam["comment"] = ""
            dictParam["comId"] = dictComment["com_id"]
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            service.callJSONMethod(methodName: "editDeleteComment", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.intSelectedRowForComment = -1
                        self.intSelectedSectionForComment = -1
                        self.arrComment.remove(at: index)
                        
                        var comment = " "
                        if  self.arrComment.count > 0{
                            comment = " Comments " + "(\(self.arrComment.count))"
                        } else {
                            comment = " Comments"
                        }
                        self.lblCommentCnt.text = comment
                        
                        var arrPostAction = [Dictionary<String,Any>]()
                        arrPostAction = self.dictPostDetail["arrPostAction"] as! [Dictionary<String, Any>]
                        for (index, var dictPost) in arrPostAction.enumerated() {
                            if dictPost.keys.contains("comment_count") {
                                let newCount  =  self.arrComment.count
                                dictPost["comment_count"] = newCount
                                arrPostAction[index] = dictPost
                            }
                        }
                        self.dictPostDetail["arrPostAction"] = arrPostAction
                        self.setupUIData()
                        self.tblPostDetails.reloadData()
                        self.delegate?.reloadPostData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func btnCommentSectionEditClicked(index: NSInteger) {
        
        self.viewCommentEdit?.dictCommentData =  arrComment[index] as Dictionary<String,Any>
        self.viewCommentEdit?.index = index
        self.viewCommentEdit?.isSectionEdit = true
        self.viewCommentEdit?.displayCommentForSection()
        self.viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewCommentEdit?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewCommentEdit?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    func btnEditReplyClicked(index: NSInteger) {
        
        let dictComment = arrReply[index] as Dictionary<String,Any>
        
        self.viewCommentEdit?.dictCommentData = dictComment
        self.viewCommentEdit?.index = index
        self.viewCommentEdit?.isSectionEdit = false
        self.viewCommentEdit?.displayCommentForReply()
        self.viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewCommentEdit?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewCommentEdit?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    func btnDeleteReplyClicked(index: NSInteger) {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Sure want to delete reply?", delegate:self, cancelButtonTitle: "No")
        alertWarning.addButton(withTitle: "Yes")
        alertWarning.tag = 2
        iDeleteIndex = index
        alertWarning.show()
    }
    func callWebserviceDeleteReplyCommentPost(index: NSInteger) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            let dictReply = arrReply[index] as Dictionary<String,Any>
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            let dictParam = NSMutableDictionary()
            dictParam["forEdit"] = "0"
            dictParam["reply"] = ""
            dictParam["comId"] = dictReply["com_id"]
            dictParam["repId"] = dictReply["rep_id"]
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            service.callJSONMethod(methodName: "editDeleteReply", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrReply.remove(at: index)
                        var dictComment = self.arrComment[self.intSelectedSectionForComment]
                        dictComment["reply_arr"] = self.arrReply
                        
                        var reply : Int = Int("\(dictComment["replies_count"]!)")!
                        reply = reply - 1
                        let strReply :String = String(describing: reply)
                        dictComment["replies_count"] = strReply
                        self.arrComment[self.intSelectedSectionForComment] = dictComment
                        self.tblPostDetails.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - Create Comment Delegate -
    @IBAction func btnSendCommentAction(_ sender: Any) {
        self.view.endEditing(true)
        
        if txtViewWriteComment.text == "Write your comment" || txtViewWriteComment.text == ""{
            return
        }
        
        let dictParam = NSMutableDictionary()
        let dictPostDtlIndividual = dictPostDetail["postdetailindiv"] as! Dictionary<String,Any>
        dictParam["postId"] = dictPostDtlIndividual["post_id"] as! String;
        
        dictParam["comment"] = txtViewWriteComment.text
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertComment", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        self.txtViewWriteComment.text = "Write your comment"
                        self.txtViewWriteComment.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
                        let dictComment = dict?["data"] as! Dictionary<String,Any>
                        self.arrComment.insert(dictComment, at: 0)
                        
                        var comment = " "
                        if  self.arrComment.count > 0{
                            comment = " Comments " + "(\(self.arrComment.count))"
                        } else {
                            comment = " Comments"
                        }
                        self.lblCommentCnt.text = comment
                        var arrPostAction = [Dictionary<String,Any>]()
                        arrPostAction = self.dictPostDetail["arrPostAction"] as! [Dictionary<String, Any>]
                        for (index, var dictPost) in arrPostAction.enumerated() {
                            if dictPost.keys.contains("comment_count") {
                                let newCount  =  self.arrComment.count
                                dictPost["comment_count"] = newCount
                                arrPostAction[index] = dictPost
                            }
                        }
                        self.dictPostDetail["arrPostAction"] = arrPostAction
                        self.setupUIData()
                        self.tblPostDetails.reloadData()
                        self.delegate?.reloadPostData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
        
    }
    // MARK: - UITextViewDelegate
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        
        let length = textView.text.characters.count as Int
        if length > 0 {
            lblComment.text = textView.text
            textView.textColor = UIColor.black
        }
        else{
            lblComment.text = "Hi"
            textView.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        }
    }
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        textviewCheck = 1
        if textView.text == "Write your comment" {
            textView.text = ""
            textView.textColor = UIColor.black
        }
        let length = textView.text.characters.count as Int
        if length > 0 {
            lblComment.text = textView.text
        }
        else{
            lblComment.text = "Hi"
        }
        return true
    }
    
    func textFieldReplyShouldBeginEditing(_ textField: UITextField) -> Bool{
        textviewCheck = 0
        return true
    }
    func textFieldReplyShouldEndEditing(_ textField: UITextField) -> Bool{
        
        return true
    }
    func textViewReplyShouldEndEditing(_ textView: UITextView) -> Bool {
        
        self.tblPostDetails.reloadData()
        return true
    }
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        
        if textView.text.characters.count>0 {
            textView.textColor = UIColor.black
        }
        else{
            textView.text = "Write your comment"
            textView.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        
    }
    func lineCount(for label: UITextView) -> Int {
        let labelWidth: CGFloat = label.frame.size.width
        var lineCount = 0
        let textSize = CGSize(width: labelWidth, height: CGFloat(MAXFLOAT))
        let rHeight = lroundf(Float(label.sizeThatFits(textSize).height))
        lineCount = Int(rHeight / 15)
        return lineCount
    }
    
    // MARK: - CommentEdit Delegate
    func hideCommentEditView() {
        viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewCommentEdit?.alpha = 0.0
        }) { (Bool) in
            self.viewCommentEdit?.isHidden = true
        }
    }
    
    func saveSectionCommentEditView(sectionIndex : NSInteger,dictComment : Dictionary<String,Any>) -> Void{
        viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewCommentEdit?.alpha = 0.0
        }) { (Bool) in
            self.viewCommentEdit?.isHidden = true
        }
        arrComment[sectionIndex] = dictComment
        //reload section if needed
        tblPostDetails.reloadData()
    }
    func saveReplyCommentEditView(cellIndex : NSInteger,dictComment : Dictionary<String,Any>) -> Void{
        
        viewCommentEdit?.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.viewCommentEdit?.alpha = 0.0
        }) { (Bool) in
            self.viewCommentEdit?.isHidden = true
        }
        arrReply[cellIndex] = dictComment
        var dictComment = arrComment[intSelectedSectionForComment]
        dictComment["reply_arr"] = arrReply
        arrComment[intSelectedSectionForComment] = dictComment
        //reload section if needed
        self.tblPostDetails.reloadData()
    }
    
    // MARK: - UICollectionViewDataSource -
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.cvPostImages {
            return arrPostImages.count
        } else if collectionView == cvPostAction {
            return arrPostAction.count
        }else {
            return arrMoreAction.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.cvPostImages {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PostImagesCVCell", for: indexPath) as! PostImagesCVCell
            let dictImages = arrPostImages[indexPath.row]
            cell.imgPostImage.contentMode = .scaleAspectFill
            
            var strBaseUrl = ""
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                strBaseUrl = IMAGE_ATTACHMENT_BASE_URL
            }
            else{
                strBaseUrl = SELL_IMAGE_ATTACHMENT_URL
            }
            
            if dictImages.keys.contains("attachment_name") {
                let strPhotoName = dictImages["attachment_name"] as! String
                if strPhotoName.characters.count != 0 {
                    let strUrl = strBaseUrl + (dictImages["attachment_name"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    cell.imgPostImage.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    cell.imgPostImage.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                cell.imgPostImage.image = #imageLiteral(resourceName: "default_img")
            }
            return cell
        } else if collectionView == cvPostAction {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PostActionCVCell", for: indexPath) as! PostActionCVCell
            
            let dictData = arrPostAction[indexPath.row]
            let intPostActionType = dictData["postActionType"] as! Int
            let dictPostDtlIndividual = dictPostDetail["postdetailindiv"] as! Dictionary<String,Any>
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                switch intPostActionType {
                case PostActionTypeSHARE.LIKE_POST.rawValue:
                    
                    if (dictPostDtlIndividual["ag_cls"] as AnyObject).int32Value == 1 {
                        cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                        cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    }
                    else{
                        cell.imgAction.image = UIImage (named: dictData["img_icon_unsel"] as! String)
                        cell.lblAction.textColor = UIColor.lightGray
                    }
                    cell.lblAction.text = (dictPostDtlIndividual["agree_count"] as AnyObject).stringValue
                    
                    break
                    
                case PostActionTypeSHARE.DISLIKE_POST.rawValue:
                    if (dictPostDtlIndividual["dag_cls"] as AnyObject).int32Value == 1 {
                        cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                        cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    }
                    else{
                        cell.imgAction.image = UIImage (named: dictData["img_icon_unsel"] as! String)
                        cell.lblAction.textColor = UIColor.lightGray
                    }
                    cell.lblAction.text = (dictPostDtlIndividual["dis_agree_count"] as AnyObject).stringValue
                    break
                case PostActionTypeSHARE.VIEW_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = dictData["view_count"] as! String?
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    
                    break
                case PostActionTypeSHARE.COMMENT_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = (dictData["comment_count"] as AnyObject).stringValue
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                case PostActionTypeSHARE.FOLLOW_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = "Follow"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                case PostActionTypeSHARE.SHARE_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    cell.lblAction.text = "Share"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                    
                case PostActionTypeSHARE.DELETE_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    
                    break
                case PostActionTypeSHARE.PRIME_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    cell.lblAction.text = "Prime"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                    
                default:
                    
                    break
                    
                }
            }else{
                switch intPostActionType {
                case PostActionTypeSELL.EA_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    
                    cell.lblAction.text = "E.A."
                    
                    break
                    
                case PostActionTypeSELL.COMMENT_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    cell.lblAction.text = "Chat"
                    
                    break
                case PostActionTypeSELL.BID_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = "Bid"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    
                    break
                case PostActionTypeSELL.EDIT_BID_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = "Edit Bid"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                case PostActionTypeSELL.VIEW_MORE_DETAIL_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = "View More"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                    
                case PostActionTypeSELL.DELETE_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    cell.lblAction.text = ""
                    break
                case PostActionTypeSELL.SOLD_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    cell.lblAction.text = "SOLD"
                    
                    break
                default:
                    
                    break
                    
                }
            }
            return cell
            
        }
        else {
            //More Action
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PostMoreActionCVCell", for: indexPath) as! PostMoreActionCVCell
            let dictData = arrMoreAction[indexPath.row]
            cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
            
            return cell
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath: IndexPath) -> CGSize{
        if collectionView == self.cvPostImages {
            return CGSize(width: UIScreen.main.bounds.size.width, height: collectionView.frame.size.height);
        } else if collectionView == self.cvPostAction {
            let dictData = arrPostAction[sizeForItemAtIndexPath.row]
            var strCount : String = String()
            let intPostActionType = dictData["postActionType"] as! Int
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                switch intPostActionType {
                case PostActionTypeSHARE.LIKE_POST.rawValue:
                    
                    let temp = dictData["agree_count"]
                    if temp == nil {
                        strCount = " "
                    }else{
                        strCount = "\(temp!)"
                    }
                    
                    break
                    
                case PostActionTypeSHARE.DISLIKE_POST.rawValue:
                    let temp = dictData["dis_agree_count"]
                    if temp == nil {
                        strCount = " "
                    }else{
                        strCount = "\(temp!)"
                    }
                    
                    break
                case PostActionTypeSHARE.VIEW_POST.rawValue:
                    let temp = dictData["view_count"]
                    if temp == nil {
                        strCount = " "
                    }else{
                        strCount = "\(temp!)"
                    }
                    
                    break
                case PostActionTypeSHARE.COMMENT_POST.rawValue:
                    let temp = dictData["comment_count"]
                    if temp == nil {
                        strCount = " "
                    }else{
                        strCount = "\(temp!)"
                    }
                    break
                case PostActionTypeSHARE.FOLLOW_POST.rawValue:
                    strCount = "Follow"
                    break
                case PostActionTypeSHARE.SHARE_POST.rawValue:
                    strCount = "Share"
                    break
                case PostActionTypeSHARE.DELETE_POST.rawValue:
                    strCount = " "
                    return CGSize(width: 47, height: 35);
                    
                case PostActionTypeSHARE.PRIME_POST.rawValue:
                    strCount = "Prime"
                    break
                    
                default:
                    
                    break
                    
                }
            }
            else {
                switch intPostActionType {
                case PostActionTypeSELL.EA_POST.rawValue:
                    strCount = "E.A."
                    
                    break
                    
                case PostActionTypeSELL.COMMENT_POST.rawValue:
                    strCount = "Chat"
                    
                    break
                case PostActionTypeSELL.BID_POST.rawValue:
                    strCount = "Bid"
                    
                    break
                case PostActionTypeSELL.EDIT_BID_POST.rawValue:
                    strCount = "Edit Bid"
                    
                    break
                case PostActionTypeSELL.VIEW_MORE_DETAIL_POST.rawValue:
                    strCount = "View More"
                    break
                case PostActionTypeSELL.SOLD_POST.rawValue:
                    strCount = "SOLD"
                    break
                case PostActionTypeSELL.DELETE_POST.rawValue:
                    return CGSize(width: 47, height: 35);
                    
                default:
                    
                    break
                    
                }
            }
            
            var charcount = strCount.characters.count
            charcount = 60 + (charcount * 7)
            
            return CGSize(width: charcount, height: 35);
        }
        else{
            return CGSize(width: self.cvMoreAction.frame.size.width / 3, height: 45);
        }
    }
    
    // MARK: - UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView == self.cvPostImages {
            self.openPostDetail(indexOfPost: indexPath.row)
        }else if collectionView == self.cvPostAction {
            let dictData = arrPostAction[indexPath.row]
            let intPostActionType = dictData["postActionType"] as! Int
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                switch intPostActionType {
                case PostActionTypeSHARE.LIKE_POST.rawValue:
                    self.postLikeClicked(indexOfPost: indexPath.row)
                    break
                    
                case PostActionTypeSHARE.DISLIKE_POST.rawValue:
                    self.postUnLikeClicked(indexOfPost: indexPath.row)
                    
                    break
                case PostActionTypeSHARE.VIEW_POST.rawValue:
                    self.postViewClicked(indexOfPost: indexPath.row)
                    
                    break
                case PostActionTypeSHARE.COMMENT_POST.rawValue:
                    //                self.postCommentClicked(indexOfPost: indexPath.row)
                    
                    break
                case PostActionTypeSHARE.FOLLOW_POST.rawValue:
                    self.postFollowClicked(indexOfPost: indexPath.row)
                    
                    break
                case PostActionTypeSHARE.SHARE_POST.rawValue:
                    self.postReplyClicked(indexOfPost: indexPath.row)
                    
                    break
                    
                case PostActionTypeSHARE.DELETE_POST.rawValue:
                    self.postDeleteClicked(indexOfPost: indexPath.row)
                    break
                    
                case PostActionTypeSHARE.PRIME_POST.rawValue:
                    break
                    
                default:
                    
                    break
                }
                
            }else{
                switch intPostActionType
                {
                case PostActionTypeSELL.EA_POST.rawValue:
                    self.postEAClicked(indexOfPost: indexPath.row)
                    break
                case PostActionTypeSELL.COMMENT_POST.rawValue:
                    self.postChatClicked(indexOfPost: indexPath.row)
                    
                    break
                case PostActionTypeSELL.BID_POST.rawValue:
                    self.postBidClicked(indexOfPost: indexPath.row)
                    break
                case PostActionTypeSELL.EDIT_BID_POST.rawValue:
                    self.postBidClicked(indexOfPost: indexPath.row)
                    break
                case PostActionTypeSELL.VIEW_MORE_DETAIL_POST.rawValue:
                    self.postViewMoreClicked(indexOfPost: indexPath.row)
                    break
                case PostActionTypeSELL.DELETE_POST.rawValue:
                    self.postDeleteClicked(indexOfPost: indexPath.row)
                    break
                case PostActionTypeSELL.SOLD_POST.rawValue:
                    break
                default:
                    
                    break
                    
                }
            }
        }else {
            //more action
            let dictData = arrMoreAction[indexPath.row]
            let  intPostMoreActionType = dictData["moreActionType"] as! Int
            
            switch intPostMoreActionType {
            case PostMoreActionTypeSHARE.SHARE_POST.rawValue:
                self.postReplyClicked(indexOfPost: indexPath.row)
                break
                
            case PostMoreActionTypeSHARE.EDIT_POST.rawValue:
                self.postDescriptionEditClicked(indexOfPost: indexPath.row)
                
                break
                
            case PostMoreActionTypeSHARE.DELETE_POST.rawValue:
                self.postDeleteClicked(indexOfPost: indexPath.row)
                break
            default:
                
                break
            }
        }
    }
    
    // MARK: - Custom Method
    func reloadImages() -> Void {
        cvPostImages.reloadData()
    }
    
    // MARK: - PostListingDelegate
    
    func postLikeClicked(indexOfPost: NSInteger) {
        let dictPost = dictPostDetail
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictParam = NSMutableDictionary()
        
        dictParam["pId"] = dictPost["p_id"]
        dictParam["postType"] = dictPost["post_type"]
        
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        dictParam["forWhat"] = "1"
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        callWebserviceForLikeUnlikeSharePost(dictParam: dictParam)
    }
    
    func postUnLikeClicked(indexOfPost: NSInteger) {
        
        let dictPost = dictPostDetail
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictParam = NSMutableDictionary()
        
        dictParam["pId"] = dictPost["p_id"]
        dictParam["postType"] = dictPost["post_type"]
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        dictParam["forWhat"] = "2"
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        callWebserviceForLikeUnlikeSharePost(dictParam: dictParam)
    }
    
    func postViewClicked(indexOfPost: NSInteger) {
        
    }
    
    func postCommentClicked(indexOfPost: NSInteger) {
        
        self.viewPostComments?.intSelectedRowForComment = -1
        self.viewPostComments?.intSelectedSectionForComment = -1
        self.viewPostComments?.arrComment = arrComment
        self.viewPostComments?.reloadComments()
        self.viewPostComments?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostComments?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostComments?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    func postReplyClicked(indexOfPost: NSInteger) {
        self.viewPostShare?.txtMessage.text = ""
        self.viewPostShare?.setUserData()
        self.viewPostShare?.index = indexOfPost
        let dictPost = dictPostDetail
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        viewPostShare?.lblPostDetail.text = dictPostDtlIndividual["post_content"] as? String
        
        self.viewPostShare?.alpha = 0.0
        viewPostShare?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostShare?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostShare?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    func postFollowClicked(indexOfPost: NSInteger) {
        let dictPost = dictPostDetail
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        
        let dictUserData = (dictPostDtlIndividual["postuserdata"] as? Dictionary<String,Any>)!
        
        let dictParam = NSMutableDictionary()
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        dictParam["encPostId"] = dictPostDtlIndividual["enc_posted_by"] as! String
        dictParam["fromView"] = "0"
        dictParam["type"] = "follow"
        dictParam["otherUserId"] = dictUserData["reporter_id"] as! String
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        callWebserviceForFollowUser(dictParam: dictParam)
    }
    
    func postDeleteClicked(indexOfPost: NSInteger) {
        
        let dictPost = dictPostDetail
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        
        let alert:UIAlertController=UIAlertController(title: Constant.APP_NAME, message: Constant.ALERT_MSG_CONFIRM_TO_DELETE_POST, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = dictPost["share_id"] as! String;
            dictParam["type"] = dictPostDtlIndividual["post_type"] as! String
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            self.callWebserviceDeletePost(dictParam: dictParam,andIndexOfPost: self.intCurrentRow)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
            
        }
        // Add the actions
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    func postDescriptionEditClicked(indexOfPost: NSInteger) -> Void {
        
    }
    func openUserProfileScreen(indexOfPost: NSInteger) {
        //        let vcUserProfile = self.storyboard?.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
        //        vcUserProfile.dictUserPostData = dictPostDetail
        //        self.navigationController?.pushViewController(vcUserProfile, animated: true)
    }
    
    func postEAClicked(indexOfPost: NSInteger) {
        let vcEcommerce = self.storyboard?.instantiateViewController(withIdentifier: "EcommerceAgreementViewController") as! EcommerceAgreementViewController
        vcEcommerce.dictPostDtl = dictPostDetail
        self.navigationController?.pushViewController(vcEcommerce, animated: true)
    }
    
    func postChatClicked(indexOfPost: NSInteger) {
        let vcChatMsg = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        self.navigationController?.pushViewController(vcChatMsg, animated: true)
    }
    
    func postBidClicked(indexOfPost: NSInteger) {
        
        let dictPost = arrPost[indexOfPost] as Dictionary<String,Any>
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        
        viewBidPrice?.index = indexOfPost
        viewBidPrice?.dictBidDtl = dictPostDtlIndividual
        
        if dictPostDtlIndividual.keys.contains("bid_price") {
            viewBidPrice?.txtPrice.text = ""
            viewBidPrice?.lblTitle.text = "Place Bid"
            viewBidPrice?.btnPlaceBid.setTitle("PLACE BID", for: .normal)
        }
        else{
            viewBidPrice?.txtPrice.text = dictPostDtlIndividual["amount"] as! String?
            viewBidPrice?.lblTitle.text = "Edit Bid"
            viewBidPrice?.btnPlaceBid.setTitle("EDIT BID", for: .normal)
        }
        
        viewBidPrice?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewBidPrice?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewBidPrice?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    
    func openPostDetail(indexOfPost: NSInteger) {
        
        self.viewPostImage?.alpha = 0.0
        
        let dictPost = dictPostDetail
        let dictPostdetailindiv = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        viewPostImage?.currentPostType = currentPostType
        viewPostImage?.isHidden = false
        viewPostImage?.arrAttDetail = dictPostdetailindiv["att_detail"] as! [Dictionary<String,Any>]
        
        viewPostImage?.cvPostImageList.reloadData()
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewPostImage?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewPostImage?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    func openPostAttachment(indexOfPost: NSInteger) {
        
        let dictPost = dictPostDetail
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_IMAGE {
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_VIDEO {
            
            let arrAttachment = dictPostDtlIndividual["att_detail"] as! [Dictionary<String,Any>]
            if arrAttachment.count != 0 {
                let dictAttachment = arrAttachment[0]
                let strUrl = VIDEO_ATTACHMENT_BASE_URL + (dictAttachment["attachment_name"] as! String)
                
                let url = NSURL(string: strUrl)!
                
                self.showSpinner(enableInteraction: false)
                
                DispatchQueue.global().async {
                    HttpDownloader.loadFileSync(url: url, completion: { (path, error) in
                        
                        DispatchQueue.main.async {
                            self.hideSpinner()
                            if (error == nil) {
                                
                                if path != "" {
                                    //                            let urlLocal = NSURL(fileURLWithPath: path)
                                    self.playVideo(videoUrl: path)
                                }
                            }
                        }
                    })
                }
                //                playVideo(videoUrl: strUrl)
            }
            
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_AUDIO {
            
            self.viewAudioPlay?.dictPostDetail = dictPostDtlIndividual
            self.viewAudioPlay?.lblTitle.text = dictPostDtlIndividual["post_content"] as? String
            
            viewAudioPlay?.isHidden = false
            UIView.animate(withDuration: 0.0, animations: {() -> Void in
                self.viewAudioPlay?.alpha = 0.0
            }, completion: {(_ finished: Bool) -> Void in
                UIView.animate(withDuration: 0.3, animations: {() -> Void in
                    self.viewAudioPlay?.alpha = 1.0
                }, completion: { _ in })
            })
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_DOCUMENT {
            let arrAttachment = dictPostDtlIndividual["att_detail"] as! [Dictionary<String,Any>]
            if arrAttachment.count != 0 {
                let dictAttachment = arrAttachment[0]
                let strUrl = DOCUMENT_ATTACHMENT_BASE_URL + (dictAttachment["attachment_name"] as! String)
                let url = NSURL(string: strUrl)!
                
                self.showSpinner(enableInteraction: true)
                
                DispatchQueue.global().async {
                    HttpDownloader.loadFileSync(url: url, completion: { (path, error) in
                        
                        DispatchQueue.main.async {
                            self.hideSpinner()
                            if (error == nil) {
                                
                                if path != "" {
                                    let urlLocal = NSURL(fileURLWithPath: path)
                                    self.viewDocumentViewer?.webView.loadRequest(URLRequest(url: urlLocal as URL))
                                    self.viewDocumentViewer?.isHidden = false
                                    UIView.animate(withDuration: 0.0, animations: {() -> Void in
                                        self.viewDocumentViewer?.alpha = 0.0
                                    }, completion: {(_ finished: Bool) -> Void in
                                        UIView.animate(withDuration: 0.3, animations: {() -> Void in
                                            self.viewDocumentViewer?.alpha = 1.0
                                        }, completion: { _ in })
                                    })
                                }
                            }
                        }
                    })
                }
            }
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_LOCATION {
        }
        else if dictPostDtlIndividual["attachment_type"] as! String == ATTACHMENT_TYPE_YOUTUBE {
            //YouTube Video Link Redirect to video player
            
            let strPostContent = dictPostDtlIndividual["post_content"]
            
            let detector = try! NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
            let matches = detector.matches(in: strPostContent! as! String, options: [], range: NSRange(location: 0, length: ((strPostContent as! String).utf16.count)))
            if matches.count != 0 {
                let match = matches[0]
                let url = (strPostContent as! NSString).substring(with: match.range)
                let array = url.components(separatedBy: "?")
                if array.count != 0 {
                    var strYouTubeID = array[1]
                    strYouTubeID = strYouTubeID.replacingOccurrences(of: "v=", with: "")
                    
                    let videoPlayVC = self.storyboard?.instantiateViewController(withIdentifier: "VideoPlayerViewController") as! VideoPlayerViewController
                    //                    videoPlayVC.strVideoLink = "ruMTxHFf9OI"
                    videoPlayVC.strVideoLink = strYouTubeID as NSString?
                    self.navigationController?.pushViewController(videoPlayVC, animated: true)
                }
            }
        }
        else {
            
        }
    }
    func postViewMoreClicked(indexOfPost: NSInteger) {
        
    }
    
    // MARK: - BidPriceDelegate
    
    func hideBidPriceView() {
        self.view.endEditing(true)
        
        viewBidPrice?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewBidPrice?.alpha = 0.0
        }) { (Bool) in
            self.viewBidPrice?.isHidden = true
        }
    }
    func insertUpdateBidPriceClick(strAmount: String, indexOfObject: NSInteger) {
        let dictPost = arrPost[indexOfObject] as Dictionary<String,Any>
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        print(dictPostDtlIndividual)
        
        if dictPostDtlIndividual.keys.contains("bid_price") {
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = dictPostDtlIndividual["post_id"] as! String;
            dictParam["price"] = strAmount
            self.callWebserviceBidPost(dictParam: dictParam)
        }
        else{
            let dictParam = NSMutableDictionary()
            dictParam["bidId"] = dictPostDtlIndividual["bid_id"] as! String;
            dictParam["amount"] = strAmount
            self.callWebserviceEditBidPost(dictParam: dictParam)
        }
    }
    
    func btnCloseCommentClickedWithData(index: NSInteger,dictComment : Dictionary<String,Any>) -> Void{
        
        self.view.endEditing(true)
        arrPost[index] = dictComment
        
        tblPostDetails.reloadRows(at: self.tblPostDetails.indexPathsForVisibleRows!, with:.none)
        
        viewPostComments?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostComments?.alpha = 0.0
        }) { (Bool) in
            self.viewPostComments?.isHidden = true
        }
    }
    // MARK: - SEARCHBAR DELEGATE METHODS -
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.isHidden = true
        self.perform(#selector(self.resignSearchBar), with: nil, afterDelay: 0.05)
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.isHidden = true
        searchBar.resignFirstResponder()
        //call webservice
    }
    
    func resignSearchBar() {
        self.searchBar.resignFirstResponder()
    }
    
    // MARK: - SharePostDelegate
    
    func hideSharePostView() {
        self.view.endEditing(true)
        
        viewPostShare?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostShare?.alpha = 0.0
        }) { (Bool) in
            self.viewPostShare?.isHidden = true
        }
    }
    
    func sharePostClicked(strDescription: String, indexOfObject: NSInteger) {
        self.hideSharePostView()
        let dictPost = dictPostDetail
        print(dictPost)
        let dictPostDtlIndividual = dictPost["postdetailindiv"] as! Dictionary<String,Any>
        let dictParam = NSMutableDictionary()
        dictParam["postId"] = dictPostDtlIndividual["id_for_agr"] as! String;
        dictParam["desc"] = strDescription
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        callWebserviceSharedPost(dictParam: dictParam)
    }
    
    // MARK: - AudioPlayViewDelegate
    
    func hideAudioPlayView() {
        viewAudioPlay?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewAudioPlay?.alpha = 0.0
        }) { (Bool) in
            self.viewAudioPlay?.isHidden = true
        }
    }
    
    func showSpinnerCallBack() {
        self.showSpinner(enableInteraction: false)
    }
    
    func hideSpinnerCallBack() {
        self.hideSpinner()
    }
    
    // MARK: - DocumentViewerViewDelegate
    
    func hideDocumentViewerView() {
        viewDocumentViewer?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewDocumentViewer?.alpha = 0.0
        }) { (Bool) in
            self.viewDocumentViewer?.isHidden = true
        }
    }
    
    func documentWebViewLoadFinish() {
        self.hideSpinner()
    }
    
    // MARK: - PostImageViewDelegate
    func hidePostImageView() -> Void {
        
        viewPostImage?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostImage?.alpha = 0.0
        }) { (Bool) in
            self.viewPostImage?.isHidden = true
        }
    }
    
    // MARK: - PostDetailViewDelegate
    func hidePostDetailView() -> Void {
        self.view.endEditing(true)
        
        viewPostDetail?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPostDetail?.alpha = 0.0
        }) { (Bool) in
            self.viewPostDetail?.isHidden = true
        }
    }
    
    // MARK: - CreatePostCategoryDelegate
    
    func selectedCategoryForPost(dictCategory: Dictionary<String, String>) {
        dictSelectedCatgeroy = dictCategory
        print(dictCategory["categoryName"] ?? "")
    }
    
    func selectedCategoryForFilterPost(arrCategory: [Dictionary<String, String>]) {
        arrSelectedCategoryForFilter = arrCategory
        if currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue || currentPostType == CurrentSelectedPostType.BOTH.rawValue {
            callWebservicePostForHome()
        }
        else{
            callWebservicePostForSell()
        }
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent //or default
    }
    
    // MARK: - AVPlayer Methods
    func playVideo(videoUrl : String)->Void{
        let videoURL = NSURL(fileURLWithPath: videoUrl)
        player = AVPlayer(url: videoURL as URL)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if (keyPath == "status") {
            if let currentItem = self.player?.currentItem {
                let status = currentItem.status
                if (status == .readyToPlay) {
                    
                }
            }
        }
    }
    // MARK: - Webservice Call
    
    func callWebservicePostForHome() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            dictParam["postType"] = "share"
            dictParam["searchKey"] = ""
            dictParam["cateId"] = ""
            
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getPost", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrPost = dict?["data"] as! [Dictionary<String,Any>]
                        self.filterPostarray()
                        self.setupUIData()
                        self.tblPostDetails.reloadData()
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "commentNotification"), object: nil)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func filterPostarray() -> Void {
        
        for (index, var dictPostAction) in arrPost.enumerated() {
            print(dictPostAction)
            
            var arr = [Dictionary<String, Any>]()
            var arrMoreAction = [Dictionary<String, Any>]()
            
            let dictData = dictPostAction["postdetailindiv"]as! Dictionary<String,Any>
            if dictData.keys.contains("need_to_call_agr_dis") {
                
                if dictData.keys.contains("agree_count") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "like_icon_sel"
                    dictTemp["img_icon_unsel"] = "like_icon"
                    dictTemp["agree_count"] = dictData["agree_count"]
                    dictTemp["postActionType"] = PostActionTypeSHARE.LIKE_POST.rawValue
                    arr.append(dictTemp)
                }
                if dictData.keys.contains("dis_agree_count") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "unlike_icon_sel"
                    dictTemp["img_icon_unsel"] = "unlike_icon"
                    dictTemp["dis_agree_count"] = dictData["dis_agree_count"]
                    dictTemp["postActionType"] = PostActionTypeSHARE.DISLIKE_POST.rawValue
                    arr.append(dictTemp)
                }
            }
            
            if dictData.keys.contains("view_count") {
                var  dictTemp = Dictionary<String, Any>()
                dictTemp["img_icon_sel"] = "view_icon_sel"
                dictTemp["img_icon_unsel"] = "view_icon"
                dictTemp["view_count"] = dictData["view_count"]
                dictTemp["postActionType"] = PostActionTypeSHARE.VIEW_POST.rawValue
                arr.append(dictTemp)
            }
            if dictData.keys.contains("comment_count") {
                var  dictTemp = Dictionary<String, Any>()
                dictTemp["img_icon_sel"] = "comm_icon_sel"
                dictTemp["img_icon_unsel"] = "comm_icon_sel"
                dictTemp["comment_count"] = dictData["comment_count"]
                dictTemp["postActionType"] = PostActionTypeSHARE.COMMENT_POST.rawValue
                arr.append(dictTemp)
            }
            
            var  dictTempShare = Dictionary<String, Any>()
            dictTempShare["img_icon"] = "more_share_icon"
            dictTempShare["share"] = "share"
            dictTempShare["moreActionType"] = PostMoreActionTypeSHARE.SHARE_POST.rawValue
            arrMoreAction.append(dictTempShare)
            
            if dictData.keys.contains("need_to_dlt") {
                var  dictTemp = Dictionary<String, Any>()
                dictTemp["img_icon"] = "more_delete_icon"
                dictTemp["need_to_dlt"] = dictData["need_to_dlt"]
                dictTemp["moreActionType"] = PostMoreActionTypeSHARE.DELETE_POST.rawValue
                arrMoreAction.append(dictTemp)
                
            }
            
            print(dictPostAction.count)
            dictPostAction["arrPostAction"] = arr
            dictPostAction["arrMoreAction"] = arrMoreAction
            arrPost[index] = dictPostAction
        }
    }
    
    func callWebservicePostForSell() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            dictParam["postType"] = "sell"
            dictParam["searchKey"] = ""
            var strCatID = ""
            
            for (_, dict) in arrSelectedCategoryForFilter.enumerated() {
                if strCatID == "" {
                    strCatID = dict["con_id"]!
                }
                else{
                    strCatID = strCatID + "," + dict["con_id"]!
                }
            }
            
            dictParam["cateId"] = strCatID
            
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "getPost", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrPost = dict?["data"] as! [Dictionary<String,Any>]
                        self.dictPostDetail.removeAll()
                        self.filterPostarrayForSell()
                        self.dictPostDetail = self.arrPost[self.intCurrentRow]
                        self.setupUIData()
                        self.tblPostDetails.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func filterPostarrayForSell() -> Void {
        
        for (index, var dictPostAction) in arrPost.enumerated() {
            var arr = [Dictionary<String, Any>]()
            let dictData = dictPostAction["postdetailindiv"]as! Dictionary<String,Any>
            
            var strSold = ""
            if dictData.keys.contains("sold") {
                strSold = dictData["sold"] as! String
            }
            
            if (strSold == "1") {
                var  dictTemp = Dictionary<String, Any>()
                dictTemp["img_icon_sel"] = "ea_icon_sel"
                dictTemp["img_icon_unsel"] = "ea_icon"
                dictTemp["postActionType"] = PostActionTypeSELL.SOLD_POST.rawValue
                arr.append(dictTemp)
            }
            else{
                if dictData.keys.contains("sold_url") {
                    
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "ea_icon_sel"
                    dictTemp["img_icon_unsel"] = "ea_icon"
                    dictTemp["postActionType"] = PostActionTypeSELL.EA_POST.rawValue
                    arr.append(dictTemp)
                }
                
                if dictData.keys.contains("need_to_msg") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "chat_icon_sel"
                    dictTemp["img_icon_unsel"] = "chat_icon"
                    dictTemp["postActionType"] = PostActionTypeSELL.COMMENT_POST.rawValue
                    arr.append(dictTemp)
                }
                if dictData.keys.contains("bid_price") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "price_icon_sel_Home"
                    dictTemp["img_icon_unsel"] = "price_icon_Home"
                    dictTemp["postActionType"] = PostActionTypeSELL.BID_POST.rawValue
                    arr.append(dictTemp)
                }
                
                if dictData.keys.contains("edit_bid") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "price_icon_sel_Home"
                    dictTemp["img_icon_unsel"] = "price_icon_Home"
                    dictTemp["postActionType"] = PostActionTypeSELL.EDIT_BID_POST.rawValue
                    arr.append(dictTemp)
                }
                
                if dictData.keys.contains("view_more_detail") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon_sel"] = "more_icon"
                    dictTemp["img_icon_unsel"] = "more_icon"
                    dictTemp["need_to_follow"] = dictData["need_to_follow"]
                    dictTemp["postActionType"] = PostActionTypeSELL.VIEW_MORE_DETAIL_POST.rawValue
                    arr.append(dictTemp)
                }
                
                if dictData.keys.contains("need_to_dlt") {
                    var  dictTemp = Dictionary<String, Any>()
                    dictTemp["img_icon"] = "delete_icon"
                    dictTemp["need_to_dlt"] = dictData["need_to_dlt"]
                    dictTemp["postActionType"] = PostActionTypeSELL.DELETE_POST.rawValue
                    arr.append(dictTemp)
                }
            }
            dictPostAction["arrPostAction"] = arr
            arrPost[index] = dictPostAction
        }
    }
    
    func callWebserviceForLikeUnlikeSharePost(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "likeDislike", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        let dictPostDetailIndiv = dict?["data"] as! Dictionary<String,Any>
                        self.dictPostDetail["postdetailindiv"] = dictPostDetailIndiv
                        self.setupUIData()
                        self.delegate?.reloadPostData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func callWebserviceViewCommentsSharePost(dictParam : NSMutableDictionary) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: true)
            service.callJSONMethod(methodName: "viewTheComment", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        self.arrComment = dict?["data"] as! [Dictionary<String,Any>]
                        var comment = " "
                        if  self.arrComment.count > 0{
                            comment = " Comments " + "(\(self.arrComment.count))"
                        } else {
                            comment = " Comments"
                        }
                        self.lblCommentCnt.text = comment
                        self.tblPostDetails.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func callWebserviceForFollowUser(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "followUser", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.delegate?.reloadPostData()
                        self.setUIAfterFollow()
                        self.delegate?.updateFollowUnFollowButton(isSetFollow: true)
                        self.dictPostDetail["arrPostAction"] = self.arrPostAction
                        self.cvPostAction.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceSharedPost(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertSharedData", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        let arrSharePost = dict?["data"] as! [Dictionary<String,Any>]
                        if arrSharePost.count != 0 {
                            var dictPostAction = arrSharePost[0]
                            var arr = [Dictionary<String, Any>]()
                            var arrMoreAction = [Dictionary<String,Any>]()
                            let dictData = dictPostAction["postdetailindiv"]as! Dictionary<String,Any>
                            if dictData.keys.contains("need_to_call_agr_dis") {
                                
                                if dictData.keys.contains("agree_count") {
                                    var  dictTemp = Dictionary<String, Any>()
                                    dictTemp["img_icon_sel"] = "like_icon_sel"
                                    dictTemp["img_icon_unsel"] = "like_icon"
                                    dictTemp["agree_count"] = dictData["agree_count"]
                                    dictTemp["postActionType"] = PostActionTypeSHARE.LIKE_POST.rawValue
                                    arr.append(dictTemp)
                                }
                                if dictData.keys.contains("dis_agree_count") {
                                    var  dictTemp = Dictionary<String, Any>()
                                    dictTemp["img_icon_sel"] = "unlike_icon_sel"
                                    dictTemp["img_icon_unsel"] = "unlike_icon"
                                    dictTemp["dis_agree_count"] = dictData["dis_agree_count"]
                                    dictTemp["postActionType"] = PostActionTypeSHARE.DISLIKE_POST.rawValue
                                    arr.append(dictTemp)
                                }
                            }
                            
                            if dictData.keys.contains("view_count") {
                                var  dictTemp = Dictionary<String, Any>()
                                dictTemp["img_icon_sel"] = "view_icon_sel"
                                dictTemp["img_icon_unsel"] = "view_icon"
                                dictTemp["view_count"] = dictData["view_count"]
                                dictTemp["postActionType"] = PostActionTypeSHARE.VIEW_POST.rawValue
                                arr.append(dictTemp)
                            }
                            if dictData.keys.contains("comment_count") {
                                var  dictTemp = Dictionary<String, Any>()
                                dictTemp["img_icon_sel"] = "comm_icon_sel"
                                dictTemp["img_icon_unsel"] = "comm_icon_sel"
                                dictTemp["comment_count"] = dictData["comment_count"]
                                dictTemp["postActionType"] = PostActionTypeSHARE.COMMENT_POST.rawValue
                                arr.append(dictTemp)
                            }
                            var  dictTempShare = Dictionary<String, Any>()
                            dictTempShare["img_icon"] = "more_share_icon"
                            dictTempShare["share"] = "share"
                            dictTempShare["moreActionType"] = PostMoreActionTypeSHARE.SHARE_POST.rawValue
                            arrMoreAction.append(dictTempShare)
                            
                            if dictData.keys.contains("need_to_dlt") {
                                var  dictEdit = Dictionary<String, Any>()
                                dictEdit["img_icon"] = "more_edit_icon"
                                dictEdit["need_to_edt"] = dictData["need_to_dlt"]
                                dictEdit["moreActionType"] = PostMoreActionTypeSHARE.EDIT_POST.rawValue
                                arrMoreAction.append(dictEdit)
                                
                                var  dictTemp = Dictionary<String, Any>()
                                dictTemp["img_icon"] = "more_delete_icon"
                                dictTemp["need_to_dlt"] = dictData["need_to_dlt"]
                                dictTemp["moreActionType"] = PostMoreActionTypeSHARE.DELETE_POST.rawValue
                                arrMoreAction.append(dictTemp)
                                
                            }
                            print(dictPostAction.count)
                            dictPostAction["arrPostAction"] = arr
                            dictPostAction["arrMoreAction"] = arrMoreAction
                            
                            //Changed By Pankaj
                            
                            let dictPostDtlIndividual = self.dictPostDetail["postdetailindiv"] as! Dictionary<String,Any>
                            let dictUserData = dictPostDtlIndividual["postuserdata"] as! Dictionary<String,Any>
                            let strPostUserId = dictUserData["reporter_id"] as? String
                            
                            let userDefault = UserDefaults.standard .dictionaryRepresentation()
                            let dictLoggedUser =  userDefault["userData"] as! Dictionary<String,Any>
                            let strLoggedUserId = dictLoggedUser["reporter_id"] as? String
                            
                            if strPostUserId == strLoggedUserId {
                                self.delegate?.addNewSharedPost(indexOfObject: self.intCurrentRow, andSharedPostDict: dictPostAction as NSDictionary)
                                self.intCurrentRow += 1
                            }
                            
                        }
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceDeletePost(dictParam : NSMutableDictionary, andIndexOfPost: NSInteger) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "deletePost", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.delegate?.reloadPostData()
                        self.navigationController!.popViewController(animated: true)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceBidPost(dictParam : NSMutableDictionary) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertDirectBid", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.hideBidPriceView()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func callWebserviceEditBidPost(dictParam : NSMutableDictionary) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            service.callJSONMethod(methodName: "updateBidPrice", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.hideBidPriceView()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func setUIAfterFollow() -> Void {
        
        var dictPostDtlIndividual = dictPostDetail["postdetailindiv"] as! Dictionary<String,Any>
        if dictPostDtlIndividual.keys.contains("need_to_follow") {
            dictPostDtlIndividual.removeValue(forKey: "need_to_follow")
            dictPostDetail["postdetailindiv"] = dictPostDtlIndividual
        }
        if !btnFollow.isHidden {
            btnFollow.isHidden = true
        }
        if dictPostDtlIndividual.keys.contains("is_prime") || dictPostDtlIndividual.keys.contains("need_to_follow") {
            topSpaceLblUserName.constant = 5.0
        }else{
            topSpaceLblUserName.constant = 15.0
        }
    }
}

//
//  EditPasswordViewController.swift
//  Oriscene
//
//  Created by Parth on 18/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class EditPasswordViewController: BaseViewController {
    
    var service = WebService()
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var viewContent: UIView!
    @IBOutlet var viewOldPasswordContainer: UIView!
    @IBOutlet var viewNewPasswordContainer: UIView!
    @IBOutlet var viewConfirmPasswordContainer: UIView!
    
    @IBOutlet var btnUpdate: UIButton!
    @IBOutlet var txtConfirmPassword: UITextField!
    @IBOutlet var txtNewPassword: UITextField!
    @IBOutlet var txtOldPassword: UITextField!
    @IBOutlet var bottomConstScrollView: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setUpUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    func setUpUI() -> Void {
        viewOldPasswordContainer.layer.cornerRadius = 3.0
        viewOldPasswordContainer.layer.masksToBounds = true
        viewOldPasswordContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewOldPasswordContainer.layer.borderWidth = 1.0
        
        viewNewPasswordContainer.layer.cornerRadius = 3.0
        viewNewPasswordContainer.layer.masksToBounds = true
        viewNewPasswordContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewNewPasswordContainer.layer.borderWidth = 1.0
        
        viewConfirmPasswordContainer.layer.cornerRadius = 3.0
        viewConfirmPasswordContainer.layer.masksToBounds = true
        viewConfirmPasswordContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewConfirmPasswordContainer.layer.borderWidth = 1.0
        
        btnUpdate.layer.cornerRadius = 3.0
        btnUpdate.layer.masksToBounds = true
    }
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstScrollView?.constant = 0.0
            } else {
                self.bottomConstScrollView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - Action Method
    @IBAction func btnUpdateAction(_ sender: Any) {
        if validatePassword() {
            //call webservice for edit password
            callWebserviceToUpdatePassword()
        }
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    //MARK:- Validation Method
    func validatePassword() -> Bool {
        if trimString(string: (txtOldPassword.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_OLD_PASSWORD_VALIDATE)
            return false
        }
        else if isValidPassword(txtNewPassword.text!) == false {
            showAlert(string: Constant.ALERT_MSG_PASSWORD_VALIDATE_FORMAT)
            return false
        }
        else if trimString(string: (txtConfirmPassword.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_REPEAT_PASSWORD_VALIDATE)
            return false
        }
        else if trimString(string: (txtNewPassword.text)!) != trimString(string: (txtConfirmPassword.text)!) {
            showAlert(string: Constant.ALERT_MSG_BOTH_PASSWORD_SAME_VALIDATE)
            return false
        }
        else if trimString(string: (txtNewPassword.text)!) == trimString(string: getCurrentPassword()) {
            showAlert(string: "current password and new Password can not be same")
            return false
        }
        else{
            return true
        }
    }
    
    //MARK:- Webservice Method
    func callWebserviceToUpdatePassword() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            dictParam["forWhat"] = "2"
            dictParam["oldPass"] = txtOldPassword.text
            dictParam["newPass"] = txtNewPassword.text
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "updateProfile", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        let userDefault = UserDefaults.standard
                        let dictData = dict?["data"] as! NSDictionary
                        print(dictData)
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        userDefault.synchronize()
                        self.navigationController!.popViewController(animated: true)
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            })
            
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func getCurrentPassword() -> String {
        let userDefault = UserDefaults.standard.dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            let dictUserData = userDefault["userData"] as! Dictionary<String,Any>
            var password = dictUserData["password"] as! String
            password = password.fromBase64()!
            //need to convert 2 times in base64 as backend is converting 2times so.
            password = password.fromBase64()!
            print(password)
            return password
        }
        return ""
    }
}

//
//  CategoryFirstViewController.swift
//  Oriscene
//
//  Created by Parth on 09/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol CreatePostCategoryDelegate {
    func selectedCategoryForPost(dictCategory : Dictionary<String,String>) -> Void
    func selectedCategoryForFilterPost(arrCategory : [ Dictionary<String,String>]) -> Void
}

class CategoryFirstViewController: BaseViewController,UITableViewDataSource,UITableViewDelegate {
    
    let service = WebService()
    
    var delegate : CreatePostCategoryDelegate?
    var isFromCreatePost : Bool = false
    var isFromFilterPost : Bool = false
    var isFromUserProfile : Bool = false
    var strUserID : String = ""
    var selectedCategoryForCreatePost : NSInteger = -1
    // MARK: - Control OutLet
    @IBOutlet var tblCategory: UITableView!
    @IBOutlet var btnBack: UIButton!
    @IBOutlet var btnSelect: UIButton!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var btnClearFilter: UIButton!
    @IBOutlet var widthConstBtnClearFilter: NSLayoutConstraint!
    
    //    var arrCategoryList = [ [ "" : "" , "" : "" , "" : "" ] ]
    var arrCategoryList = [ Dictionary<String,String>]()
    var arrSelectedCategoryListForFilter = [ Dictionary<String,String>]()
    
    // MARK: - UIView Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    
    func setupUI(){
        
        if isFromCreatePost {
            lblTitle.text = "Category List"
            //            callWebserviceforGettingCategory()
            callWebserviceforSelectedCategory()
            btnClearFilter.isHidden = true
            widthConstBtnClearFilter.constant = 0.0
        }
        else if isFromFilterPost{
            btnClearFilter.isHidden = false
            lblTitle.text = "Category List"
            callWebserviceforSelectedCategory()
            widthConstBtnClearFilter.constant = 50.0
        }
        else {
            btnClearFilter.isHidden = true
            lblTitle.text = "Select at Least 5 Categories"
            callWebserviceforGettingCategory()
            widthConstBtnClearFilter.constant = 0.0
        }
        
        tblCategory.register(CategoryFirstTVCell.self, forCellReuseIdentifier: "CategoryFirstTVCell")
        tblCategory.register(UINib.init(nibName: "CategoryFirstTVCell", bundle: nil), forCellReuseIdentifier: "CategoryFirstTVCell")
    }
    
    // MARK: - Action Method
    //    @IBAction func btnBackAction(_ sender: AnyObject) {
    //        self.navigationController!.popViewController(animated: true)
    //    }
    @IBAction func btnSelectAction(_ sender: AnyObject) {
        
        if isFromCreatePost {
            if selectedCategoryForCreatePost == -1 {
                let alertWarning = UIAlertView(title: Constant.APP_NAME, message: Constant.ALERT_MSG_CATEGORY_SELECT_FOR_CREATE_POST, delegate: nil, cancelButtonTitle: "OK")
                alertWarning.show()
            }
            else{
                var dictCategory = arrCategoryList[selectedCategoryForCreatePost]
                dictCategory["selectedCategory"] = "\(selectedCategoryForCreatePost)"
                delegate?.selectedCategoryForPost(dictCategory: dictCategory)
                self.navigationController!.popViewController(animated: true)
            }
        }
        else if isFromFilterPost {
            
            let predicate = NSPredicate(format: "selected == '1'")
            let arrSelectedCategory = arrCategoryList.filter { predicate.evaluate(with: $0) }
            
            delegate?.selectedCategoryForFilterPost(arrCategory: arrSelectedCategory)
            self.navigationController!.popViewController(animated: true)
        }
        else{
            let predicate = NSPredicate(format: "selected == '1'")
            print(arrCategoryList)
            let arrSelectedCategory = arrCategoryList.filter { predicate.evaluate(with: $0) }
            if arrSelectedCategory.count < 5 {
                self.showAlert(string: Constant.ALERT_MSG_MINIMUM_FIVE_CATEGORY_VALIDATE)
            }
            else{
                let predicate = NSPredicate(format: "selected == '1'")
                let arrSelectedCategory = arrCategoryList.filter { predicate.evaluate(with: $0) }
                var arrId = Array<String>()
                for (_, Element) in arrSelectedCategory.enumerated() {
                    arrId.append(Element["con_id"]!)
                }
                
                let strSelectedCatId = arrId.joined(separator: ",")
                callWebserviceforSetCategory(strCatId: strSelectedCatId)
            }
        }
    }
    
    @IBAction func btnClearFilterAction(_ sender: Any) {
        
        let alert:UIAlertController=UIAlertController(title: Constant.APP_NAME, message: "Are you sure to clear filter?", preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
        }
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.clearFilter()
        }
        // Add the actions
        alert.addAction(cancelAction)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func clearFilter() -> Void {
        arrSelectedCategoryListForFilter = [ Dictionary<String,String>]()
        for (index, var element) in self.arrCategoryList.enumerated() {
            element["selected"] = "0"
            self.arrCategoryList[index] = element
        }
        tblCategory.reloadData()
    }
    
    // MARK: - UITableView Datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCategoryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "CategoryFirstTVCell") as! CategoryFirstTVCell
        let dictCategory = arrCategoryList[indexPath.row]
        cell.lblCategory.text = dictCategory["con_name"]
        
        let fileUrl = NSURL(string: CATEGORY_ICON_BASEURL + dictCategory["con_image"]!)
        cell.imgCategory.sd_setImage(with: fileUrl as URL!)
        cell.imgCategory.contentMode = UIViewContentMode.redraw
        if isFromCreatePost {
            if selectedCategoryForCreatePost == indexPath.row {
                cell.btnCategorySelect.isSelected = true
            }
            else{
                cell.btnCategorySelect.isSelected = false
            }
        }
        else if isFromFilterPost {
            if dictCategory["selected"] == "1"  {
                cell.btnCategorySelect.isSelected = true
            }
            else{
                cell.btnCategorySelect.isSelected = false
            }
        }
        else {
            if dictCategory["selected"] == "0" {
                cell.btnCategorySelect.isSelected = false
            }
            else{
                cell.btnCategorySelect.isSelected = true
            }
        }
        cell.btnCategorySelect.isUserInteractionEnabled = false
        return cell
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if isFromCreatePost {
            selectedCategoryForCreatePost = indexPath.row
            tableView.reloadData()
        }
        else if isFromFilterPost {
            var dictCategory = arrCategoryList[indexPath.row] as Dictionary<String,String>
            
            if dictCategory["selected"] == "1" {
                dictCategory["selected"] = "0"
            }
            else{
                dictCategory["selected"] = "1"
            }
            arrCategoryList[indexPath.row] = dictCategory
            tableView .reloadRows(at: [indexPath], with: UITableViewRowAnimation.none)
        }
        else{
            var dictCategory = arrCategoryList[indexPath.row]
            if dictCategory["selected"] == "0" {
                dictCategory.updateValue("1", forKey: "selected")
            }
            else{
                dictCategory.updateValue("0", forKey: "selected")
            }
            
            arrCategoryList[indexPath.row] = dictCategory
            tableView .reloadRows(at: [indexPath], with: UITableViewRowAnimation.none)
        }
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent //or default
    }
    
    // MARK: - Webservice Calling Method
    func callWebserviceforGettingCategory() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            // RequestDict["cId"] = "101";
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "getCategory", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrCategoryList = dict?["data"] as! [ Dictionary<String,String>]
                        
                        for (index, var element) in self.arrCategoryList.enumerated() {
                            element["selected"] = "0"
                            self.arrCategoryList[index] = element
                        }
                        self.tblCategory.reloadData()
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    func callWebserviceforSetCategory(strCatId : String) -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            dictParam["category"] = strCatId
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertCategory", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        let userDefault = UserDefaults.standard
                        userDefault.set("1", forKey: "isLogin")
                        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
                        appDelegate.menuView?.intSelectedRow = 0
                        appDelegate.menuView?.RefreshUserDetail()
                        let vcHome = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                        vcHome.currentPostType = CurrentSelectedPostType.BOTH.rawValue
                        self.navigationController?.setViewControllers([vcHome], animated: true)
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - Webservice Calling Method
    func callWebserviceforSelectedCategory() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["level"] = "1";
            dictParam["listFor"] = "1";
            
            if isFromUserProfile {
                dictParam["userId"] = strUserID
            }
            else{
                let userDefault = UserDefaults.standard .dictionaryRepresentation()
                let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
                dictParam["userId"] = dictUser["reporter_id"] as? String
            }
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "selectedCategory", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.arrCategoryList = dict?["data"] as! [ Dictionary<String,String>]
                        
                        for (index, var element) in self.arrCategoryList.enumerated() {
                            element["selected"] = "0"
                            self.arrCategoryList[index] = element
                        }
                        
                        if self.isFromFilterPost {
                            for dict in self.arrSelectedCategoryListForFilter {
                                for (index, var element) in self.arrCategoryList.enumerated() {
                                    if element["con_name"] == dict["con_name"]{
                                        element["selected"] = "1"
                                        self.arrCategoryList[index] = element
                                    }
                                }
                            }
                        }
                        self.tblCategory.reloadData()
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

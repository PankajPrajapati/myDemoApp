//
//  AccountDetailViewController.swift
//  Oriscene
//
//  Created by Parth on 18/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class AccountDetailViewController: BaseViewController {
    
    var service = WebService()
    var selectedAccountType = ""
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var viewContent: UIView!
    @IBOutlet var btnIndividual: UIButton!
    @IBOutlet var btnBusiness: UIButton!
    @IBOutlet var btnOrganization: UIButton!
    @IBOutlet var viewAccountNameContainer: UIView!
    @IBOutlet var txtAccountName: UITextField!
    @IBOutlet var btnUpdate: UIButton!
    
    @IBOutlet var bottomConstScrollView: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        //timeCalculation()
        setUserData()
        self.setUpUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    func setUpUI() -> Void {
        btnUpdate.layer.cornerRadius = 3.0
        btnUpdate.layer.masksToBounds = true
        
        viewAccountNameContainer.layer.cornerRadius = 3.0
        viewAccountNameContainer.layer.masksToBounds = true
        viewAccountNameContainer.layer.borderWidth = 1.0
        viewAccountNameContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
    }
    
    func setUserData() -> Void {
        let userDefault = UserDefaults.standard.dictionaryRepresentation()
        
        if userDefault.keys.contains("business_data") {
            let dictUser = userDefault["business_data"] as! Dictionary<String,Any>
            
            let strAccountType = dictUser["accounttype"] as! String
            if strAccountType.characters.count > 0 {
                if strAccountType == "Individual" {
                    selectedAccountType = "Individual"
                    btnIndividual.isSelected = true
                    btnBusiness.isSelected = false
                    btnOrganization.isSelected = false
                }
                else if strAccountType == "Business" {
                    selectedAccountType = "Business"
                    btnIndividual.isSelected = false
                    btnBusiness.isSelected = true
                    btnOrganization.isSelected = false
                }
                else if strAccountType == "Organization" {
                    selectedAccountType = "Organization"
                    btnIndividual.isSelected = false
                    btnBusiness.isSelected = false
                    btnOrganization.isSelected = true
                }
                else{
                    selectedAccountType = ""
                }
            }else {
                selectedAccountType = ""
            }
            
            let strAccountName = dictUser["accountname"] as! String
            if strAccountName.characters.count > 0 {
                txtAccountName.text = strAccountName
            }else {
                txtAccountName.text = ""
            }
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstScrollView?.constant = 0.0
                //                self.scrollView.setContentOffset(CGPoint(x: 0.0, y: 0.0), animated: true)
            } else {
                self.bottomConstScrollView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    // MARK: - Action Method
    @IBAction func btnUpdateAction(_ sender: Any) {
        if validateAccountDetail() {
            //call webservice
            callWebserviceUpdateAccountDetail()
        }
    }
    @IBAction func btnIndividualAction(_ sender: Any) {
        btnOrganization.isSelected = false
        btnBusiness.isSelected = false
        btnIndividual.isSelected = true
        selectedAccountType = "Individual"
    }
    @IBAction func btnBusinessAction(_ sender: Any) {
        btnOrganization.isSelected = false
        btnBusiness.isSelected = true
        btnIndividual.isSelected = false
        selectedAccountType = "Business"
    }
    @IBAction func btnOrganizationAction(_ sender: Any) {
        btnOrganization.isSelected = true
        btnBusiness.isSelected = false
        btnIndividual.isSelected = false
        selectedAccountType = "Organization"
    }
    
    
    //MARK:- Validation Method
    func validateAccountDetail() -> Bool {
        if selectedAccountType == "" {
            showAlert(string: Constant.ALERT_MSG_ACCOUNT_TYPE_VALIDATE)
            return false
        }
        else if trimString(string: (txtAccountName.text)!).characters.count == 0 {
            showAlert(string: Constant.ALERT_MSG_ACCOUNT_NAME_VALIDATE)
            return false
        }
        else{
            return true
        }
    }
    
    //MARK:- Webservice Method
    func callWebserviceUpdateAccountDetail() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            dictParam["forWhat"] = "3"
            dictParam["accountType"] = selectedAccountType
            dictParam["accountName"] = txtAccountName.text
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "updateProfile", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        let userDefault = UserDefaults.standard
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                            userDefault.synchronize()
                        }
                        self.navigationController!.popViewController(animated: true)
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

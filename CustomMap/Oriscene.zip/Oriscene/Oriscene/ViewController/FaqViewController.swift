//
//  FaqViewController.swift
//  Oriscene
//
//  Created by Parth on 14/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class FaqViewController: BaseViewController , FAQDelegate , UITableViewDelegate , UITableViewDataSource {
    let service = WebService()
    var arrFAQList = [Dictionary<String,Any>]()
    var intSelectedRow : NSInteger = -1
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var viewMiddle: UIView!
    @IBOutlet var tblFAQ: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setUI()
        self.callWebserviceGetFAQ()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    func setUI() -> Void {
        
        viewMiddle.layer.shadowColor = UIColor.lightGray.cgColor
        viewMiddle.layer.shadowOpacity = 1.0
        viewMiddle.layer.shadowOffset = CGSize.zero
        viewMiddle.layer.shadowRadius = 5
        
        tblFAQ.register(FAQTVCell.self, forCellReuseIdentifier: "FAQTVCell")
        tblFAQ.register(UINib.init(nibName: "FAQTVCell", bundle: nil), forCellReuseIdentifier: "FAQTVCell")
        
    }
    
    // MARK: - UITableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrFAQList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "FAQTVCell") as! FAQTVCell
        cell.delegate = self
        cell.index = indexPath.row
        let dict = arrFAQList[indexPath.row] as Dictionary
        
        cell.lblTitle.attributedText = stringFromHtml(string: (dict["faq"] as! String))
        
        if (dict["selected"] as? String) == "1" {
            cell.btnTitle.isSelected = true
            cell.lblDescription.attributedText = stringFromHtml(string: (dict["answer"] as! String))
            cell.topSpaceConstLblDesc.constant = 19.0
            cell.bottomSpaceConstLblDesc.constant = 10.0
        }
        else{
            cell.btnTitle.isSelected = false
            cell.lblDescription.text = ""
            cell.topSpaceConstLblDesc.constant = 14.0
            cell.bottomSpaceConstLblDesc.constant = 0.0
        }
        cell.viewColorMark.backgroundColor = UIColor.blue
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    // MARK: - FAQDelegate
    func btnTitleActionClicked(index: NSInteger) {
        
        var dict = arrFAQList[index] as Dictionary
        if (dict["selected"] as? String) == "1" {
            dict["selected"] = "0"
        }
        else
        {
            dict["selected"] = "1"
        }
        arrFAQList[index] = dict
        tblFAQ.reloadRows(at: [IndexPath.init(row: index, section: 0)] , with: UITableViewRowAnimation.automatic)
    }
    
    //MARK:- Webservice
    func callWebserviceGetFAQ() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "getFAQ", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        print(dict!)
                        self.arrFAQList = dict?["data"] as! [Dictionary<String,Any>]
                        self.tblFAQ.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    private func stringFromHtml(string: String) -> NSAttributedString? {
        do {
            let data = string.data(using: String.Encoding.utf8, allowLossyConversion: true)
            if let d = data {
                let str = try NSAttributedString(data: d,
                                                 options: [NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType],
                                                 documentAttributes: nil)
                return str
            }
        } catch {
        }
        return nil
    }
}
extension String {
    func nsRange(from range: Range<String.Index>) -> NSRange {
        let from = range.lowerBound.samePosition(in: utf16)
        let to = range.upperBound.samePosition(in: utf16)
        return NSRange(location: utf16.distance(from: utf16.startIndex, to: from),
                       length: utf16.distance(from: from, to: to))
    }
}

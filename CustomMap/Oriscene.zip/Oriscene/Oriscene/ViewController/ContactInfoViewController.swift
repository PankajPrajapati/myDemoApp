//
//  ContactInfoViewController.swift
//  Oriscene
//
//  Created by Parth on 18/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class ContactInfoViewController: BaseViewController {
    
    let service = WebService()
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var viewContent: UIView!
    @IBOutlet var viewEmailContainer: UIView!
    @IBOutlet var viewAlternateEmailContainer: UIView!
    @IBOutlet var viewLandlineContainer: UIView!
    @IBOutlet var viewMobileContainer: UIView!
    @IBOutlet var viewAlternateMobileContainer: UIView!
    
    @IBOutlet var btnUpdate: UIButton!
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtAlternateEmail: UITextField!
    @IBOutlet var txtLandLine: UITextField!
    @IBOutlet var txtMobile: UITextField!
    @IBOutlet var txtAlternateMobile: UITextField!
    @IBOutlet var viewInputAccessoryDone: UIView!
    @IBOutlet var btnDone: UIButton!
    
    @IBOutlet var bottomConstScrollView: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setUpUI()
        setUpData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Custom Method
    
    func setUpUI() -> Void {
        viewEmailContainer.layer.cornerRadius = 3.0
        viewEmailContainer.layer.masksToBounds = true
        viewEmailContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewEmailContainer.layer.borderWidth = 1.0
        
        viewAlternateEmailContainer.layer.cornerRadius = 3.0
        viewAlternateEmailContainer.layer.masksToBounds = true
        viewAlternateEmailContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewAlternateEmailContainer.layer.borderWidth = 1.0
        
        viewLandlineContainer.layer.cornerRadius = 3.0
        viewLandlineContainer.layer.masksToBounds = true
        viewLandlineContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewLandlineContainer.layer.borderWidth = 1.0
        
        viewMobileContainer.layer.cornerRadius = 3.0
        viewMobileContainer.layer.masksToBounds = true
        viewMobileContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewMobileContainer.layer.borderWidth = 1.0
        
        viewAlternateMobileContainer.layer.cornerRadius = 3.0
        viewAlternateMobileContainer.layer.masksToBounds = true
        viewAlternateMobileContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewAlternateMobileContainer.layer.borderWidth = 1.0
        
        btnUpdate.layer.cornerRadius = 3.0
        btnUpdate.layer.masksToBounds = true
        
        viewInputAccessoryDone.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewInputAccessoryDone.layer.borderWidth = 1.0
        
        txtMobile.inputAccessoryView = viewInputAccessoryDone
        txtAlternateMobile.inputAccessoryView = viewInputAccessoryDone
        txtLandLine.inputAccessoryView = viewInputAccessoryDone
    }
    
    func setUpData() -> Void {
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("business_data") {
            let dictBussiness =  userDefault["business_data"] as! Dictionary<String,Any>
            txtEmail.text = dictBussiness["contactemail"] as? String
            txtAlternateEmail.text = dictBussiness["contactaltemail"] as? String
            txtMobile.text = dictBussiness["contactmobile"] as? String
            txtAlternateMobile.text = dictBussiness["contactaltmobile"] as? String
            txtLandLine.text = dictBussiness["contactlandline"] as? String
        }
    }
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstScrollView?.constant = 0.0
                
            } else {
                self.bottomConstScrollView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - Action Method
    
    @IBAction func btnUpdateAction(_ sender: Any) {
        if self.validateData() {
            self.callWebserviceToUpdateContactDtl()
        }
    }
    
    @IBAction func btnDoneInputAccessoryAction(_ sender: Any) {
        self.view.endEditing(true)
    }
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    // MARK: - Call Webservice
    func callWebserviceToUpdateContactDtl() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["contactEmail"] = txtEmail.text
            dictParam["contactAltEmail"] = txtAlternateEmail.text
            dictParam["contactLandline"] = txtLandLine.text
            dictParam["contactMobile"] = txtMobile.text
            dictParam["contactAltMobile"] = txtAlternateMobile.text
            
            dictParam["forWhat"] = "4"
            
            showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "updateProfile", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.showAlert(string: dict?["message"] as! String)
                        
                        let userDefault = UserDefaults.standard
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                            userDefault.synchronize()
                        }
                        self.navigationController!.popViewController(animated: true)
                    }
                    else if dict?["status"] as! String == "0" {
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            }, onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                print(error as Any)
                self.showAlert(string: (error?.localizedDescription)!)
            })
            
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - Validate Data
    
    func validateData() -> Bool {
        
        if trimString(string: txtEmail.text!).characters.count > 0 {
            if !isValidEmail(testStr: trimString(string: txtEmail.text!)) {
                showAlert(string: "Please enter valid email")
                return false
            }
        }
        
        if trimString(string: txtAlternateEmail.text!).characters.count > 0 {
            if !isValidEmail(testStr: trimString(string: txtAlternateEmail.text!)) {
                showAlert(string: "Please enter valid alternate email")
                return false
            }
        }
        
        if trimString(string: txtEmail.text!).characters.count > 0 || trimString(string: txtAlternateEmail.text!).characters.count > 0 {
            if trimString(string: txtEmail.text!) == trimString(string: txtAlternateEmail.text!) {
                showAlert(string: "Contact Email and Alternative Email should be different")
                return false
            }
        }
        
        if trimString(string: txtMobile.text!).characters.count > 0 || trimString(string: txtAlternateMobile.text!).characters.count > 0 {
            if trimString(string: txtMobile.text!) == trimString(string: txtAlternateMobile.text!) {
                showAlert(string: "Contact mobile and Alternative mobile should be different")
                return false
            }
        }
        
        if trimString(string: txtEmail.text!).characters.count == 0 && trimString(string: txtAlternateEmail.text!).characters.count == 0 && trimString(string: txtLandLine.text!).characters.count == 0 && trimString(string: txtMobile.text!).characters.count == 0 && trimString(string: txtAlternateMobile.text!).characters.count == 0 {
            showAlert(string: "Please provide contact information")
            return false
        }
        
        return true
    }
}

//
//  MyWalletViewController.swift
//  Oriscene
//
//  Created by TriState  on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit
import MessageUI

class MyWalletViewController: BaseViewController ,UITableViewDelegate ,UITableViewDataSource,TTTAttributedLabelDelegate, MFMailComposeViewControllerDelegate {
    
    var arrWalletData = [Dictionary<String,String>]()
    var dictWalletData = Dictionary<String,Any>()
    var service = WebService()
    
    @IBOutlet var tblWalletData: UITableView!
    
    @IBOutlet var viewFooter: UIView!
    
    @IBOutlet var lblContactUs: TTTAttributedLabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupMyWalletUI()
        
        
        arrWalletData = [
            [ "KeyData" : "Refers,Bonuses and Sharing","ValueData" : "0" ],
            [ "KeyData" : "Selling","ValueData" : "0" ],
            [ "KeyData" : "Total Earned","ValueData" : "0" ],
        ]
        
        self.tblWalletData.reloadData()
        callWebserviceWalletDetails()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: -Custom Method
    func setupMyWalletUI() {
        
        let strMain = "If you have any Questions regarding your account. please contact us immediately at : Contactus@oriscene.com"
        let strSub = "Contactus@oriscene.com"
        let range = (strMain as NSString).range(of:strSub)
        self.lblContactUs.delegate = self
        let url = URL(string: "")
        self.lblContactUs.addLink(to: url, with: range)
        
        
        tblWalletData.register(MyWalletTVCell.self, forCellReuseIdentifier: "MyWalletTVCell")
        tblWalletData.register(UINib.init(nibName: "MyWalletTVCell", bundle: nil), forCellReuseIdentifier: "MyWalletTVCell")
    }
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith url: URL!) {
        print("Link click")
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    // MARK: - Tableview Data source Delegate Method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrWalletData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "MyWalletTVCell") as! MyWalletTVCell
        cell.selectionStyle = .none
        let dictWallet = arrWalletData[indexPath.row]
        
        cell.lblKeyData.text = dictWallet["KeyData"]
        cell.lblValueData.text = dictWallet["ValueData"]
        
        if(indexPath.row == arrWalletData.count-1)
        {
            cell.lblKeyData.font = UIFont(name: "HelveticaNeueCyr-Medium", size: 17)!
        }
        else
        {
            cell.lblKeyData.font = UIFont(name: "HelveticaNeueCyr-Light", size: 17)!
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func tableView( _ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        return viewFooter
    }
    
    func tableView( _ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return viewFooter.frame.size.height
    }
    
    //    // MARK: - Button Action
    //    @IBAction func btnBackAction(_ sender: Any) {
    //        self.navigationController!.popViewController(animated: true)
    //    }
    
    //MARK:- Webservice
    func callWebserviceWalletDetails() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            //            self.showSpinner(enableInteraction: false)
            self.showSpinnerForChildVC(enableInteraction: false)
            service.callJSONMethod(methodName: "walletDetails", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        print(dict!)
                        self.dictWalletData = dict?["data"] as! Dictionary<String,Any>
                        self.setWalletArray()
                        let userDefault = UserDefaults.standard
                        userDefault.set(self.dictWalletData, forKey: "WalletData")
                        userDefault.synchronize()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    //MARK:- Custom Method set wallet array
    func setWalletArray() -> Void {
        var bon_ref_agr_amount = "0"
        var sellingAmount = "0"
        
        if dictWalletData.keys.contains("bon_ref_agr_amount") {
            bon_ref_agr_amount = dictWalletData["bon_ref_agr_amount"] as! String
        }
        if dictWalletData.keys.contains("selling_amount") {
            sellingAmount = dictWalletData["selling_amount"] as! String
        }
        var total = String(format:"%0.2f",Double(bon_ref_agr_amount)! + Double(sellingAmount)!)
        
        if dictWalletData.keys.contains("or_userwallet") {
            total = dictWalletData["or_userwallet"] as! String
        }
        
        arrWalletData = [
            [ "KeyData" : "Refers,Bonuses and Sharing","ValueData" : bon_ref_agr_amount ],
            [ "KeyData" : "Selling","ValueData" : sellingAmount ],
            [ "KeyData" : "Total Earned","ValueData" : total ],
        ]
        tblWalletData.reloadData()
        
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
        
        mailComposerVC.setToRecipients(["contactus@oriscene.com"])
        mailComposerVC.setSubject("")
        mailComposerVC.setMessageBody("", isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertView(title: Constant.APP_NAME, message: "Your device could not send e-mail.", delegate: self, cancelButtonTitle: "OK")
        sendMailErrorAlert.show()
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}

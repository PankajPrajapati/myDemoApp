//
//  LoginViewController.swift
//  Oriscene
//
//  Created by Parth on 07/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit

class LoginViewController: BaseViewController,UITextFieldDelegate, ForgotPasswordViewDelegate {
    var service = WebService()
    let facebookReadPermissions = ["public_profile", "email", "user_friends"]
    var dictFBData : NSDictionary?
    var viewForgotPassword : ForgotPasswordView? = nil
    // MARK: - Control OutLet
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var contentView: UIView!
    @IBOutlet var imgLogo: UIImageView!
    @IBOutlet var viewUserName: UIView!
    @IBOutlet var viewPassword: UIView!
    @IBOutlet var txtUserName: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var btnLogin: UIButton!
    @IBOutlet var btnFacebookLogin: UIButton!
    // MARK: - Constrant Outlet
    
    @IBOutlet var heightConstContentView: NSLayoutConstraint!
    @IBOutlet var topConstLogo: NSLayoutConstraint!
    @IBOutlet var topSpaceOR: NSLayoutConstraint!
    @IBOutlet var bottomSpaceConstOR: NSLayoutConstraint!
    @IBOutlet var topConstSignUp: NSLayoutConstraint!
    @IBOutlet var heightConstUserName: NSLayoutConstraint!
    @IBOutlet var bottomConstScrollView: NSLayoutConstraint!
    
    // MARK: - UIView Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if viewForgotPassword == nil {
            viewForgotPassword = ForgotPasswordView.instanceFromNib() as? ForgotPasswordView
            viewForgotPassword?.frame = UIScreen.main.bounds
            viewForgotPassword?.isHidden = true
            viewForgotPassword?.delegate = self
            viewForgotPassword?.alpha = 0.0
            self.view.addSubview(viewForgotPassword!)
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstScrollView?.constant = 0.0
                //                self.scrollView.setContentOffset(CGPoint(x: 0.0, y: 0.0), animated: true)
            } else {
                self.bottomConstScrollView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - Custom Method
    
    
    func setupUI(){
        
        UIApplication.shared.statusBarStyle = .lightContent
        
        viewUserName.layer.cornerRadius = 3.0
        viewUserName.layer.masksToBounds = true
        viewPassword.layer.cornerRadius = 3.0
        viewPassword.layer.masksToBounds = true
        btnLogin.layer.cornerRadius = 3.0
        btnLogin.layer.masksToBounds = true
        btnFacebookLogin.layer.cornerRadius = 3.0
        btnFacebookLogin.layer.masksToBounds = true
        
        if DeviceType.IS_IPHONE_5 {
            heightConstUserName.constant -= 7.0
            topConstLogo.constant -= 30.0
            topSpaceOR.constant -= 10.0
            bottomSpaceConstOR.constant -= 10.0
            topConstSignUp.constant -= 10.0
            heightConstContentView.constant = 568.0 - 20.0
        }
        else if DeviceType.IS_IPHONE_6_OR_7 {
            topConstLogo.constant += 10.0
            topSpaceOR.constant += 6.0
            bottomSpaceConstOR.constant += 7.0
            heightConstContentView.constant = 667.0 - 20.0
            topConstSignUp.constant -= 10.0
        }
        else if DeviceType.IS_IPHONE_6P_OR_7P {
            topConstLogo.constant += 20.0
            topSpaceOR.constant += 20.0
            bottomSpaceConstOR.constant += 20.0
            heightConstContentView.constant = 736.0 - 20.0
            topConstSignUp.constant -= 10.0
        }
    }
    
    // MARK: - Action Method
    @IBAction func btnLoginAction(_ sender: AnyObject) {
        txtUserName.resignFirstResponder()
        txtPassword.resignFirstResponder()
        if validateNormalLogin() {
            loginWithNormal()
        }
    }
    @IBAction func btnForgotPasswordAction(_ sender: AnyObject) {
        
        self.viewForgotPassword?.alpha = 0.0
        viewForgotPassword?.isHidden = false
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewForgotPassword?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewForgotPassword?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    @IBAction func btnFacebookLoginAction(_ sender: AnyObject) {
        
        if isConnectedToNetwork() {
            self.txtUserName.text = ""
            self.txtPassword.text = ""
            self.view.resignFirstResponder()
            DispatchQueue.main.async {
                self.showSpinner(enableInteraction: false)
            }
            
            let fbLoginManager = FBSDKLoginManager();
            fbLoginManager.loginBehavior = FBSDKLoginBehavior.systemAccount;
            
            FBSDKLoginManager().logIn(withReadPermissions:self.facebookReadPermissions) { (result, error) in
                if error != nil {
                    FBSDKLoginManager().logOut()
                    self.hideSpinner()
                } else if (result?.isCancelled)! {
                    // Handle cancellations
                    FBSDKLoginManager().logOut()
                    
                    self.hideSpinner()
                } else {
                    // If you ask for multiple permissions at once, you
                    // should check if specific permissions missing
                    var allPermsGranted = true
                    //result.grantedPermissions returns an array of _NSCFString pointers
                    let grantedPermissions = result?.grantedPermissions.map({"\($0)"})
                    
                    for permission in self.facebookReadPermissions {
                        if !(grantedPermissions?.contains(permission))! {
                            allPermsGranted = false
                            break
                        }
                    }
                    if allPermsGranted {
                        // Do work
                        //  let fbToken = result.token.tokenString
                        //   let fbUserID = result.token.userID
                        self.hideSpinner()
                        self.showSpinner(enableInteraction: false)
                        self.getFBUserData()
                        //successBlock()
                    } else {
                        
                        self.hideSpinner()
                        // failureBlock((nil)
                    }
                }
            }
        }
        else {
            self.showNoNetworkAlert()
        }
    }
    
    func getFBUserData(){
        if((FBSDKAccessToken.current()) != nil){
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email, gender, verified"]).start(completionHandler: { (connection, result, error) -> Void in
                if (error == nil){
                    //                    self.hideSpinnerNew()
                    self.dictFBData = result as? NSDictionary;
                    print(self.dictFBData ?? "")
                    self.callFBLoginMethod();
                }
                else{
                    self.hideSpinner()
                }
            })
        }
    }
    
    @IBAction func btnSignUpAction(_ sender: AnyObject) {
        let vcSignUp = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        self.navigationController?.pushViewController(vcSignUp, animated: true)
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent //or default
    }
    
    // MARK: - Webservice Call
    
    func callFBLoginMethod() -> Void {
        
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["rememberme"] = "0"
            dictParam["fbId"] = dictFBData?["id"] as? String
            dictParam["email"] = dictFBData?["email"] as? String
            //        dictParam["verified"] = dictFBData?["verified"]
            if dictFBData?["verified"] as! Bool{
                let dict = (dictFBData as! Dictionary<String, Any>)
                if dict.keys.contains("email") {
                    dictParam["verified"] = "1"
                }
                else{
                    dictParam["verified"] = "0"
                }
            }
            else{
                dictParam["verified"] = "0"
            }
            dictParam["gender"] = dictFBData?["gender"] as? String
            dictParam["lName"] = dictFBData?["last_name"] as? String
            dictParam["loginWith"] = "1"
            dictParam["password"] = ""
            dictParam["fName"] = dictFBData?["first_name"] as? String
            
            service.callJSONMethod(methodName: "login", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: {(_ dict :Dictionary<String, Any>?) in
                print(dict ?? "")
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        let userDefault = UserDefaults.standard
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                        }
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        userDefault.set("1", forKey: "isLogin")
                        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
                        appDelegate.menuView?.intSelectedRow = 0
                        appDelegate.menuView?.RefreshUserDetail()
                        
                        appDelegate.callWebserviceSetDeviceToken()
                        let vcHome = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                        vcHome.currentPostType = CurrentSelectedPostType.BOTH.rawValue
                        self.navigationController?.pushViewController(vcHome, animated: true)
                    }
                    else if dict?["status"] as! String == "2" {
                        let userDefault = UserDefaults.standard
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                        }
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        
                        let vcCategoryFirst = self.storyboard?.instantiateViewController(withIdentifier: "CategoryFirstViewController") as! CategoryFirstViewController
                        self.navigationController?.pushViewController(vcCategoryFirst, animated: true)
                    }
                    else if dict?["status"] as! String == "3" {
                        let userDefault = UserDefaults.standard
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                        }
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        
                        let vcSignUp = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
                        vcSignUp.isFromFacebook = true
                        vcSignUp.dictFBData = self.dictFBData;
                        self.navigationController?.pushViewController(vcSignUp, animated: true)
                    }
                    else{
                        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: dict?["message"] as? String , delegate: nil, cancelButtonTitle: "OK")
                        alertWarning.show()
                    }
                }
                
            }, onFailResponse: {(_ error : NSError?) in
                self.hideSpinner()
                let alertWarning = UIAlertView(title: Constant.APP_NAME, message: error?.localizedDescription , delegate: nil, cancelButtonTitle: "OK")
                alertWarning.show()
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func loginWithNormal() -> Void {
        
        if isConnectedToNetwork() {
            
            let dictParam = NSMutableDictionary()
            dictParam["rememberme"] = "0"
            dictParam["email"] = txtUserName.text
            dictParam["password"] = txtPassword.text
            dictParam["loginWith"] = "normal"
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "login", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: {(_ dict :Dictionary<String, Any>?) in
                self.hideSpinner()
                
                
                if !(dict?.isEmpty)! {
                    //            if [dict is [NSObject : Dictionary]] {
                    if dict?["status"] as! String == "1" {
                        self.txtUserName.text = ""
                        self.txtPassword.text = ""
                        self.view.resignFirstResponder()
                        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
                        appDelegate.menuView?.intSelectedRow = 0
                        let userDefault = UserDefaults.standard
                        userDefault.set("1", forKey: "isLogin")
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                        }
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        appDelegate.menuView?.RefreshUserDetail()
                        
                        appDelegate.callWebserviceSetDeviceToken()
                        let vcHome = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                        vcHome.currentPostType = CurrentSelectedPostType.BOTH.rawValue
                        self.navigationController?.pushViewController(vcHome, animated: true)
                    }
                    else if dict?["status"] as! String == "2" {
                        self.txtUserName.text = ""
                        self.txtPassword.text = ""
                        self.view.resignFirstResponder()
                        let userDefault = UserDefaults.standard
                        if let dictBussiness = dict?["business_data"] {
                            userDefault.set(dictBussiness, forKey: "business_data")
                        }
                        let dictData = dict?["data"] as! NSDictionary
                        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
                        for (_, element) in dictMutable.allKeys.enumerated() {
                            let tmpValue = dictMutable[element]
                            if (tmpValue is NSNull) {
                                dictMutable[element] = ""
                            }
                        }
                        print(dictMutable)
                        userDefault.set(dictMutable, forKey: "userData")
                        
                        let vcCategoryFirst = self.storyboard?.instantiateViewController(withIdentifier: "CategoryFirstViewController") as! CategoryFirstViewController
                        self.navigationController?.pushViewController(vcCategoryFirst, animated: true)
                    }
                    else{
                        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: dict?["message"] as? String , delegate: nil, cancelButtonTitle: "OK")
                        alertWarning.show()
                    }
                    //            }
                }
                
            }, onFailResponse: {(_ error : NSError?) in
                self.hideSpinner()
                let alertWarning = UIAlertView(title: Constant.APP_NAME, message: error?.localizedDescription , delegate: nil, cancelButtonTitle: "OK")
                alertWarning.show()
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceForgotPassword() -> Void {
        if isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            dictParam["email"] = self.trimString(string: (viewForgotPassword?.txtEmail.text)!)
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "forgotPassword", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: {(_ dict :Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1" {
                        self.hideForgotPasswordView()
                        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: dict?["message"] as? String , delegate: nil, cancelButtonTitle: "OK")
                        alertWarning.show()
                        
                    }
                    else{
                        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: dict?["message"] as? String , delegate: nil, cancelButtonTitle: "OK")
                        alertWarning.show()
                    }
                }
            }, onFailResponse: {(_ error : NSError?) in
                self.hideSpinner()
                let alertWarning = UIAlertView(title: Constant.APP_NAME, message: error?.localizedDescription , delegate: nil, cancelButtonTitle: "OK")
                alertWarning.show()
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - Validation
    
    func validateNormalLogin() -> Bool {
        if (self.trimString(string: (txtUserName.text)!).characters.count) == 0 {
            self.showAlert(string: Constant.ALERT_MSG_EMAIL_VALIDATE)
            return false
        } else if !self.isValidEmail(testStr: self.trimString(string:(txtUserName.text!))) {
            self.showAlert(string: Constant.ALERT_MSG_EMAIL_VALIDATE_FROMAT)
            return false
        } else if (self.trimString(string:(txtPassword.text)!).characters.count) == 0 {
            self.showAlert(string: Constant.ALERT_MSG_PASSWORD_VALIDATE)
            return false
        }
        else{
            return true
        }
    }
    
    // MARK: - ForgotPasswordViewDelegate
    func requestForgotPasswordClicked() {
        if self.trimString(string:(viewForgotPassword?.txtEmail.text!)!).characters.count == 0 {
            self.showAlert(string: Constant.ALERT_MSG_EMAIL_VALIDATE)
        }
        else if !self.isValidEmail(testStr: self.trimString(string:(viewForgotPassword?.txtEmail.text!)!)) {
            self.showAlert(string: Constant.ALERT_MSG_EMAIL_VALIDATE_FROMAT)
        }
        else{
            callWebserviceForgotPassword()
        }
    }
    
    func hideForgotPasswordView() {
        self.view.endEditing(true)
        
        viewForgotPassword?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewForgotPassword?.alpha = 0.0
        }) { (Bool) in
            self.viewForgotPassword?.isHidden = true
        }
    }
}

//
//  WalletViewController.swift
//  Oriscene
//
//  Created by TriState  on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class WalletViewController: BaseViewController, UICollectionViewDelegate, UICollectionViewDataSource,UIGestureRecognizerDelegate,UIScrollViewDelegate {
    
    var vcMYWallet : MyWalletViewController? = nil
    var vcTransHis : TransactHistoryViewController? = nil
    var vcWithdrawFund : WithdrawFundsViewController? = nil
    var arrViewControllers = [UIViewController]()
    var frame: CGRect = CGRect(x: 0, y: 0, width: 0, height: 0)
    var pageControl : UIPageControl = UIPageControl(frame:CGRect(x: 50, y: 300, width: 200, height: 50))
    
    var selectIndexPate = 0
    var arrButtonList = [ Dictionary<String,String>]()
    @IBOutlet var CVTitleButton: UICollectionView!
    @IBOutlet var scrollView: UIScrollView!
    
    // MARK: - Life cycle Method
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUI()
        arrButtonList = [[ "Title" : "My\nWallet" ] , [ "Title" : "Transaction\nHistory" ] , [ "Title" : "Withdraw\nFunds" ]]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("Frame := " + "\(vcMYWallet?.view.frame)")
    }
    
    // MARK: - Custom Method
    func setUI() -> Void {
        
        configurePageControl()
        
        self.CVTitleButton.register(UINib(nibName: "StatisticsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "StatisticsCell")
        self.CVTitleButton.register(UINib(nibName: "StatisticDataCell", bundle: nil), forCellWithReuseIdentifier: "StatisticDataCell")
        
        
        vcMYWallet = self.storyboard?.instantiateViewController(withIdentifier: "MyWalletViewController") as? MyWalletViewController
        
        vcTransHis = self.storyboard?.instantiateViewController(withIdentifier: "TransactHistoryViewController") as? TransactHistoryViewController
        
        vcWithdrawFund = self.storyboard?.instantiateViewController(withIdentifier: "WithdrawFundsViewController") as? WithdrawFundsViewController
        
        arrViewControllers = [vcMYWallet!,vcTransHis!,vcWithdrawFund!]
        scrollView.delegate = self
        
        for index in 0..<arrViewControllers.count {
            
            frame.origin.x = UIScreen.main.bounds.width * CGFloat(index)
            frame.size = self.scrollView.frame.size
            self.scrollView.isPagingEnabled = true
            print(frame)
            
            let subView = arrViewControllers[index]
            subView.view.frame = frame
            print(subView.view.frame)
            self.scrollView .addSubview(subView.view)
            addChildViewController(subView)
            subView.didMove(toParentViewController: self)
        }
        
        self.scrollView.contentSize = CGSize(width: UIScreen.main.bounds.width * CGFloat(arrViewControllers.count), height: self.scrollView.frame.size.height);
        // pageControl.addTarget(self, action: Selector(("changePage:")), for: UIControlEvents.valueChanged)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK :  PAGE CONTROL And Scroll Methods
    func configurePageControl() {
        
        self.pageControl.numberOfPages = arrViewControllers.count
        self.pageControl.currentPage = 0
        self.pageControl.tintColor = UIColor.red
        self.pageControl.pageIndicatorTintColor = UIColor.black
        self.pageControl.currentPageIndicatorTintColor = UIColor.green
        self.view.addSubview(pageControl)
        self.pageControl.isHidden = true
        
    }
    
    func changePage(sender: AnyObject) -> () {
        let x = CGFloat(pageControl.currentPage) * scrollView.frame.size.width
        scrollView.setContentOffset(CGPoint(x: x,y :0), animated: true)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let pageNumber = round(scrollView.contentOffset.x / scrollView.frame.size.width)
        pageControl.currentPage = Int(pageNumber)
        
        if(pageNumber == 0)
        {
            selectIndexPate = 0;
            vcMYWallet?.setupMyWalletUI()
        }
        else if (pageNumber == 1)
        {
            selectIndexPate = 1;
            vcTransHis?.setupTransactionHistoryUI()
        }
        else if (pageNumber == 2)
        {
            selectIndexPate = 2;
            vcWithdrawFund?.setupWithdrawFundsUI()
        }
        self.CVTitleButton.reloadData()
        
    }
    // MARK :  Collectionview Datasource and Delegate
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrViewControllers.count
    }
    
    private func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell : StatisticsCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StatisticsCell", for: indexPath as IndexPath) as! StatisticsCollectionViewCell
        let dictButton = arrButtonList[indexPath.row]
        cell.lblStatisticsTypes.text = dictButton["Title"]
        cell.lblStatisticsTypes.textAlignment = .center
        cell.lblStatisticsTypes.lineBreakMode = NSLineBreakMode.byCharWrapping
        if selectIndexPate == indexPath.row {
            cell.lblDivider.isHidden = false
            cell.lblStatisticsTypes.textColor = UIColor (colorLiteralRed: 34.0/255.0, green: 40.0/255.0, blue: 53.0/255.0, alpha: 1)
            
            
        } else {
            cell.lblDivider.isHidden = true
            cell.lblStatisticsTypes.textColor = UIColor (colorLiteralRed: 167.0/255.0, green: 169.0/255.0, blue:174.0/255.0, alpha: 1)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.view.endEditing(true)
        selectIndexPate = indexPath.row
        
        if(indexPath.row == 0)
        {
            self.scrollToPage(scrollView: self.scrollView, page: 0, animated: false)
            vcMYWallet?.viewDidLoad()
        }
        else if (indexPath.row == 1)
        {
            self.scrollToPage(scrollView: self.scrollView, page: 1, animated: false)
            vcTransHis?.viewDidLoad()
        }
        else if (indexPath.row == 2)
        {
            self.scrollToPage(scrollView: self.scrollView, page: 2, animated: false)
            vcWithdrawFund?.viewDidLoad()
        }
        CVTitleButton.reloadData()
    }
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 0, 0, 0);
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize
    {
        
        return CGSize(width:(collectionView.frame.size.width / CGFloat(arrViewControllers.count) - 5), height: collectionView.frame.size.height)
    }
    
    func scrollToPage(scrollView: UIScrollView, page: Int, animated: Bool) {
        var frame: CGRect = scrollView.frame
        frame.origin.x = frame.size.width * CGFloat(page);
        frame.origin.y = 0;
        scrollView.scrollRectToVisible(frame, animated: animated)
    }
    
}

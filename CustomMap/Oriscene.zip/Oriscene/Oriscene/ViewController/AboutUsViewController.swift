//
//  AboutUsViewController.swift
//  Oriscene
//
//  Created by Parth on 14/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class AboutUsViewController: BaseViewController {
    
    var isForTermsAndConditions : Bool = false
    let service  = WebService()
    
    @IBOutlet var webView: UIWebView!
    
    @IBOutlet var btnDismiss: UIButton!
    @IBOutlet var lblTitle: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        if isForTermsAndConditions {
            btnDismiss.isHidden = false
            lblTitle.text = "Terms and Conditions"
            callWebserviceforGettingTermsAndConditons()
        }
        else {
            btnDismiss.isHidden = true
            lblTitle.text = "About Us"
            callWebserviceforGettingAboutUs()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Action Method
    @IBAction func btnDismissAction(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
    // MARK: - Webservice Calling Method
    func callWebserviceforGettingTermsAndConditons() -> Void {
        
        let dictParam = NSMutableDictionary()
        dictParam["key"] = "terms_or";
        self.showSpinner(enableInteraction: true)
        service.callJSONMethod(methodName: "getContentByKey", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
            self.hideSpinner()
            if dict?["status"] as! String == "1"{
                let dict = dict?["data"] as! Dictionary<String,String>
                let strContent = dict["content"]
                self.webView.loadHTMLString(strContent!, baseURL: nil)
            }
            else {
                self.showAlert(string: dict?["message"] as! String)
            }
            
        },onFailResponse: { (_ error:NSError?) in
            self.hideSpinner()
            self.showAlert(string: (error?.localizedDescription)!)
        })
    }
    
    func callWebserviceforGettingAboutUs() -> Void {
        
        let dictParam = NSMutableDictionary()
        dictParam["key"] = "about_or";
        self.showSpinner(enableInteraction: true)
        service.callJSONMethod(methodName: "getContentByKey", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
            self.hideSpinner()
            if dict?["status"] as! String == "1"{
                let dict = dict?["data"] as! Dictionary<String,String>
                let strContent = dict["content"]
                self.webView.loadHTMLString(strContent!, baseURL: nil)
            }
            else {
                self.showAlert(string: dict?["message"] as! String)
            }
            
        },onFailResponse: { (_ error:NSError?) in
            self.hideSpinner()
            self.showAlert(string: (error?.localizedDescription)!)
        })
    }
}

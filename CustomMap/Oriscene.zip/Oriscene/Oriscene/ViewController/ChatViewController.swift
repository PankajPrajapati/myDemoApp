//
//  ChatViewController.swift
//  Oriscene
//
//  Created by Parth on 28/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol ChatViewDelegate {
    func replaceLastMessage(index : NSInteger, dictMessageData : Dictionary<String,Any>) -> Void
}

class ChatViewController: JSQMessagesViewController,UIGestureRecognizerDelegate {
    
    let incomingBubble = JSQMessagesBubbleImageFactory().incomingMessagesBubbleImage(with: UIColor(red: 242/255, green: 244/255, blue: 249/255, alpha: 1.0))
    let outgoingBubble = JSQMessagesBubbleImageFactory().outgoingMessagesBubbleImage(with: UIColor(red: 137/255, green: 147/255, blue: 166/255, alpha: 1.0))
    var delegate : ChatViewDelegate?
    var arrJSQMessages  = [JSQMessage]()
    var arrAllMessages = [Dictionary<String,Any>]()
    var indexOfMessage = NSInteger()
    
    var otherUser = JSQMessagesAvatarImageFactory().avatarImage(with: #imageLiteral(resourceName: "default_img"))
    var loggedUser = JSQMessagesAvatarImageFactory().avatarImage(with:  #imageLiteral(resourceName: "default_img"))
    var service = WebService()
    
    var ViewSpinner: UIView = UIView()
    var imageView : UIImageView = UIImageView()
    var dictMainMessage = Dictionary<String,Any>()
    var refreshControl = UIRefreshControl()
    var isRefressing = false
    var isForNotification = false
    var strOtherUserId = ""
    var dictOtherUser = Dictionary<String,Any>()
    
    // MARK: - OutLet
    @IBOutlet var spinner: UIActivityIndicatorView!
    
    @IBOutlet var viewWriteChatMessage: UIView!
    @IBOutlet var btnSendChatMsg: UIButton!
    @IBOutlet var lblChatMsg: UILabel!
    @IBOutlet var txtViewChatMsg: UITextView!
    
    @IBOutlet var bottomConstWriteChatMsgView: NSLayoutConstraint!
    @IBOutlet var viewShadow: UIView!
    
    // MARK: - View LifeCycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        //Set Collectionview Layout here for cell spacing
        let layout: UICollectionViewFlowLayout = JSQMessagesCollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 20
        collectionView!.collectionViewLayout = layout as! JSQMessagesCollectionViewFlowLayout
        
        self.collectionView!.alwaysBounceVertical = true
        let refresher = UIRefreshControl()
        refresher.addTarget(self, action: #selector(loadEarlierMessage), for: .valueChanged)
        refreshControl = refresher
        collectionView!.addSubview(refreshControl)
        lblTopTitle?.text = "Chat Message"
        setUserData()
        setUpUI()
        if strOtherUserId.characters.count > 0 {
            self.inputToolbar.isUserInteractionEnabled = false
            callWebserviceForChatMessage()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstWriteChatMsgView?.constant = 0.0
            } else {
                self.bottomConstWriteChatMsgView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.view.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    //MARK: - Custom Method
    func setUserData() -> Void {
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            if dictUser.keys.contains("photo") {
                let strPhotoId = dictUser["photo"]
                
                if strPhotoId is String {
                    let strPhotoName = strPhotoId as! String
                    if strPhotoName.characters.count != 0 {
                        let strUrl = PROFILE_PIC_BASEURL + (dictUser["photo"] as! String)
                        setUserImage(strUrl: strUrl, tag: 1)
                    }
                }
            }
        }
        
        if !dictMainMessage.isEmpty {
            dictOtherUser = dictMainMessage["user_data"] as! Dictionary<String,Any>
            
            strOtherUserId = dictOtherUser["reporter_id"] as! String
            let strusenickname = dictOtherUser["usenickname"] as! String
            if strusenickname == "1" {
                lblTopTitle?.text = dictOtherUser["reporter_name"] as? String
            }
            else{
                lblTopTitle?.text = (dictOtherUser["firstname"] as! String) + " " + (dictOtherUser["lastname"] as! String)
            }
            
            if dictOtherUser.keys.contains("photo") {
                let strPhotoId = dictOtherUser["photo"]
                if strPhotoId is String {
                    let strPhotoName = strPhotoId as! String
                    if strPhotoName.characters.count != 0 {
                        let strUrl = PROFILE_PIC_BASEURL + (dictOtherUser["photo"] as! String)
                        setUserImage(strUrl: strUrl, tag: 2)
                    }
                }
            }
        }
        else if !dictOtherUser.isEmpty {
            strOtherUserId = dictOtherUser["reporter_id"] as! String
            let strusenickname = dictOtherUser["usenickname"] as! String
            if strusenickname == "1" {
                lblTopTitle?.text = dictOtherUser["reporter_name"] as? String
            }
            else{
                lblTopTitle?.text = (dictOtherUser["firstname"] as! String) + " " + (dictOtherUser["lastname"] as! String)
            }
            
            if dictOtherUser.keys.contains("photo") {
                let strPhotoId = dictOtherUser["photo"]
                if strPhotoId is String {
                    let strPhotoName = strPhotoId as! String
                    if strPhotoName.characters.count != 0 {
                        let strUrl = PROFILE_PIC_BASEURL + (dictOtherUser["photo"] as! String)
                        setUserImage(strUrl: strUrl, tag: 2)
                    }
                }
            }
        }else{
            //do nothing
        }
    }
    
    func setUpUI() -> Void {
        btnSendChatMsg.layer.cornerRadius = btnSendChatMsg.frame.size.height / 2
        btnSendChatMsg.layer.masksToBounds = true
        self.inputToolbar.contentView?.leftBarButtonItem = nil
        let sendButton = UIButton()
        sendButton.setImage(UIImage(named: "send_icon"), for: .normal)
        sendButton.backgroundColor = UIColor(red: 16/255, green: 87/255, blue: 198/255, alpha: 1.0)
        self.inputToolbar.contentView?.rightBarButtonItem = sendButton
        self.automaticallyScrollsToMostRecentMessage = true
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard(gesture:)))
        tapGestureRecognizer.delegate = self
        self.collectionView?.addGestureRecognizer(tapGestureRecognizer)
    }
    
    // MARK: - Action Navigation
    
    @IBAction override func btnBackClickAction(_ sender: Any) {
        dictMainMessage["last_msg"] = arrAllMessages.last
        delegate?.replaceLastMessage(index: indexOfMessage, dictMessageData: dictMainMessage)
        self.navigationController!.popViewController(animated: true)
    }
    
    @IBAction func btnSendChatMsgAction(_ sender: Any) {
        txtViewChatMsg.resignFirstResponder()
    }
    
    func reloadMessagesView() {
        self.collectionView?.reloadData()
    }
    
    // MARK: - JSQ Chat collectionview Mthods
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrJSQMessages.count
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView, layout collectionViewLayout: JSQMessagesCollectionViewFlowLayout, heightForCellBottomLabelAt indexPath: IndexPath) -> CGFloat {
        return 20
    }
    override func collectionView(_ collectionView: JSQMessagesCollectionView, attributedTextForCellBottomLabelAt indexPath: IndexPath) -> NSAttributedString? {
        let message: JSQMessage = self.arrJSQMessages[indexPath.item]
        let dateFormatter = DateFormatter()
        dateFormatter.locale = NSLocale(localeIdentifier: "en-US") as Locale!
        dateFormatter.dateFormat = "MMM dd,yyyy"
        let strDate = dateFormatter.string(from: message.date)
        dateFormatter.dateFormat = "hh:mm a"
        let strTime = dateFormatter.string(from: message.date)
        let attributedString = NSMutableAttributedString(string:"\(strDate) at \(strTime)")
        let fontAtt = [NSForegroundColorAttributeName: UIColor.gray, NSFontAttributeName: UIFont.systemFont(ofSize: 14.0)]
        let range = NSMakeRange(0, attributedString.length)
        attributedString.setAttributes(fontAtt, range: range)
        
        return attributedString;
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView, messageDataForItemAt indexPath: IndexPath) -> JSQMessageData {
        
        let message = arrJSQMessages[indexPath.item]
        return message
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView, messageBubbleImageDataForItemAt indexPath: IndexPath) -> JSQMessageBubbleImageDataSource? {
        let data = arrJSQMessages[indexPath.row]
        switch(data.senderId) {
        case self.senderId():
            return self.outgoingBubble
        default:
            return self.incomingBubble
        }
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView, avatarImageDataForItemAt indexPath: IndexPath) -> JSQMessageAvatarImageDataSource? {
        
        let message = arrJSQMessages[indexPath.item]
        if message.senderId == self.senderId(){
            return loggedUser
        }else{
            return otherUser
        }
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView, didDeleteMessageAt indexPath: IndexPath) {
        //to do anything after deleting message
    }
    
    // MARK: - Set userId and UserDisplay Name
    override func senderId() -> String {
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        let strSenderId = dictUser["reporter_id"] as? String
        
        return strSenderId!
    }
    override func senderDisplayName() -> String {
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            let strSenderName = (dictUser["firstname"] as! String) + " " + (dictUser["lastname"] as! String)
            return strSenderName
        }
        
        return ""
    }
    
    // MARK: - Send Button delegate
    override func didPressSend(_ button: UIButton, withMessageText text: String, senderId: String, senderDisplayName: String, date: Date) {
        print(self.dictMainMessage)
        let dictParam = NSMutableDictionary()
        dictParam["otherUserId"] = strOtherUserId
        dictParam["postId"] = ""
        dictParam["message"] = text
        callSendMessageWebservice(dictParam:dictParam)
    }
    
    // MARK: - tap Gesture Delegate Method
    func gestureRecognizer(_: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWith shouldRecognizeSimultaneouslyWithGestureRecognizer:UIGestureRecognizer) -> Bool {
        return true
    }
    
    func dismissKeyboard(gesture: UITapGestureRecognizer) {
        self.inputToolbar.contentView?.textView?.resignFirstResponder()
    }
    
    // MARK: - Custom Method //Get User Image And set in Collectionview
    func setUserImage(strUrl : String, tag : Int) -> Void {
        
        if strUrl.characters.count == 0 {
            return
        }
        
        let fileUrl = NSURL(string: strUrl)!
        let imageView = UIImageView()
        imageView.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
            if error != nil {
                print("Failed: \(error)")
            } else {
                print("Success")
                if tag == 1 {
                    self.loggedUser = JSQMessagesAvatarImageFactory().avatarImage(with: image!)
                    
                }
                else {
                    self.otherUser = JSQMessagesAvatarImageFactory().avatarImage(with: image!)
                }
            }
        }
    }
    
    // MARK: - Webservice Call
    
    func callWebserviceForChatMessage() -> Void {
        
        if self.isConnectedToNetwork() {
            if !isRefressing && !isForNotification {
                self.showSpinner(enableInteraction: false)
            }
            
            let dictParam = NSMutableDictionary()
            dictParam["otherUserId"] = strOtherUserId
            
            if arrAllMessages.count > 0 {
                dictParam["msgCount"] = String("\(arrAllMessages.count)")
            }else{
                dictParam["msgCount"] = ""
            }
            
            if isForNotification {
                let dictLastMsg = arrAllMessages.last
                let lastMsgId = dictLastMsg?["msg_id"] as! String
                dictParam["lastMsgId"] = lastMsgId ////use when push notification arrive
                dictParam["msgCount"] = ""
            }else{
                dictParam["lastMsgId"] = ""
            }
            
            service.callJSONMethod(methodName: "getAllMessage", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                self.inputToolbar.isUserInteractionEnabled = true
                if self.isRefressing {
                    self.refreshControl.endRefreshing()
                }
                if self.isForNotification {
                    self.isForNotification = false
                }
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        let tempArray =  dict?["data"] as! [Dictionary<String,Any>]
                        if self.isRefressing {
                            self.isRefressing = false
                            self.arrAllMessages.insert(contentsOf: tempArray, at: 0)
                            self.createChatMessage()
                            self.reloadMessagesView()
                            let indexPath = IndexPath(item: tempArray.count - 1 , section: 0)
                            self.scroll(to:indexPath , animated: false)
                        }
                        else{
                            self.arrAllMessages += tempArray
                            self.createChatMessage()
                            self.reloadMessagesView()
                            self.scrollToBottom(animated: false)
                        }
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                        self.isForNotification = false
                        self.isRefressing = false
                        self.lblNoMessage?.isHidden = false
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
                self.isForNotification = false
                self.isRefressing = false
            })
        }
        else{
            self.showNoNetworkAlert()
            self.isForNotification = false
            self.isRefressing = false
        }
    }
    
    func callSendMessageWebservice(dictParam : NSMutableDictionary) -> Void {
        if self.isConnectedToNetwork() {
            service.callJSONMethod(methodName: "sendMessage", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        let dictMsg =  dict?["data"] as! Dictionary<String,Any>
                        self.arrAllMessages.append(dictMsg)
                        self.createChatMessage()
                        self.finishSendingMessage()
                        self.lblNoMessage?.isHidden = true
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    // MARK: - Refresh Method
    
    func loadEarlierMessage() {
        if !isRefressing {
            isRefressing = true
            callWebserviceForChatMessage()
        }
    }
    
    // MARK: - Create DemoChat Method
    func createChatMessage() {
        if arrJSQMessages.count > 0 {
            arrJSQMessages.removeAll()
        }
        for (_, dictData) in arrAllMessages.enumerated() {
            let senderId = dictData["from_id"] as! String
            let senderName = dictData["msg_by"] as! String
            let strDate = dictData["posteddate"]  as! String
            
            let strMsg = dictData["message"] as! String
            let dateFormater = DateFormatter()
            dateFormater.timeZone = NSTimeZone.local
            dateFormater.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let date  =  dateFormater.date(from: strDate)
            
            let message = JSQMessage(senderId:senderId , senderDisplayName:senderName, date: date!, text: strMsg)
            arrJSQMessages.append(message)
        }
    }
    // MARK: - BaseView Methods
    
    func showSpinner(enableInteraction : Bool) -> Void {
        
        imageView.stopRotating()
        ViewSpinner.removeFromSuperview()
        
        self.view.isUserInteractionEnabled = enableInteraction
        ViewSpinner = UIView(frame: CGRect(x:0, y:0, width:80, height: 80))
        let window = UIApplication.shared.windows.first
        ViewSpinner.center = (window?.center)!//self.view.center;
        ViewSpinner.backgroundColor = UIColor.init(red: 51.0/255.0, green: 59.0/255.0, blue: 81.0/255.0, alpha: 1.0)
        ViewSpinner.alpha = 0.5
        ViewSpinner.layer.cornerRadius = 5.0
        ViewSpinner.bringSubview(toFront: ViewSpinner)
        
        let imageName = "img_loader.png"
        let globalImage = UIImage(named: imageName)
        imageView = UIImageView(image: globalImage!)
        imageView.frame = CGRect(x: ViewSpinner.frame.size.width/2-25, y: ViewSpinner.frame.size.height/2-25, width: 50, height: 50)
        
        imageView.startRotating()
        imageView.layer.cornerRadius = imageView.frame.size.height/2
        imageView.layer.masksToBounds = true
        ViewSpinner.addSubview(imageView)
        
        self.view.addSubview(ViewSpinner)
    }
    
    func hideSpinner() -> Void {
        self.view.isUserInteractionEnabled = true
        
        imageView.stopRotating()
        ViewSpinner.removeFromSuperview()
    }
    
    // MARK: - Recability Method
    func isConnectedToNetwork() -> Bool {
        
        if (currentReachabilityStatus == ReachabilityStatus.reachableViaWiFi)
        {
            return true
        }
        else if (currentReachabilityStatus == ReachabilityStatus.reachableViaWWAN)
        {
            return true
        }
        else{
            return false
        }
    }
    
    func showNoNetworkAlert() -> Void {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Please check internet connection." , delegate: nil, cancelButtonTitle: "OK")
        alertWarning.show()
    }
    
    func showAlert(string : String) -> Void {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: string , delegate: nil, cancelButtonTitle: "OK")
        alertWarning.show()
    }
    
    
    func addNewChatMessage(notification: NSNotification) -> Void {
        //call webservice with last message id here
        isForNotification = true
        callWebserviceForChatMessage()
    }
    
    func addNewChatMessages() -> Void {
        //call webservice with last message id here
        isForNotification = true
        callWebserviceForChatMessage()
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent //or default
    }
}

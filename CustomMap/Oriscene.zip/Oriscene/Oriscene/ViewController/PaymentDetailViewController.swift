//
//  PaymentDetailViewController.swift
//  Oriscene
//
//  Created by Tristate on 12/20/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class PaymentDetailViewController: BaseViewController, PayPalPaymentDelegate, PayPalFuturePaymentDelegate, PayPalProfileSharingDelegate {
    
    var service = WebService()
    var resultText = "" // empty
    var payPalConfig = PayPalConfiguration() // default
    var isFromBidVC : Bool = false
    
    var dictPostDtl = Dictionary<String,Any>()
    var dictEcommerceAgreement = Dictionary<String,Any>()
    
    @IBOutlet weak var lblTransectionNumber: UILabel!
    @IBOutlet weak var lblSellerName: UILabel!
    @IBOutlet weak var lblBuyerName: UILabel!
    @IBOutlet weak var lblFileType: UILabel!
    @IBOutlet weak var lblFileCount: UILabel!
    @IBOutlet weak var lblFileFormat: UILabel!
    @IBOutlet weak var lblFileSize: UILabel!
    @IBOutlet weak var lblTotalFileSize: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var btnMakePayment: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up payPalConfig
        payPalConfig.acceptCreditCards = false
        payPalConfig.merchantName = "Oriscene, Inc."
        payPalConfig.merchantPrivacyPolicyURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/privacy-full")
        payPalConfig.merchantUserAgreementURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/useragreement-full")
        // Setting the languageOrLocale property is optional.
        //
        // If you do not set languageOrLocale, then the PayPalPaymentViewController will present
        // its user interface according to the device's current language setting.
        //
        // Setting languageOrLocale to a particular language (e.g., @"es" for Spanish) or
        // locale (e.g., @"es_MX" for Mexican Spanish) forces the PayPalPaymentViewController
        // to use that language/locale.
        //
        // For full details, including a list of available languages and locales, see PayPalPaymentViewController.h.
        
        payPalConfig.languageOrLocale = Locale.preferredLanguages[0]
        
        // Setting the payPalShippingAddressOption property is optional.
        //
        // See PayPalConfiguration.h for details.
        
        payPalConfig.payPalShippingAddressOption = .none;
        
        print("PayPal iOS SDK Version: \(PayPalMobile.libraryVersion())")
        
        // Do any additional setup after loading the view.
        btnMakePayment.layer.cornerRadius = 5.0;
        btnMakePayment.layer.masksToBounds = true
        self.setupData()
    }
    
    func setupData() -> Void {
        
        var dictUserData = Dictionary<String,Any>()
        var dictViewMoredtl = Dictionary<String,Any>()
        
        if isFromBidVC {
            dictUserData = dictPostDtl["user_data"] as! Dictionary<String,Any>
            dictViewMoredtl = dictPostDtl["view_more_detail"] as! Dictionary<String,Any>
        }else{
            let dictPostDtlIndividual = dictPostDtl["postdetailindiv"] as! Dictionary<String, Any>
            dictUserData = dictPostDtlIndividual["postuserdata"] as! Dictionary<String,Any>
            dictViewMoredtl = dictPostDtlIndividual["view_more_detail"] as! Dictionary<String,Any>
        }
        lblSellerName.text = (dictUserData["firstname"] as! String) + " " + (dictUserData["lastname"] as! String)
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            let strusenickname = dictUser["usenickname"] as! String
            if strusenickname == "1" {
                lblBuyerName.text = dictUser["reporter_name"] as? String
            }
            else{
                lblBuyerName.text = (dictUser["firstname"] as! String) + " " + (dictUser["lastname"] as! String)
            }
        }
        else{
            lblBuyerName.text = ""
        }
        lblFileType.text = dictViewMoredtl["file_type"] as? String
        lblFileSize.text = dictViewMoredtl["file_size_list"] as? String
        lblTotalFileSize.text = dictViewMoredtl["file_size"] as? String
        lblFileFormat.text = dictViewMoredtl["file_format"] as? String
        lblFileCount.text = dictViewMoredtl["multi_file"] as? String
        lblAmount.text = "$ " + (dictViewMoredtl["price"] as? String)!
        let transactionNumber = self.dictEcommerceAgreement["trans_num"] as AnyObject
        
        lblTransectionNumber.text =  "\(transactionNumber)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Button Click Action
    @IBAction func btnMakePaymentClickAction(_ sender: Any) {
        
        // Remove our last completed payment, just for demo purposes.
        resultText = ""
        
        // Note: For purposes of illustration, this example shows a payment that includes
        //       both payment details (subtotal, shipping, tax) and multiple items.
        //       You would only specify these if appropriate to your situation.
        //       Otherwise, you can leave payment.items and/or payment.paymentDetails nil,
        //       and simply set payment.amount to your total charge.
        
        // Optional: include multiple items
        var dictViewMoredtl = Dictionary<String,Any>()
        if isFromBidVC {
            dictViewMoredtl = dictPostDtl["view_more_detail"] as! Dictionary<String,Any>
        }else{
            let dictPostDtlIndividual = dictPostDtl["postdetailindiv"] as! Dictionary<String,Any>
            dictViewMoredtl = dictPostDtlIndividual["view_more_detail"] as! Dictionary<String,Any>
        }
        
        let item1 = PayPalItem(name: "Oriscene", withQuantity: 1, withPrice: NSDecimalNumber(string: (dictViewMoredtl["price"] as? String)!), withCurrency: "USD", withSku: "Hip-0037")
        
        let items = [item1]
        let subtotal = PayPalItem.totalPrice(forItems: items)
        
        // Optional: include payment details
        let shipping = NSDecimalNumber(string: "0.0")
        let tax = NSDecimalNumber(string: "0.0")
        let paymentDetails = PayPalPaymentDetails(subtotal: subtotal, withShipping: shipping, withTax: tax)
        
        let total = subtotal.adding(shipping).adding(tax)
        
        let payment = PayPalPayment(amount: total, currencyCode: "USD", shortDescription: "Oriscene", intent: .sale)
        
        payment.items = items
        payment.paymentDetails = paymentDetails
        
        if (payment.processable) {
            let paymentViewController = PayPalPaymentViewController(payment: payment, configuration: payPalConfig, delegate: self)
            present(paymentViewController!, animated: true, completion: nil)
        }
        else {
            // This particular payment will always be processable. If, for
            // example, the amount was negative or the shortDescription was
            // empty, this payment wouldn't be processable, and you'd want
            // to handle that here.
            print("Payment not processalbe: \(payment)")
        }
    }
    
    //    @IBAction func btnBackClickAction(_ sender: Any) {
    //        self.navigationController!.popViewController(animated: true)
    //    }
    
    // MARK: - PayPalPaymentDelegate
    
    func payPalPaymentDidCancel(_ paymentViewController: PayPalPaymentViewController) {
        print("PayPal Payment Cancelled")
        resultText = ""
        paymentViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalPaymentViewController(_ paymentViewController: PayPalPaymentViewController, didComplete completedPayment: PayPalPayment) {
        print("PayPal Payment Success !")
        paymentViewController.dismiss(animated: true, completion: { () -> Void in
            // send completed confirmaion to your server
            //            print("Here is your proof of payment:\n\n\(completedPayment.confirmation)\n\nSend this to your server for confirmation and fulfillment.")
            
            let dictConfirmation = completedPayment.confirmation as! Dictionary<String,Any>
            let dictResponse = dictConfirmation["response"] as! Dictionary<String,Any>
            let dictParam = NSMutableDictionary()
            
            let transactionNumber = self.dictEcommerceAgreement["trans_num"] as AnyObject
            dictParam["transId"] = "\(transactionNumber)"
            dictParam["paymentTransId"] = dictResponse["id"] as! String
            dictParam["paymentDate"] = "" // dictResponse["create_time"] as! String
            
            dictParam["payerEmail"] = ""
            dictParam["currency"] = "USD"
            
            self.callWebserviceConfirmPayment(dictParam: dictParam)
            self.resultText = completedPayment.description
        })
    }
    
    // MARK: Future Payments
    
    @IBAction func authorizeFuturePaymentsAction(_ sender: AnyObject) {
        let futurePaymentViewController = PayPalFuturePaymentViewController(configuration: payPalConfig, delegate: self)
        present(futurePaymentViewController!, animated: true, completion: nil)
    }
    
    
    func payPalFuturePaymentDidCancel(_ futurePaymentViewController: PayPalFuturePaymentViewController) {
        print("PayPal Future Payment Authorization Canceled")
        futurePaymentViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalFuturePaymentViewController(_ futurePaymentViewController: PayPalFuturePaymentViewController, didAuthorizeFuturePayment futurePaymentAuthorization: [AnyHashable: Any]) {
        print("PayPal Future Payment Authorization Success!")
        // send authorization to your server to get refresh token.
        futurePaymentViewController.dismiss(animated: true, completion: { () -> Void in
            self.resultText = futurePaymentAuthorization.description
            //            self.showAlert(string: self.resultText)
        })
    }
    
    // MARK: Profile Sharing
    
    @IBAction func authorizeProfileSharingAction(_ sender: AnyObject) {
        let scopes = [kPayPalOAuth2ScopeOpenId, kPayPalOAuth2ScopeEmail, kPayPalOAuth2ScopeAddress, kPayPalOAuth2ScopePhone]
        let profileSharingViewController = PayPalProfileSharingViewController(scopeValues: NSSet(array: scopes) as Set<NSObject>, configuration: payPalConfig, delegate: self)
        present(profileSharingViewController!, animated: true, completion: nil)
    }
    
    // PayPalProfileSharingDelegate
    
    func userDidCancel(_ profileSharingViewController: PayPalProfileSharingViewController) {
        print("PayPal Profile Sharing Authorization Canceled")
        profileSharingViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalProfileSharingViewController(_ profileSharingViewController: PayPalProfileSharingViewController, userDidLogInWithAuthorization profileSharingAuthorization: [AnyHashable: Any]) {
        print("PayPal Profile Sharing Authorization Success!")
        
        // send authorization to your server
        
        profileSharingViewController.dismiss(animated: true, completion: { () -> Void in
            self.resultText = profileSharingAuthorization.description
            //            self.showAlert(string: self.resultText)
        })
        
    }
    
    // MARK: - Webservice methods
    func callWebserviceConfirmPayment(dictParam : NSMutableDictionary) -> Void {
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            service.callJSONMethod(methodName: "makePayment", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        let alert:UIAlertController=UIAlertController(title: Constant.APP_NAME , message: dict?["message"] as? String, preferredStyle: UIAlertControllerStyle.alert)
                        let cameraAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default)
                        {
                            UIAlertAction in
                            for (_, element) in (self.navigationController?.viewControllers.enumerated())!{
                                if element.isKind(of: HomeViewController.self) {
                                    let vc = element as! HomeViewController
                                    vc.reloadPostData()
                                    self.navigationController!.popToViewController(vc, animated: true)
                                    return
                                }
                            }
                            
                            let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                            homeVC.currentPostType = CurrentSelectedPostType.BOTH.rawValue
                            let appDelegate = UIApplication.shared.delegate as! AppDelegate
                            appDelegate.menuView?.intSelectedRow = MenuIndex.HOME.rawValue
                            appDelegate.menuView?.reloadDataForMenu()
                            self.navigationController?.setViewControllers([homeVC], animated: true)
                        }
                        alert.addAction(cameraAction)
                        self.present(alert, animated: true, completion: nil)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
}

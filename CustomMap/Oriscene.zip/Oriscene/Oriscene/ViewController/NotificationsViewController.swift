//
//  NotificationsViewController.swift
//  Oriscene
//
//  Created by Parth on 11/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class NotificationsViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    let service = WebService()
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var tblNotifications: UITableView!
    var arrNotification = [Dictionary<String,Any>]()
    var postCount = 0
    var isPagingAvailable = true
    var isLoadingData = false
    var viewForFooter : TableFooterView? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblNotifications.register(NotificationListTVCell.self, forCellReuseIdentifier: "NotificationListTVCell")
        tblNotifications.register(UINib.init(nibName: "NotificationListTVCell", bundle: nil), forCellReuseIdentifier: "NotificationListTVCell")
        
        // Do any additional setup after loading the view.
        self.callWebserviceNotification()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - UITableView DataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrNotification.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let viewCommentSectionView = NotificationSectionHeaderView.instanceFromNib() as! NotificationSectionHeaderView
        if section == 0 {
            viewCommentSectionView.lblHeaderTitle.text = "Notification"
        }
        else{
            viewCommentSectionView.lblHeaderTitle.text = "Old Notification"
        }
        return viewCommentSectionView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "NotificationListTVCell") as! NotificationListTVCell
        cell.index = indexPath.row
        let dictNotificaiton = arrNotification[indexPath.row] as Dictionary<String,Any>
        cell.lblNotificationMsg.text = dictNotificaiton["not_message"] as! String?
        if let strDate = dictNotificaiton["not_date"] {
            cell.lblTime.text = convertStringToDate(strDate: strDate as! String)
        }else{
            cell.lblTime.text = ""
        }
        
        let checkd = dictNotificaiton["user_data"]
        
        if checkd is Dictionary<String,Any> {
            let dictUserData = dictNotificaiton["user_data"] as! Dictionary<String,Any>
            if dictUserData.count > 0 {
                if dictUserData.keys.contains("photo") {
                    let strPhotoNameID = dictUserData["photo"]
                    if strPhotoNameID is String {
                        let strPhotoName = strPhotoNameID as! String
                        if strPhotoName.characters.count != 0 {
                            let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                            let fileUrl = NSURL(string: strUrl)
                            
                            cell.imgProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                                if error != nil {
                                    print("Failed: \(error)")
                                } else {
                                    print("Success")
                                }
                            }
                        }
                        else{
                            cell.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
                        }
                    }
                    else{
                        cell.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
                    }
                }
                else{
                    cell.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
                }
                cell.lblUserName.text = (dictUserData["firstname"] as! String?)! + " " + (dictUserData["lastname"] as! String?)!
            }
            else{
                cell.lblUserName.text = "Oriscene"
                cell.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
            
            cell.widthConstLblUnreadStatus.constant = 0.0
            cell.leadingConstProfilePic.constant = 0.0
            
        } else {
            cell.lblUserName.text = "Oriscene"
            cell.imgProfilePic.image = #imageLiteral(resourceName: "default_img")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 114.0
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 40.0
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let dictNotification = arrNotification[indexPath.row]
        let strRedirect = dictNotification["redirect"] as! String
        print(strRedirect)
        if strRedirect == "followers" {
            appDelegate.menuView?.intSelectedRow = MenuIndex.FOLLOWERS.rawValue
            appDelegate.menuView?.reloadDataForMenu()
            let vcFollowers = self.storyboard?.instantiateViewController(withIdentifier: "FollowersViewController") as! FollowersViewController
            self.navigationController?.setViewControllers([vcFollowers], animated: true)
        }
        else if strRedirect == "share" {
            let vcPostDetail = self.storyboard?.instantiateViewController(withIdentifier: "PostDetailViewController") as! PostDetailViewController
            vcPostDetail.isFromNotification = 1
            vcPostDetail.strPostId = dictNotification["post_id"] as! String
            vcPostDetail.currentPostType = CurrentSelectedPostType.SHARE_POST.rawValue
            self.navigationController?.pushViewController(vcPostDetail, animated: true)
        }
        else if strRedirect == "sell" {
            appDelegate.menuView?.intSelectedRow = MenuIndex.SELL_POSTS.rawValue
            appDelegate.menuView?.reloadDataForMenu()
            let vcSell = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            vcSell.currentPostType = CurrentSelectedPostType.SELL_POST.rawValue
            self.navigationController?.setViewControllers([vcSell], animated: true)
        }
        else if strRedirect == "bid" {
            let vcBid = self.storyboard?.instantiateViewController(withIdentifier: "BidsViewController") as! BidsViewController
            self.navigationController?.pushViewController(vcBid, animated: true)
        }
        else if strRedirect == "Mywallet" {
            let vcWallet = self.storyboard?.instantiateViewController(withIdentifier: "WalletViewController") as! WalletViewController
            self.navigationController?.pushViewController(vcWallet, animated: true)
        }
    }
    
    // MARK: - Webservice Call
    func callWebserviceNotification() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            self.isLoadingData = false
            dictParam["postLimit"] = String(postCount)
            
            if arrNotification.count <= 0 {
                self.showSpinner(enableInteraction: true)
            }
            
            service.callJSONMethod(methodName: "getNotification", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.isLoadingData = false
                self.tblNotifications.tableFooterView = UIView()
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        let tempArray =  dict?["data"] as! [Dictionary<String,Any>]
                        
                        
                        if self.arrNotification.count > 0 {
                            self.arrNotification.append(contentsOf: tempArray)
                        }else{
                            self.arrNotification = tempArray
                        }
                        if tempArray.count >= 10 {
                            self.isPagingAvailable = true
                        }else{
                            self.isPagingAvailable = false
                        }
                        
                        self.postCount += tempArray.count
                        
                        self.tblNotifications.reloadData()
                    }
                    else if dict?["status"] as! String == "0" {
                        self.isPagingAvailable = false
                        self.showAlert(string: dict?["message"] as! String)
                    }
                    else{
                        self.isPagingAvailable = false
                        if self.arrNotification.count <= 0 {
                            self.showAlert(string: dict?["message"] as! String)
                        }
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    // MARK: - Scrollview Scrolling Methods
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let y = scrollView.contentOffset.y + scrollView.bounds.height - scrollView.contentInset.bottom
        let height = scrollView.contentSize.height
        if y >= height {
            
            if isPagingAvailable && !isLoadingData {
                //call webservice
                
                if viewForFooter == nil {
                    viewForFooter = TableFooterView.instanceFromNib() as? TableFooterView
                    viewForFooter?.frame = CGRect (x:0, y:0, width:tblNotifications.frame.size.width, height: 50)
                }
                tblNotifications.tableFooterView = viewForFooter
                viewForFooter?.indicator.startAnimating()
                isLoadingData = true
                self.callWebserviceNotification()
            }
        }
    }
}

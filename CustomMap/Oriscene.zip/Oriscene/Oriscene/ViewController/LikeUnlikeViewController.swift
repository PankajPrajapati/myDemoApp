//
//  LikeUnlikeViewController.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 26/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

enum ENUM_REVIEW_TYPE : Int {
    case LIKE = 0, UNLIKE, VIEW, COMMENT
}

class LikeUnlikeViewController: BaseViewController, UITableViewDataSource, UITableViewDelegate {
    
    var arrUserList = [ Dictionary<String,Any>]()
    var strTitle : String?
    var dictData = Dictionary<String,Any>()
    var intType : Int = 0
    
    @IBOutlet weak var tblLikeUnlike: UITableView!
    @IBOutlet var lblTitleHeader: UILabel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tblLikeUnlike.register(LikeUnLikeUserCell.self, forCellReuseIdentifier: "self.tblLikeUnlike")
        self.tblLikeUnlike.register(UINib.init(nibName: "LikeUnLikeUserCell", bundle: nil), forCellReuseIdentifier: "LikeUnLikeUserCell")
        
        // Do any additional setup after loading the view.
        lblTitleHeader?.text = strTitle
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55.0
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if intType == ENUM_REVIEW_TYPE.LIKE.rawValue {
            let arrTmp = dictData["agr_res"]
            if arrTmp is [Dictionary<String,Any>] {
                let arr = arrTmp as! [Dictionary<String,Any>]
                return arr.count
            }
            else {
                return 0
            }
        }
        else if intType == ENUM_REVIEW_TYPE.UNLIKE.rawValue {
            let arrTmp = dictData["dis_agr_res"]
            if arrTmp is [Dictionary<String,Any>] {
                let arr = arrTmp as! [Dictionary<String,Any>]
                return arr.count
            }
            else {
                return 0
            }
        }
        else{
            let arrTmp = dictData["agr_res"]
            if arrTmp is [Dictionary<String,Any>] {
                let arr = arrTmp as! [Dictionary<String,Any>]
                return arr.count
            }
            else {
                return 0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "LikeUnLikeUserCell") as! LikeUnLikeUserCell
        
        var dict = Dictionary<String,Any>()
        var dictPostData = Dictionary<String,Any>()
        
        if intType == ENUM_REVIEW_TYPE.LIKE.rawValue {
            let arrList = dictData["agr_res"] as! [Dictionary<String,Any>]
            dict = arrList[indexPath.row]
            dictPostData = dict["post_agree_data"] as! Dictionary<String,Any>
            cell.lblUserName.text = dict["post_agree_name"] as! String?
        }
        else{
            let arrList = dictData["dis_agr_res"] as! [Dictionary<String,Any>]
            dict = arrList[indexPath.row]
            dictPostData = dict["post_disagree_data"] as! Dictionary<String,Any>
            cell.lblUserName.text = dict["post_disagree_name"] as! String?
        }
        cell.ivUser.layer.cornerRadius = cell.ivUser.frame.size.height / 2
        cell.ivUser.layer.masksToBounds = true
        
        if dictPostData.keys.contains("photo") {
            
            let strStringNameId = dictPostData["photo"]
            if strStringNameId is String {
                let strPhotoName = strStringNameId as! String
                
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictPostData["photo"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    cell.ivUser.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    cell.ivUser .image = #imageLiteral(resourceName: "default_img")
                }
            }else {
                cell.ivUser.image = #imageLiteral(resourceName: "default_img")
            }
            
        }
        else{
            cell.ivUser.image = #imageLiteral(resourceName: "default_img")
        }
        
        return cell
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

//
//  AppDelegate.swift
//  Oriscene
//
//  Created by Parth on 07/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit
import Firebase
import FirebaseMessaging
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, MenuDelegate,UIAlertViewDelegate {

    var window: UIWindow?
    var menuView : MenuView?
    var shouldRotate = false
    let gcmMessageIDKey = "gcm.message_id"
    let service = WebService()
    var alertview : UIAlertView?
    var hideAlert = false
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)
        
        //TODO: - Enter your credentials
        PayPalMobile .initializeWithClientIds(forEnvironments: [PayPalEnvironmentProduction: PATPAL_PRODUCTION_CLIENT_ID, PayPalEnvironmentSandbox: PAYPAL_SANDBOX_CLIENT_ID])
        PayPalMobile.preconnect(withEnvironment: PayPalEnvironmentSandbox)
    
        var userDefault = UserDefaults.standard.dictionaryRepresentation()
        
        //clear Filter
        UserDefaults.standard.removeObject(forKey: "filterArray")
        UserDefaults.standard.synchronize()
        
        if userDefault.keys.contains("isLogin") {
            if userDefault["isLogin"] as! String == "1" {
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                vcNav.isNavigationBarHidden = true
                
                if userDefault.keys.contains("userData") {
                    let dictUser = userDefault["userData"] as! Dictionary<String,Any>
                    let deActieStatus = dictUser["deactive_status"] as! String
                    if deActieStatus == "yes" {
                        //re direct to basicInfo screen
                        let vcBasicInfo = storyboard.instantiateViewController(withIdentifier: "BasicInformationViewController") as! BasicInformationViewController
                        vcNav.setViewControllers([vcBasicInfo], animated: true)
                        window?.rootViewController = vcNav
                    }else{
                        let vcHome = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                        vcHome.currentPostType = CurrentSelectedPostType.BOTH.rawValue
                        vcNav.setViewControllers([vcHome], animated: true)
                        window?.rootViewController = vcNav
                    }
                }else {
                    let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                    let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                    vcNav.isNavigationBarHidden = true
                    let vcLogin = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                    vcNav.setViewControllers([vcLogin], animated: true)
                    window?.rootViewController = vcNav
                }
           
            }
            else {
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                vcNav.isNavigationBarHidden = true
                let vcLogin = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                vcNav.setViewControllers([vcLogin], animated: true)
                window?.rootViewController = vcNav
            }
        }
        else{
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
            vcNav.isNavigationBarHidden = true
            let vcLogin = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            vcNav.setViewControllers([vcLogin], animated: true)
            window?.rootViewController = vcNav
        }
        
        loadMenu()
        
        if #available(iOS 10.0, *) {
            let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
            UNUserNotificationCenter.current().requestAuthorization(
                options: authOptions,
                completionHandler: {_, _ in })
            
            // For iOS 10 display notification (sent via APNS)
            UNUserNotificationCenter.current().delegate = self
            // For iOS 10 data message (sent via FCM)
            FIRMessaging.messaging().remoteMessageDelegate = self
            
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
                // Do something here
            }
            
        } else {
            let settings: UIUserNotificationSettings =
                UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings)
        }
        
        application.registerForRemoteNotifications()
        
//        NotificationCenter.default.addObserver(self, selector: #selector(tokenRefreshNotification(_:)), name:.firInstanceIDTokenRefresh , object: nil)
        
        FIRApp.configure()
        
        // Add observer for InstanceID token refresh callback.
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.tokenRefreshNotification),
                                               name: .firInstanceIDTokenRefresh,
                                               object: nil)
//        if launchOptions != nil {
//            let dict = launchOptions as Dictionary<String,Any>
//            let dictNotification = launchOptions["UIApplicationLaunchOptionsRemoteNotificationKey"]
//            self.application(application, didReceiveRemoteNotification: launchOptions!)
//        }
        
        if let dict = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] as? Dictionary<String,Any> {
            hideAlert = true
//            var dictNotification = (launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] as! String)
            self.application(application, didReceiveRemoteNotification: dict)
        }
        
        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        FIRMessaging.messaging().disconnect()
        print("Disconnected from FCM.")
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        FBSDKAppEvents.activateApp()
        connectToFcm()
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        return FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
    }
    
    func tokenRefreshNotification(_ notification: Notification) {
        if let refreshedToken = FIRInstanceID.instanceID().token() {
            UserDefaults.standard.setValue(refreshedToken, forKey: "deviceToken")
            UserDefaults.standard.synchronize()
            print("InstanceID token: \(refreshedToken)")
        }
        
        // Connect to FCM since connection may have failed when attempted before having a token.
        connectToFcm()
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        FIRInstanceID.instanceID().setAPNSToken(deviceToken as Data, type: .unknown)
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Unable to register for remote notifications: \(error.localizedDescription)")
    }
    
    func connectToFcm() {
        // Won't connect since there is no token
        guard FIRInstanceID.instanceID().token() != nil else {
            return;
        }
        
        if let refreshedToken = FIRInstanceID.instanceID().token() {
            print("InstanceID token: \(refreshedToken)")
            UserDefaults.standard.setValue(refreshedToken, forKey: "deviceToken")
            UserDefaults.standard.synchronize()
        }
        
        // Disconnect previous FCM connection if it exists.
        FIRMessaging.messaging().disconnect()
        
        FIRMessaging.messaging().connect { (error) in
            if error != nil {
                print("Unable to connect with FCM. \(error)")
            } else {
                print("Connected to FCM.")
            }
        }
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        
//        application.applicationIconBadgeNumber = 0
//        application.cancelAllLocalNotifications()
        
        let userDefault = UserDefaults.standard.dictionaryRepresentation()
        if userDefault.keys.contains("isLogin") {
            if userDefault["isLogin"] as! String != "1" {
                return
            }
        }else {
            return
        }
      //for Deactive Account :-
        if userDefault.keys.contains("userData") {
            let dictUser = userDefault["userData"] as! Dictionary<String,Any>
            let deActiveStatus = dictUser["deactive_status"] as! String
            if deActiveStatus == "yes" {
                //re direct to basicInfo screen
                    let vcNav = window?.rootViewController as! UINavigationController
                    for (_,element) in vcNav.viewControllers.enumerated(){
                        if element.isKind(of: BasicInformationViewController.self) {
                            let vcBasic = element as! BasicInformationViewController
                            vcNav.setViewControllers([vcBasic], animated: true)
                            window?.rootViewController = vcNav
                        }
                    }
                return
            }
        }
        
        if application.applicationState == .background || application.applicationState == .inactive {
            if let type = userInfo["type"] {
//                if type is Int32 {
                    let strType = type as! String
                    if strType == "1" {
                        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                        let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                        vcNav.isNavigationBarHidden = true
                        let vcFollowers = storyboard.instantiateViewController(withIdentifier: "FollowersViewController") as! FollowersViewController
                        vcNav.setViewControllers([vcFollowers], animated: true)
                        window?.rootViewController = vcNav
                        menuView?.intSelectedRow = MenuIndex.FOLLOWERS.rawValue
                        window?.rootViewController?.view.addSubview(menuView!)
                    }
                    else if strType == "2" {
                            //chat message
                            let dictData = userInfo as NSDictionary
                            let navVC  = application.windows[0].rootViewController as! UINavigationController
                            let  currentVisibleVC = navVC.visibleViewController
                            if currentVisibleVC is ChatViewController {
                                let chatVC = currentVisibleVC as! ChatViewController
                                
                                //let currentGroupId = chatVC.dictMainMessage["grp_id"] as! String
                                let newUserId = dictData["otherUserId"] as! String
                                if  chatVC.strOtherUserId == newUserId {
                                    chatVC.addNewChatMessages()
                                    return
                                }
                                else {
                                    setChatmessage(isNeedToSet : false)//another group msg so need to reload that messages
                                }
                            }
                            else if currentVisibleVC is MessagesViewController {
                                let messageVC = currentVisibleVC as! MessagesViewController
                                messageVC.isFromAppdelegate = true
                                messageVC.callWebserviceGetMessages()
                                return
                            }
                            else {
                                // in some other ViewController
//                                let title = dictData["title"] as! String
//                                let message = dictData["text"] as! String
//                                if alertview != nil {
//                                    self.alertview?.dismiss(withClickedButtonIndex: 0, animated: false)
//                                }
//                                
//                                alertview = UIAlertView (title: title, message: message, delegate: self, cancelButtonTitle: "Close", otherButtonTitles: "Open")
//                                alertview?.show()

                                if hideAlert {
                                    hideAlert = false
                                    self.setChatmessage(isNeedToSet: true)
                                }else {
                                    let title = dictData["title"] as! String
                                    let message = dictData["text"] as! String
                                    if alertview != nil {
                                        self.alertview?.dismiss(withClickedButtonIndex: 0, animated: false)
                                    }
                                    
                                    alertview = UIAlertView (title: title, message: message, delegate: self, cancelButtonTitle: "Close", otherButtonTitles: "Open")
                                    alertview?.tag = 2
                                    alertview?.show()
                                    
                                }
                            }
                        
                    }else if strType == "3" {
                        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                        let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                        vcNav.isNavigationBarHidden = true
                        let vcNotifications = storyboard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
                        vcNav.setViewControllers([vcNotifications], animated: true)
                        window?.rootViewController = vcNav
                        menuView?.intSelectedRow = MenuIndex.NOTIFICATION.rawValue
                        window?.rootViewController?.view.addSubview(menuView!)
                    }
                    else if strType == "4" {
                        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                        let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                        vcNav.isNavigationBarHidden = true
                        let vcNotifications = storyboard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
                        let vcBid = storyboard.instantiateViewController(withIdentifier: "BidsViewController") as! BidsViewController
                        vcNav.setViewControllers([vcNotifications,vcBid], animated: true)
                        window?.rootViewController = vcNav
                        menuView?.intSelectedRow = MenuIndex.NOTIFICATION.rawValue
                        window?.rootViewController?.view.addSubview(menuView!)
                    }
                    else if strType == "5" {
                        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                        let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                        vcNav.isNavigationBarHidden = true
                        let vcNotifications = storyboard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
                        let vcBid = storyboard.instantiateViewController(withIdentifier: "BidsViewController") as! BidsViewController
                        vcNav.setViewControllers([vcNotifications,vcBid], animated: true)
                        window?.rootViewController = vcNav
                        menuView?.intSelectedRow = MenuIndex.NOTIFICATION.rawValue
                        window?.rootViewController?.view.addSubview(menuView!)
                    }
                
//                }
            }
        }
        else {
            if let type = userInfo["type"] {
                //                if type is Int32 {
                let strType = type as! String
                if strType == "1" {
                    
                    let dictData = userInfo as NSDictionary
                    let navVC  = application.windows[0].rootViewController as! UINavigationController
                    let  currentVisibleVC = navVC.visibleViewController
                    if currentVisibleVC is FollowersViewController {
                        let FollowVC = currentVisibleVC as! FollowersViewController
//                        messageVC.isFromAppdelegate = true
                        FollowVC.callWebserviceForFollowers()
                        return
                    }
                    else {
                        
//                        if hideAlert {
//                            hideAlert = false
//                            self.setChatmessage(isNeedToSet: true)
//                        }else {
                            let title = dictData["title"] as! String
                            let message = dictData["text"] as! String
                            if alertview != nil {
                                self.alertview?.dismiss(withClickedButtonIndex: 0, animated: false)
                            }
                            
                            alertview = UIAlertView (title: title, message: message, delegate: self, cancelButtonTitle: "Close", otherButtonTitles: "Open")
                            alertview?.tag = 1
                            alertview?.show()
                            
//                        }
                    }
                    
                    /*
                    let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                    let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                    vcNav.isNavigationBarHidden = true
                    let vcFollowers = storyboard.instantiateViewController(withIdentifier: "FollowersViewController") as! FollowersViewController
                    vcNav.setViewControllers([vcFollowers], animated: true)
                    window?.rootViewController = vcNav
                    menuView?.intSelectedRow = MenuIndex.FOLLOWERS.rawValue
                    window?.rootViewController?.view.addSubview(menuView!)*/
                }
                else if strType == "2" {
                    //chat message
                    let dictData = userInfo as NSDictionary
                    let navVC  = application.windows[0].rootViewController as! UINavigationController
                    let  currentVisibleVC = navVC.visibleViewController
                    if currentVisibleVC is ChatViewController {
                        let chatVC = currentVisibleVC as! ChatViewController
                        
                        //let currentGroupId = chatVC.dictMainMessage["grp_id"] as! String
                        let newUserId = dictData["otherUserId"] as! String
                        if  chatVC.strOtherUserId == newUserId {
                            chatVC.addNewChatMessages()
                            return
                        }
                        else {
                            setChatmessage(isNeedToSet : false)//another group msg so need to reload that messages
                        }
                    }
                    else if currentVisibleVC is MessagesViewController {
                        let messageVC = currentVisibleVC as! MessagesViewController
                        messageVC.isFromAppdelegate = true
                        messageVC.callWebserviceGetMessages()
                        return
                    }
                    else {
                        // in some other ViewController
                        if hideAlert {
                            hideAlert = false
                            self.setChatmessage(isNeedToSet: true)
                        }else {
                            let title = dictData["title"] as! String
                            let message = dictData["text"] as! String
                            if alertview != nil {
                                self.alertview?.dismiss(withClickedButtonIndex: 0, animated: false)
                            }
                            
                            alertview = UIAlertView (title: title, message: message, delegate: self, cancelButtonTitle: "Close", otherButtonTitles: "Open")
                            alertview?.tag = 2
                            alertview?.show()
                        }
                    }
                }else if strType == "3" {
                    
                    let dictData = userInfo as NSDictionary
                    let navVC  = application.windows[0].rootViewController as! UINavigationController
                    let  currentVisibleVC = navVC.visibleViewController
                    if currentVisibleVC is NotificationsViewController {
                        let NotVC = currentVisibleVC as! NotificationsViewController
                        //                        messageVC.isFromAppdelegate = true
                        NotVC.postCount = 0
                        NotVC.isLoadingData = false
                        NotVC.isPagingAvailable = true
                        NotVC.callWebserviceNotification()
                        return
                    }
                    else {
                        
//                        if hideAlert {
//                            hideAlert = false
//                            self.setChatmessage(isNeedToSet: true)
//                        }else {
                            let title = dictData["title"] as! String
                            let message = dictData["text"] as! String
                            if alertview != nil {
                                self.alertview?.dismiss(withClickedButtonIndex: 0, animated: false)
                            }
                            
                            alertview = UIAlertView (title: title, message: message, delegate: self, cancelButtonTitle: "Close", otherButtonTitles: "Open")
                            alertview?.tag = 3
                            alertview?.show()
                            
//                        }
                    }
                    /*
                    let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                    let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                    vcNav.isNavigationBarHidden = true
                    let vcNotifications = storyboard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
                    vcNav.setViewControllers([vcNotifications], animated: true)
                    window?.rootViewController = vcNav
                    menuView?.intSelectedRow = MenuIndex.NOTIFICATION.rawValue
                    window?.rootViewController?.view.addSubview(menuView!)
                    */
                }
                else if strType == "4" {
                    let dictData = userInfo as NSDictionary
                    let navVC  = application.windows[0].rootViewController as! UINavigationController
                    let  currentVisibleVC = navVC.visibleViewController
                    if currentVisibleVC is BidsViewController {
//                        let bidVC = currentVisibleVC as! BidsViewController
                        //                        messageVC.isFromAppdelegate = true
                        
                        return
                    }
                    else {
                        
                        //                        if hideAlert {
                        //                            hideAlert = false
                        //                            self.setChatmessage(isNeedToSet: true)
                        //                        }else {
                        let title = dictData["title"] as! String
                        let message = dictData["text"] as! String
                        if alertview != nil {
                            self.alertview?.dismiss(withClickedButtonIndex: 0, animated: false)
                        }
                        
                        alertview = UIAlertView (title: title, message: message, delegate: self, cancelButtonTitle: "Close", otherButtonTitles: "Open")
                        alertview?.tag = 4
                        alertview?.show()
                        
                        //                        }
                    }
                }
                else if strType == "5" {
                    let dictData = userInfo as NSDictionary
                    let navVC  = application.windows[0].rootViewController as! UINavigationController
                    let  currentVisibleVC = navVC.visibleViewController
                    if currentVisibleVC is WalletViewController {
                        //                        let bidVC = currentVisibleVC as! BidsViewController
                        //                        messageVC.isFromAppdelegate = true
                        
                        return
                    }
                    else {
                        
                        //                        if hideAlert {
                        //                            hideAlert = false
                        //                            self.setChatmessage(isNeedToSet: true)
                        //                        }else {
                        let title = dictData["title"] as! String
                        let message = dictData["text"] as! String
                        if alertview != nil {
                            self.alertview?.dismiss(withClickedButtonIndex: 0, animated: false)
                        }
                        
                        alertview = UIAlertView (title: title, message: message, delegate: self, cancelButtonTitle: "Close", otherButtonTitles: "Open")
                        alertview?.tag = 5
                        alertview?.show()
                        
                        //                        }
                    }
                }
            }
        }
        print(userInfo)
    }
    
    public func loadMenu () {
        menuView = MenuView.instanceFromNib() as? MenuView
        menuView?.delegate = self
        menuView?.frame = (self.window?.frame)!
        menuView?.intSelectedRow = 0
        menuView?.frame.origin.x = -(self.window?.frame.size.width)!
        window?.rootViewController?.view.addSubview(menuView!)
    }
    
    public func showMenu () {
//        self.menuView?.RefreshUserDetail()
        self.menuView?.backgroundColor = UIColor.clear
        UIView .animate(withDuration: 0.5, animations: { 
            self.menuView?.frame.origin.x = 0.0;
        }) { (Bool) in
                
            UIView .animate(withDuration: 1.0) {
                self.menuView?.backgroundColor = UIColor (colorLiteralRed: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 0.3)
            }
        }
    }
    
    public func hideMenu () {
        self.menuView?.backgroundColor = UIColor.clear
        UIView .animate(withDuration: 0.5) {
            self.menuView?.frame.origin.x = -(self.window?.frame.size.width)!;
        }
    }
    
    func hideMenuClicked() {
        self.hideMenu()
    }
    
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        if shouldRotate {
            return .allButUpsideDown
        }
        else {
            return .portrait
        }
    }
    // MARK: - Alertview Delegate Method
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        if alertview?.tag == 1 {
            if buttonIndex == 1 {
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                vcNav.isNavigationBarHidden = true
                let vcFollowers = storyboard.instantiateViewController(withIdentifier: "FollowersViewController") as! FollowersViewController
                vcNav.setViewControllers([vcFollowers], animated: true)
                window?.rootViewController = vcNav
                menuView?.intSelectedRow = MenuIndex.FOLLOWERS.rawValue
                window?.rootViewController?.view.addSubview(menuView!)
            }
        }
        else if alertview?.tag == 2 {
            if buttonIndex == 1 {
                self.setChatmessage(isNeedToSet: true)
            }
        }
        else if alertview?.tag == 3 {
            if buttonIndex == 1 {
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                vcNav.isNavigationBarHidden = true
                let vcNotifications = storyboard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
                vcNav.setViewControllers([vcNotifications], animated: true)
                window?.rootViewController = vcNav
                menuView?.intSelectedRow = MenuIndex.NOTIFICATION.rawValue
                window?.rootViewController?.view.addSubview(menuView!)
            }
        }
        else if alertview?.tag == 4 {
            if buttonIndex == 1 {
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                vcNav.isNavigationBarHidden = true
                let vcNotifications = storyboard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
                let vcBid = storyboard.instantiateViewController(withIdentifier: "BidsViewController") as! BidsViewController
                vcNav.setViewControllers([vcNotifications,vcBid], animated: true)
                window?.rootViewController = vcNav
                menuView?.intSelectedRow = MenuIndex.NOTIFICATION.rawValue
                window?.rootViewController?.view.addSubview(menuView!)
            }
        }
        else if alertview?.tag == 5 {
            if buttonIndex == 1 {
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let vcNav = storyboard.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                vcNav.isNavigationBarHidden = true
                let vcNotifications = storyboard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
                let vcWallet = storyboard.instantiateViewController(withIdentifier: "WalletViewController") as! WalletViewController
                vcNav.setViewControllers([vcNotifications,vcWallet], animated: true)
                window?.rootViewController = vcNav
                menuView?.intSelectedRow = MenuIndex.NOTIFICATION.rawValue
                window?.rootViewController?.view.addSubview(menuView!)
            }
        }
    }
    
    // MARK: - setChatmessage Method
    func setChatmessage(isNeedToSet : Bool)-> Void  {
        let navVC  = window?.rootViewController as! UINavigationController
        for (_, element) in (navVC.viewControllers.enumerated()){
            if element.isKind(of: MessagesViewController.self) {
                let vc = element as! MessagesViewController
                vc.isFromAppdelegate = true
                vc.callWebserviceGetMessages()
                if isNeedToSet {
                    menuView?.intSelectedRow = MenuIndex.MESSAGES.rawValue
                    menuView?.reloadDataForMenu()
                    navVC.popToViewController(vc, animated: true)
                }
                return
            }
        }
        
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vcMessage = storyboard.instantiateViewController(withIdentifier: "MessagesViewController") as! MessagesViewController
        if isNeedToSet {
            menuView?.intSelectedRow = MenuIndex.MESSAGES.rawValue
            menuView?.reloadDataForMenu()
            navVC.setViewControllers([vcMessage], animated: true)
        }else{
            vcMessage.callWebserviceGetMessages()
        }
        
    }
    
    // MARK: - Webservice Method
    
    func callWebserviceSetDeviceToken() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
//            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
//            dictParam["userId"] = dictUser["reporter_id"] as? String
            if userDefault.keys.contains("deviceToken") {
                dictParam["deviceToken"] = userDefault["deviceToken"]
            }
            
            let strDeviceId = UIDevice.current.identifierForVendor!.uuidString
            dictParam["deviceId"] = strDeviceId
            dictParam["deviceType"] = "0"
            
            service.callJSONMethod(methodName: "setDeviceToken", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{

                    }
                    else{
 
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func showNoNetworkAlert() -> Void {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Please check internet connection." , delegate: nil, cancelButtonTitle: "OK")
        alertWarning.show()
    }
    
    // MARK: - Recability Method
    func isConnectedToNetwork() -> Bool {
        
        if (currentReachabilityStatus == ReachabilityStatus.reachableViaWiFi)
        {
            return true
        }
        else if (currentReachabilityStatus == ReachabilityStatus.reachableViaWWAN)
        {
            return true
        }
        else
        {
            return false
        }
    }
}

@available(iOS 10, *)
extension AppDelegate : UNUserNotificationCenterDelegate {
    
    // Receive displayed notifications for iOS 10 devices.
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let userInfo = notification.request.content.userInfo
        // Print message ID.
        if let messageID = userInfo[gcmMessageIDKey] {
            print("Message ID: \(messageID)")
        }
        
        // Print full message.
        print(userInfo)
        

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let application = UIApplication.shared as UIApplication
        appDelegate.application(application, didReceiveRemoteNotification: userInfo)
        completionHandler([])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        // Print message ID.
        if let messageID = userInfo[gcmMessageIDKey] {
            print("Message ID: \(messageID)")
        }
        
        // Print full message.
        print(userInfo)
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let application = UIApplication.shared as UIApplication
        appDelegate.application(application, didReceiveRemoteNotification: userInfo)
        completionHandler()
    }
    
}

// [END ios_10_message_handling]
// [START ios_10_data_message_handling]
extension AppDelegate : FIRMessagingDelegate {
    // Receive data message on iOS 10 devices while app is in the foreground.
    func applicationReceivedRemoteMessage(_ remoteMessage: FIRMessagingRemoteMessage) {
        print(remoteMessage.appData)
    }
}
// [END ios_10_data_message_handling]


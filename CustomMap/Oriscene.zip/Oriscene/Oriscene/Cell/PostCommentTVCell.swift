//
//  PostCommentTVCell.swift
//  Oriscene
//
//  Created by Parth on 11/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol PostCommentDelegate {
    func btnCommentReplyClicked(index : NSInteger) -> Void
    func btnSubmitReplyClicked(index : NSInteger) -> Void
}

class PostCommentTVCell: UITableViewCell {

    var delegate : PostCommentDelegate?
    var index : NSInteger = -1
    
    @IBOutlet var imgUserProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblComment: UILabel!
    @IBOutlet var lblTime: UILabel!
    @IBOutlet var btnReply: UIButton!
    @IBOutlet var viewReplyContainer: UIView!
    @IBOutlet var btnSubmitReply: UIButton!
    @IBOutlet var txtViewReply: UITextView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layoutIfNeeded()
        imgUserProfilePic.layer.cornerRadius = imgUserProfilePic.frame.size.height/2
        imgUserProfilePic.layer.masksToBounds = true
        
        btnSubmitReply.layer.cornerRadius = btnSubmitReply.frame.size.height/2
        btnSubmitReply.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnReplyAction(_ sender: AnyObject) {
        delegate?.btnCommentReplyClicked(index: index)
    }
    @IBAction func btnSubmitReplyAction(_ sender: AnyObject) {
        delegate?.btnSubmitReplyClicked(index: index)
    }
    
}

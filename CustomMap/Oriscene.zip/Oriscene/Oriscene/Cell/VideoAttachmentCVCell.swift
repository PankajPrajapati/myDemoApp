//
//  VideoAttachmentCVCell.swift
//  Oriscene
//
//  Created by Parth on 18/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol AttachmentVideoCreatePostDelegate {
    func removeAttachment(index : NSInteger) -> Void
}

class VideoAttachmentCVCell: UICollectionViewCell {

    var index : NSInteger = -1
    var delegate : AttachmentVideoCreatePostDelegate?
    
    @IBOutlet var imgAttachedVideo: UIImageView!
    @IBOutlet var btnRemoveVideo: UIButton!
    @IBOutlet var lblVideoName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layoutIfNeeded()
//        imgAttachedVideo.layer.cornerRadius = imgAttachedVideo.frame.size.height / 2.0
//        imgAttachedVideo.layer.masksToBounds = true
        
        btnRemoveVideo.layer.cornerRadius = btnRemoveVideo.frame.size.height / 2.0
        btnRemoveVideo.layer.masksToBounds = true
    }
    @IBAction func btnRemoveVideoAction(_ sender: Any) {
        delegate?.removeAttachment(index: index)
    }

}

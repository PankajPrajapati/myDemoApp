//
//  PostActionCVCell.swift
//  Oriscene
//
//  Created by Parth on 10/12/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class PostActionCVCell: UICollectionViewCell {

    var index : NSInteger = -1
    
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var imgAction: UIImageView!
    @IBOutlet var lblAction: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        viewContainer.layer.cornerRadius = 12.0
        viewContainer.layer.masksToBounds = true
        viewContainer.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        viewContainer.layer.borderWidth = 1.0
    }
}

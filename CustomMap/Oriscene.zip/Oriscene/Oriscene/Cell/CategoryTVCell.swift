//
//  CategoryTVCell.swift
//  Oriscene
//
//  Created by Parth on 29/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol CategoryDelegate {
    func btnSelectSubCategoryClicked(index: NSInteger) -> Void
}

class CategoryTVCell: UITableViewCell {

    var index : NSInteger = -1
    var delegate : CategoryDelegate?
    
    @IBOutlet var lblCategoryTitle: UILabel!
    @IBOutlet var btnSelect: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnSelectCategoryAction(_ sender: Any) {
        delegate?.btnSelectSubCategoryClicked(index: index)
    }
    
}

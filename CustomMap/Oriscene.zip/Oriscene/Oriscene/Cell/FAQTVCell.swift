//
//  FAQTVCell.swift
//  Oriscene
//
//  Created by Parth on 14/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol FAQDelegate {
    func btnTitleActionClicked(index : NSInteger ) -> Void
}

class FAQTVCell: UITableViewCell, TTTAttributedLabelDelegate {

    var delegate : FAQDelegate?
    var index : NSInteger = -1
    
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var viewTitleContainer: UIView!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var btnTitle: UIButton!
    @IBOutlet var lblDescription: TTTAttributedLabel!
    @IBOutlet var viewColorMark: UIView!
    @IBOutlet var viewColorMarkContainer: UIView!
    
    @IBOutlet var heightConstViewTitleContainer: NSLayoutConstraint!
    
    @IBOutlet var topSpaceConstLblDesc: NSLayoutConstraint!
    @IBOutlet var bottomSpaceConstLblDesc: NSLayoutConstraint!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layoutIfNeeded()
        viewTitleContainer.layer.shadowColor = UIColor.lightGray.cgColor
        viewTitleContainer.layer.shadowOpacity = 0.5
        viewTitleContainer.layer.shadowOffset = CGSize.zero
        viewTitleContainer.layer.shadowRadius = 3.0
        viewTitleContainer.layer.cornerRadius = 3.0
        
        viewContainer.layer.shadowColor = UIColor.lightGray.cgColor
        viewContainer.layer.shadowOpacity = 0.5
        viewContainer.layer.shadowOffset = CGSize.zero
        viewContainer.layer.shadowRadius = 3.0
        viewContainer.layer.cornerRadius = 3.0
        
        viewColorMarkContainer.layer.cornerRadius = 3.0
        viewColorMarkContainer.layer.masksToBounds = true
        
        self.lblDescription.delegate = self
        
        
        
    }
    
    func setLink() {
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnTitleAction(_ sender: AnyObject) {
        delegate?.btnTitleActionClicked(index: index)
    }
    
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith url: URL!) {
        print(url)
    }
    
}

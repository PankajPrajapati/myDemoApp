//
//  BidTypeOptionTVCell.swift
//  Oriscene
//
//  Created by Parth on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class BidTypeOptionTVCell: UITableViewCell {

    var index : NSInteger = -1
    @IBOutlet var lblBidTypeOptionTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

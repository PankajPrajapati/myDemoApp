//
//  MyWalletTVCell.swift
//  Oriscene
//
//  Created by TriState  on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class MyWalletTVCell: UITableViewCell {

   
    @IBOutlet var lblKeyData: UILabel!
    @IBOutlet var lblValueData: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

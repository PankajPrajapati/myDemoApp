//
//  ZoomImageCell.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 05/01/17.
//  Copyright © 2017 Tristate. All rights reserved.
//

import UIKit

class ZoomImageCell: UICollectionViewCell, UIScrollViewDelegate{
   
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet var imgPostImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.layoutIfNeeded()
    }
//    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
//        return self.imgPostImage
//    }
    
    func setupScrollview() {
        self.layoutIfNeeded()
        self.updateConstraints()
//        self.scrollView = UIScrollView()
        self.scrollView.frame = UIScreen.main.bounds //UIScrollView(frame: UIScreen.main.bounds)
        self.scrollView.backgroundColor = UIColor.clear
        self.scrollView.delegate = self
        self.addSubview(self.scrollView)
        scrollView.contentSize = imgPostImage.frame.size
        let scrollViewFrame = self.scrollView.frame
        let scaleWidth: CGFloat = scrollViewFrame.size.width / self.scrollView.contentSize.width
        let scaleHeight: CGFloat = scrollViewFrame.size.height / self.scrollView.contentSize.height
        let minScale: CGFloat = min(scaleWidth, scaleHeight)
        self.scrollView.minimumZoomScale = minScale
        self.scrollView.maximumZoomScale = 4.0
        self.scrollView.zoomScale = minScale
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(self.handleDoubleTap))
        doubleTap.numberOfTapsRequired = 2
        self.imgPostImage.addGestureRecognizer(doubleTap)
    }
    
    func centerScrollViewContents() {
        // This method centers the scroll view contents also used on did zoom
        let boundsSize = self.scrollView.bounds.size
        var contentsFrame = self.imgPostImage.frame
        if contentsFrame.size.width < boundsSize.width {
            contentsFrame.origin.x = (boundsSize.width - contentsFrame.size.width) / 2.0
        }
        else {
            contentsFrame.origin.x = 0.0
        }
        if contentsFrame.size.height < boundsSize.height {
            contentsFrame.origin.y = (boundsSize.height - contentsFrame.size.height) / 2.0
        }
        else {
            contentsFrame.origin.y = 0.0
        }
        self.imgPostImage.frame = contentsFrame
    }
    
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        self.centerScrollViewContents()
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imgPostImage
    }
    
    func handleDoubleTap(_ gestureRecognizer: UIPinchGestureRecognizer) {
        //handle pinch...
        let imageView = (gestureRecognizer.view as! UIImageView)
        if imageView != nil {
            if self.scrollView.zoomScale > self.scrollView.minimumZoomScale {
                self.scrollView.setZoomScale(self.scrollView.minimumZoomScale, animated: true)
            }
            else {
                let touch = gestureRecognizer.location(in: gestureRecognizer.view)
                let scrollViewSize = self.bounds.size
                let w: CGFloat = scrollViewSize.width / self.scrollView.maximumZoomScale
                let h: CGFloat = scrollViewSize.height / self.scrollView.maximumZoomScale
                let x: CGFloat = touch.x - (w / 2.0)
                let y: CGFloat = touch.y - (h / 2.0)
                let rectTozoom = CGRect(x: x, y: y, width: w, height: h)
                self.scrollView.zoom(to: rectTozoom, animated: true)
            }
        }
    }
}

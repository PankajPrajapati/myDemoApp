//
//  ReviewTblCell.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 26/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit
protocol ReviewDelegate {
    func btnLikeClickedAction(indexOfRow: NSInteger) -> Void
    func btnUnLikeClickedAction(indexOfRow: NSInteger) -> Void
    func btnViewsClickedAction(indexOfRow: NSInteger) -> Void
    func btnCommentClickedAction(indexOfRow: NSInteger) -> Void
}

class ReviewTblCell: UITableViewCell {
    
    @IBOutlet weak var lblReview: UILabel!
    @IBOutlet var viewContainer: UIView!
    @IBOutlet weak var btnUnlike: UIButton!
    
    @IBOutlet weak var btnComments: UIButton!
    @IBOutlet weak var btnViews: UIButton!
    @IBOutlet weak var btnLike: UIButton!
    var delegate : ReviewDelegate?
    var index : NSInteger = -1
    
    @IBOutlet var imgViewContainerShadow: UIImageView!
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
//        viewContainer.layer.cornerRadius = 5.0
//        viewContainer.layer.masksToBounds = true
//        viewContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
//        viewContainer.layer.borderWidth = 1.0
//        
//        viewContainer.layer.shadowColor = UIColor.black.cgColor
//        viewContainer.layer.shadowOpacity = 1.0
//        viewContainer.layer.shadowOffset = CGSize.zero
//        viewContainer.layer.shadowRadius = 5
        
//        imgViewContainerShadow.layer.shadowColor = UIColor.black.cgColor
//        imgViewContainerShadow.layer.shadowOpacity = 1.0
//        imgViewContainerShadow.layer.shadowOffset = CGSize.zero
//        imgViewContainerShadow.layer.shadowRadius = 5
//        
//        imgViewContainerShadow.backgroundColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.1)
        
        viewContainer.layer.cornerRadius = 3.0
        //        viewContainer.layer.masksToBounds = true
        viewContainer.layer.borderColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.5).cgColor
        viewContainer.layer.borderWidth = 1.0
        
        viewContainer.layer.shadowColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewContainer.layer.shadowOpacity = 1.0
        viewContainer.layer.shadowOffset = CGSize.zero
        viewContainer.layer.shadowRadius = 5.0
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
  
    @IBAction func btnLikeAction(_ sender: Any) {
        delegate?.btnLikeClickedAction(indexOfRow: index)
    }
    
    @IBAction func btnUnlikeAction(_ sender: Any) {
        delegate?.btnUnLikeClickedAction(indexOfRow: index)
    }
   
    @IBAction func btnViewAction(_ sender: Any) {
         delegate?.btnViewsClickedAction(indexOfRow: index)
    }
    
    @IBAction func btnComments(_ sender: Any) {
         delegate?.btnCommentClickedAction(indexOfRow: index)
    }
}

//
//  LocationSearchTVCell.swift
//  Oriscene
//
//  Created by Parth on 20/12/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class LocationSearchTVCell: UITableViewCell {

    @IBOutlet var lblLocationTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

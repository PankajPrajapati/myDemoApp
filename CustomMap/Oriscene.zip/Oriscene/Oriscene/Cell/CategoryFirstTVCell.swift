//
//  CategoryFirstTVCell.swift
//  Oriscene
//
//  Created by Parth on 09/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class CategoryFirstTVCell: UITableViewCell {

    @IBOutlet var btnCategorySelect: UIButton!
    @IBOutlet var imgCategory: UIImageView!
    @IBOutlet var lblCategory: UILabel!
    
    var index: NSInteger = -1
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

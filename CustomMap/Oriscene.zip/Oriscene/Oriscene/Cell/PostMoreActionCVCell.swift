//
//  PostMoreActionCVCell.swift
//  Oriscene
//
//  Created by Tristate on 19/01/17.
//  Copyright © 2017 Tristate. All rights reserved.
//

import UIKit

class PostMoreActionCVCell: UICollectionViewCell {

    @IBOutlet weak var imgAction: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

//
//  LikeUnLikeUserCell.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 28/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class LikeUnLikeUserCell: UITableViewCell {

    @IBOutlet weak var ivUser: UIImageView!
    
    @IBOutlet weak var lblUserName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

//
//  NotificationListTVCell.swift
//  Oriscene
//
//  Created by Parth on 12/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class NotificationListTVCell: UITableViewCell {

    var index : NSInteger = -1
    @IBOutlet var lblUnreadStatus: UILabel!
    @IBOutlet var imgProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblTime: UILabel!
    @IBOutlet var lblNotificationMsg: UILabel!
    @IBOutlet var viewContainer: UIView!
    
    @IBOutlet var widthConstLblUnreadStatus: NSLayoutConstraint!
    @IBOutlet var imgViewContainerShadow: UIImageView!
    @IBOutlet var leadingConstProfilePic: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.layoutIfNeeded()
        viewContainer.layer.cornerRadius = 5.0
//        viewContainer.layer.masksToBounds = true
        viewContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewContainer.layer.borderWidth = 1.0
        
        viewContainer.layer.shadowColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewContainer.layer.shadowOpacity = 1.0
        viewContainer.layer.shadowOffset = CGSize.zero
        viewContainer.layer.shadowRadius = 2
        
        imgProfilePic.layer.cornerRadius = imgProfilePic.frame.size.height / 2.0
        imgProfilePic.layer.masksToBounds = true
        
        lblUnreadStatus.layer.cornerRadius = lblUnreadStatus.frame.size.height / 2.0
        lblUnreadStatus.layer.masksToBounds = true
        
//        imgViewContainerShadow.layer.shadowColor = UIColor.black.cgColor
//        imgViewContainerShadow.layer.shadowOpacity = 1.0
//        imgViewContainerShadow.layer.shadowOffset = CGSize.zero
//        imgViewContainerShadow.layer.shadowRadius = 5
//        
//        imgViewContainerShadow.backgroundColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.1)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

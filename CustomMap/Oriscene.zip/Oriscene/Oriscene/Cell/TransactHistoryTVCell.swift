//
//  TransactHistoryTVCell.swift
//  Oriscene
//
//  Created by TriState  on 24/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class TransactHistoryTVCell: UITableViewCell {

    @IBOutlet var viewContainer: UIView!
    @IBOutlet var lblOrderNumber: UILabel!
    @IBOutlet var lblOrderDate: UILabel!
    @IBOutlet var lblBuyerName: UILabel!
    @IBOutlet var lblPrice: UILabel!
    @IBOutlet var lblStatus: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.layoutIfNeeded()
        viewContainer.layer.cornerRadius = 3.0
        //        viewContainer.layer.masksToBounds = true
        viewContainer.layer.borderColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.5).cgColor
        viewContainer.layer.borderWidth = 1.0
        
        //viewContainer.layer.shadowColor = UIColor.lightGray.cgColor
        viewContainer.layer.shadowColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.5).cgColor
        viewContainer.layer.shadowOpacity = 1.0
        viewContainer.layer.shadowOffset = CGSize.zero
        viewContainer.layer.shadowRadius = 7.0

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

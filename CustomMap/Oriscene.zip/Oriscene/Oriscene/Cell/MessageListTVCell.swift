//
//  MessageListTVCell.swift
//  Oriscene
//
//  Created by Parth on 12/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class MessageListTVCell: UITableViewCell {

    var index : NSInteger = -1
    
    @IBOutlet var imgUserProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblMessage: UILabel!
    @IBOutlet var lblTime: UILabel!
    @IBOutlet var imgClock: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layoutIfNeeded()
        imgUserProfilePic.layer.cornerRadius = imgUserProfilePic.frame.size.height/2
        imgUserProfilePic.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

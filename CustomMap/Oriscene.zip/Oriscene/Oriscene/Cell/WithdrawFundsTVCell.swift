//
//  WithdrawFundsTVCell.swift
//  Oriscene
//
//  Created by TriState  on 29/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol WithdrawFundsTVCellDelegate {
   func btnWithdrawFundsAction(index : NSInteger) -> Void
}


class WithdrawFundsTVCell: UITableViewCell {

    var delegate : WithdrawFundsTVCellDelegate?
     var index : NSInteger = -1
    @IBOutlet var lblHeadertext: UILabel!
    @IBOutlet var btnWithdrawFundsOption: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
        
        btnWithdrawFundsOption.layer.cornerRadius = 3.0
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnWithdrawFundsAction(_ sender: Any) {
//        btnWithdrawFundsOption.isSelected = !btnWithdrawFundsOption.isSelected
        delegate?.btnWithdrawFundsAction(index: index)
    }
}

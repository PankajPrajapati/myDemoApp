//
//  ProfileCell.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class ProfileCell: UICollectionViewCell {

    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var imgUser: UIImageView!
    
    @IBOutlet var lblCount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

//
//  ReviewCvCell.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 26/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class ReviewCvCell: UICollectionViewCell, UITableViewDelegate, UITableViewDataSource, ReviewDelegate {

    @IBOutlet weak var tblReview: UITableView!
    var arrReview = [ Dictionary<String,Any>]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.tblReview.register(ReviewTblCell.self, forCellReuseIdentifier: "self.tblReview")
        self.tblReview.register(UINib.init(nibName: "ReviewTblCell", bundle: nil), forCellReuseIdentifier: "ReviewTblCell")
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrReview.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "ReviewTblCell") as! ReviewTblCell
        cell.delegate = self
        cell.index = indexPath.row
        let dict = arrReview[indexPath.row]
        cell.lblReview.text = dict["post_content"] as! String?

        if (Int(dict["agree_count"] as! String)! > 1 ) {
            cell.btnLike.setTitle((dict["agree_count"] as! String?)! + " Likes",for: .normal)
        }
        else{
            cell.btnLike.setTitle((dict["agree_count"] as! String?)! + " Like",for: .normal)
        }
        
        if (Int(dict["disagree_count"] as! String)! > 1 ) {
            cell.btnUnlike.setTitle((dict["disagree_count"] as! String?)! + " Unlikes",for: .normal)
        }
        else{
            cell.btnUnlike.setTitle((dict["disagree_count"] as! String?)! + " Unlike",for: .normal)
        }
        
        if (Int(dict["view_count"] as! String)! > 1 ) {
            cell.btnViews.setTitle((dict["view_count"] as! String?)! + " Views",for: .normal)
        }
        else{
            cell.btnViews.setTitle((dict["view_count"] as! String?)! + " View",for: .normal)
        }
        
        if (Int(dict["post_comment_count"] as! String)! > 1 ) {
            cell.btnComments.setTitle((dict["post_comment_count"] as! String?)! + " Comments",for: .normal)
        }
        else{
            cell.btnComments.setTitle((dict["post_comment_count"] as! String?)! + " Comment",for: .normal)
        }
        
        cell.btnLike.tag = indexPath.row
        return cell
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }
    
    func btnLikeClickedAction(indexOfRow: NSInteger) {
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let navVC =  appDelegate.window?.rootViewController as! UINavigationController
        
        let vcLikeUnlike = storyBoard.instantiateViewController(withIdentifier: "LikeUnlikeViewController") as! LikeUnlikeViewController
        vcLikeUnlike.lblTitleHeader?.text = "People who liked"
        vcLikeUnlike.strTitle = "People who liked"
        vcLikeUnlike.dictData = arrReview[indexOfRow]
        vcLikeUnlike.intType = 0
        navVC.pushViewController(vcLikeUnlike, animated: true)
    }
    
    func btnUnLikeClickedAction(indexOfRow: NSInteger) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let navVC =  appDelegate.window?.rootViewController as! UINavigationController
        
        let vcLikeUnlike = storyBoard.instantiateViewController(withIdentifier: "LikeUnlikeViewController") as! LikeUnlikeViewController
        vcLikeUnlike.lblTitleHeader?.text = "People who unliked"
        vcLikeUnlike.strTitle = "People who unliked"
        vcLikeUnlike.dictData = arrReview[indexOfRow]
        vcLikeUnlike.intType = 1
        navVC.pushViewController(vcLikeUnlike, animated: true)
    }
    func btnViewsClickedAction(indexOfRow: NSInteger) {
        /*
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let navVC =  appDelegate.window?.rootViewController as! UINavigationController
        
        let vcLikeUnlike = storyBoard.instantiateViewController(withIdentifier: "LikeUnlikeViewController") as! LikeUnlikeViewController
        vcLikeUnlike.lblTitleHeader?.text = "People who viewed"
        vcLikeUnlike.strTitle = "People who viewed"
        vcLikeUnlike.dictData = arrReview[indexOfRow]
        navVC.pushViewController(vcLikeUnlike, animated: true)
         */
    }
    func btnCommentClickedAction(indexOfRow: NSInteger) {
        /*
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let navVC =  appDelegate.window?.rootViewController as! UINavigationController
        
        let vcLikeUnlike = storyBoard.instantiateViewController(withIdentifier: "LikeUnlikeViewController") as! LikeUnlikeViewController
        vcLikeUnlike.lblTitleHeader?.text = "People who Commented"
        vcLikeUnlike.strTitle = "People who Commented"
        vcLikeUnlike.dictData = arrReview[indexOfRow]
        navVC.pushViewController(vcLikeUnlike, animated: true)
         */
    }
}

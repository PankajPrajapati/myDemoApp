//
//  StatisticDataCell.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol StatisticDataCellDelegate {
    func btnTimeClicked(indexOfStatistics: NSInteger, strTime: String, indexOfTime: NSInteger) -> Void
}

class StatisticDataCell: UICollectionViewCell ,UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource,PNChartDelegate{
    
    @IBOutlet weak var barChart: PNBarChart!
    @IBOutlet weak var cvUserLIst: UICollectionView!
    @IBOutlet weak var conHightCV: NSLayoutConstraint!
    
    @IBOutlet weak var chartHeaderView: UIView!
    @IBOutlet weak var tblTime: UITableView!
    @IBOutlet weak var conHightTimeTbl: NSLayoutConstraint!
    @IBOutlet weak var viewTimeDisplay: UIView!
    
    @IBOutlet weak var btnTime: UIButton!
    
    @IBOutlet var lblTypeGraph: UILabel!
    @IBOutlet var lblColorGraph: UILabel!
    @IBOutlet var lblTypeHeader: UILabel!
    
    var delegate : StatisticDataCellDelegate?
    var index : NSInteger = -1
    var indexOfSelectedTime = 0
    var dictStatistics = Dictionary<String,Any>()
    var intStatisticType : Int = 0
    var arrUserList = [ Dictionary<String,Any>]()
    var arrTime = ["All Time", "1 Week", "1 Month", "6 Month", "1 Year"]
    
    override func awakeFromNib() {
       
        super.awakeFromNib()
        
        // Initialization code
         self.cvUserLIst.register(UINib(nibName: "ProfileCell", bundle: nil), forCellWithReuseIdentifier: "ProfileCell")
        self.tblTime.register(TimeTblCell.self, forCellReuseIdentifier: "self.tblTime")
        self.tblTime.register(UINib.init(nibName: "TimeTblCell", bundle: nil), forCellReuseIdentifier: "TimeTblCell")

        self.layoutIfNeeded()
//        viewTimeDisplay.layer.masksToBounds = true
        self.viewTimeDisplay.layer.cornerRadius = 3.0
        //        viewContainer.layer.masksToBounds = true
        self.viewTimeDisplay.layer.borderColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.5).cgColor
        self.viewTimeDisplay.layer.borderWidth = 1.0
        self.viewTimeDisplay.layer.shadowColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        self.viewTimeDisplay.layer.shadowOpacity = 1.0
        self.viewTimeDisplay.layer.shadowOffset = CGSize.zero
        self.viewTimeDisplay.layer.shadowRadius = 2.0
        
//        setupGraph()
    }
   
    func setTimeData() -> Void {
        self.btnTime.setTitle("  " + arrTime[indexOfSelectedTime],for: .normal)
    }
    
    func setupGraph() -> Void {
        
//        _ = Timer.scheduledTimer(timeInterval: 0.2, target: self, selector:  #selector(StatisticDataCell.someSelector), userInfo: nil, repeats: false)
        self.perform(#selector(someSelector), with: nil, afterDelay: 0.2)
        //Chart Code
//        var barChartFormatter: NumberFormatter!
//        if barChartFormatter == nil {
//            barChartFormatter = NumberFormatter()
//            barChartFormatter.numberStyle = .currency
//            barChartFormatter.allowsFloats = false
//            barChartFormatter.maximumFractionDigits = 0
//        }
        self.barChart.backgroundColor = UIColor.clear
        //        self.barChart.yLabelFormatter = {(_ yValue: CGFloat) -> Void in
        //
        //            return barChartFormatter.string(fromNumber: Int(yValue))!
        //        }
        self.barChart.yChartLabelWidth = 20.0
        self.barChart.chartMarginLeft = 30.0
        self.barChart.chartMarginRight = 10.0
        self.barChart.chartMarginTop = 5.0
        self.barChart.chartMarginBottom = 10.0
        self.barChart.labelMarginTop = 5.0
        self.barChart.showChartBorder = true
//        barChart.xLabels = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//        barChart.yValues = [100,240,120,508,100,100,210,668,220,300]
        print(self.dictStatistics)
        if !self.dictStatistics.isEmpty {
            let arrXValue = self.dictStatistics["date"] as! Array<String>
            var arrYValue = self.dictStatistics["count"] as! Array<String>
            let arrFloat = arrYValue.intArray
            print(arrXValue)
            print(arrFloat)
            
            if arrXValue.count == 1 {
//                arrXValue.append(arrXValue[0])
//                arrYValue.append("0")
                arrYValue.insert("0", at: 0)
//                arrFloat.insert(0, at: 0)
//                arrXValue.insert("0", at: 0)
            }
            if arrFloat.count > 0 {
                let maxValue = arrFloat.max()! as Int32
                var arrYValueTitle = Array<String>()
                if maxValue >= 10 {
                    let gapValue = Float(maxValue)/10.0
                    
                    var initialValue = 0.0 as Float
                    for _ in 0...9 {
                        initialValue = initialValue + gapValue
                        arrYValueTitle.append(String(initialValue))
                    }
                }
                else{
                    let gapValue = Float(1.0)
//                    var arrYValueTitle = Array<String>()
                    var initialValue = 0.0 as Float
                    var intStartIndex = 1 as Int32
                    if maxValue == 1 {
                        intStartIndex = 0
                    }
                    for _ in intStartIndex...maxValue {
                        initialValue = initialValue + gapValue
                        arrYValueTitle.append(String(initialValue))
                    }
                }
                
                
                arrYValue = arrYValueTitle
            }
            print(arrXValue)
            print(arrYValue)
            print(arrFloat)
            self.barChart.xLabels = arrXValue
            self.barChart.yLabels = arrYValue
            self.barChart.yValues = arrFloat
        }
        else{
            self.barChart.xLabels = nil
            self.barChart.yLabels = nil
            self.barChart.yValues = nil
//            self.barChart.updateData(nil)
        }
        
        barChart.strokeColor = UIColor.init(colorLiteralRed: 121/255.0, green: 161/255.0, blue: 211/255.0, alpha: 1.0)
        //        self.barChart.strokeColors = [PNGreen, PNGreen, PNRed, PNGreen, PNGreen, PNGreen, PNRed, PNGreen]
        self.barChart.isGradientShow = false
        self.barChart.isShowNumbers = false
        self.barChart.stroke()
        self.barChart.delegate = self
        
        self.setTimeData()
    }
    
    func clearGraph() -> Void {
        self.barChart.clearGraph()
    }
    
//    func getIntegerValue(arrString: Array<Any>) -> Array<Float> {
//        var arrFloat = Array<Float>()
//        for (var element) in arrString.enumerated() {
//            
//            let numberFormatter = NumberFormatter()
//            let number = numberFormatter.number(from: element as! String)
//            let numberFloatValue = number?.floatValue
//            
//            arrFloat.append(numberFloatValue!)
//        }
//        return arrFloat
//    }
    
    func someSelector() {
        // Something after a delay
        self.conHightCV.constant = self.cvUserLIst.contentSize.height
        self.layoutIfNeeded()
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrUserList.count
    }
    
    private func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell : ProfileCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProfileCell", for: indexPath as IndexPath) as! ProfileCell
         let dict = arrUserList[indexPath.row]
        let dictUserData = dict["user_data"] as! Dictionary<String,Any>
        
//        cell.imgUser.image = UIImage (named: dict["userImage"]!, in: nil
//            , compatibleWith: nil)
        cell.imgUser.layer.cornerRadius = cell.imgUser.frame.size.height / 2
        cell.imgUser.layer.masksToBounds = true
        
        if index == ENUM_STATISTICS.FOLLOWERS.rawValue {
            cell.lblUserName.text = dict["get_follow_name"] as? String
            cell.lblCount.text = ""
        }
        else if index == ENUM_STATISTICS.VIEWS.rawValue {
            cell.lblUserName.text = dict["get_view_name"] as? String
            cell.lblCount.text = dict["view_count"] as? String
            if (Int(dict["view_count"] as! String)! > 1 ) {
                cell.lblCount.text = (dict["view_count"] as! String?)! + " Views"
            }
            else{
                cell.lblCount.text = (dict["view_count"] as! String?)! + " View"
            }
        }
        else if index == ENUM_STATISTICS.AGREES.rawValue {
            cell.lblUserName.text = dict["get_agree_name"] as? String
            cell.lblCount.text = dict["agreed_count"] as? String
            if (Int(dict["agreed_count"] as! String)! > 1 ) {
                cell.lblCount.text = (dict["agreed_count"] as! String?)! + " Agrees"
            }
            else{
                cell.lblCount.text = (dict["agreed_count"] as! String?)! + " Agree"
            }
        }
        else if index == ENUM_STATISTICS.DISAGREES.rawValue {
            cell.lblUserName.text = dict["get_disagree_name"] as? String
            cell.lblCount.text = dict["disagreed_count"] as? String
            if (Int(dict["disagreed_count"] as! String)! > 1 ) {
                cell.lblCount.text = (dict["disagreed_count"] as! String?)! + " Disagrees"
            }
            else{
                cell.lblCount.text = (dict["disagreed_count"] as! String?)! + " Disagree"
            }
        }
        else if index == ENUM_STATISTICS.COMMENTS.rawValue {
            cell.lblUserName.text = dict["get_commented_name"] as? String
            cell.lblCount.text = dict["commented_count"] as? String
            if (Int(dict["commented_count"] as! String)! > 1 ) {
                cell.lblCount.text = (dict["commented_count"] as! String?)! + " Comments"
            }
            else{
                cell.lblCount.text = (dict["commented_count"] as! String?)! + " Comment"
            }
        }
        else {
            cell.lblCount.text = ""
        }
        
        if dictUserData.keys.contains("photo") {
            
            let strStringNameId = dictUserData["photo"]
            if strStringNameId is String {
                let strPhotoName = strStringNameId as! String
                
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    cell.imgUser.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    cell.imgUser.image = #imageLiteral(resourceName: "default_img")
                }
            }else {
                cell.imgUser.image = #imageLiteral(resourceName: "default_img")
            }
            
        }
        else{
            cell.imgUser.image = #imageLiteral(resourceName: "default_img")
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath: IndexPath) -> CGSize{
        var height = 0 as Int
        if index == ENUM_STATISTICS.FOLLOWERS.rawValue {
            height = 120
        }
        else if index == ENUM_STATISTICS.VIEWS.rawValue {
            height = 145
        }
        else if index == ENUM_STATISTICS.AGREES.rawValue {
            height = 145
        }
        else if index == ENUM_STATISTICS.DISAGREES.rawValue {
            height = 145
        }
        else if index == ENUM_STATISTICS.COMMENTS.rawValue {
            height = 145
        }
        else {
            height = 120
        }
        return CGSize(width: UIScreen.main.bounds.size.width / 3, height: CGFloat( height));
    }
 
    // MARK: - UICollectionView Delegate
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let navVC =  appDelegate.window?.rootViewController as! UINavigationController
        
        let vcUserProfile = storyBoard.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
//        vcUserProfile.isFromStatistics = true
        
        let dictFollowers = arrUserList[indexPath.row];
        var dictPostDummy = Dictionary<String,Any>()
        var dictPostDetailIndiv = Dictionary<String,Any>()
        dictPostDetailIndiv["postuserdata"] = dictFollowers["user_data"]
        dictPostDetailIndiv["need_to_follow"] = dictFollowers["need_to_follow"]
        dictPostDummy["postdetailindiv"] = dictPostDetailIndiv
        vcUserProfile.isfollowers = 1
        vcUserProfile.dictUserPostData = dictPostDummy
        navVC.pushViewController(vcUserProfile, animated: true)
        /*
        let dictFollowers = arrUserList[indexPath.row];
        
        let vcUserProfile = self.storyboard?.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
        var dictPostDummy = Dictionary<String,Any>()
        var dictPostDetailIndiv = Dictionary<String,Any>()
        dictPostDetailIndiv["postuserdata"] = dictFollowers["user_data"]
        dictPostDetailIndiv["need_to_follow"] = dictFollowers["need_to_follow"]
        dictPostDummy["postdetailindiv"] = dictPostDetailIndiv
        vcUserProfile.dictUserPostData = dictPostDummy
        vcUserProfile.isfollowers = 1
        self.navigationController?.pushViewController(vcUserProfile, animated: true)*/
    }
    
    // MARK: - UITableView Datasource
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 25
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTime.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "TimeTblCell") as! TimeTblCell
        cell.lblTime.text = arrTime[indexPath.row]
        if indexPath.row == indexOfSelectedTime {
            self.btnTime.setTitle("  " + arrTime[indexPath.row],for: .normal)
        }
        return cell
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        conHightTimeTbl.constant = 0
        self.btnTime.setTitle("  " + arrTime[indexPath.row],for: .normal)
        indexOfSelectedTime = indexPath.row
        var strTime = ""
        if indexPath.row == 0 {
            strTime = "1"
        }
        else if indexPath.row == 1 {
            strTime = "2"
        }
        else if indexPath.row == 2 {
            strTime = "3"
        }
        else if indexPath.row == 3 {
            strTime = "4"
        }
        else if indexPath.row == 4 {
            strTime = "5"
        }
        self.delegate?.btnTimeClicked(indexOfStatistics: index, strTime: strTime,indexOfTime: indexOfSelectedTime)
    }

    @IBAction func btnTimeAction(_ sender: Any) {
         conHightTimeTbl.constant = 125
    }
}

extension Array {
    var doubleArray:[Double] {
        return flatMap{Double($0 as? String ?? "")}
    }
    var floatArray:[Float] {
        return flatMap{Float($0 as? String ?? "")}
    }
    var intArray:[Int32] {
        return flatMap{Int32($0 as? String ?? "")}
    }
}

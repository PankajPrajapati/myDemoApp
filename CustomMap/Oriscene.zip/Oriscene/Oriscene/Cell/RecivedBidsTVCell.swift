//
//  RecivedBidsTVCell.swift
//  Oriscene
//
//  Created by Tristate on 25/01/17.
//  Copyright © 2017 Tristate. All rights reserved.
//

import UIKit

protocol RecivedBidsCellDelegate {
    func btnViewBidClicked(index : NSInteger) -> Void
}

class RecivedBidsTVCell: UITableViewCell {

    var index : NSInteger = -1
    var delegate : RecivedBidsCellDelegate?
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var btnView: UIButton!
    @IBOutlet weak var viewContainer: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layoutIfNeeded()
        viewContainer.layer.cornerRadius = 3.0
        //        viewContainer.layer.masksToBounds = true
        viewContainer.layer.borderColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.5).cgColor
        viewContainer.layer.borderWidth = 1.0
        
        viewContainer.layer.shadowColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewContainer.layer.shadowOpacity = 1.0
        viewContainer.layer.shadowOffset = CGSize.zero
        viewContainer.layer.shadowRadius = 7.0
        btnView.layer.cornerRadius = 3.0
        btnView.layer.masksToBounds = true

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnViewClickAction(_ sender: Any) {
        self.delegate?.btnViewBidClicked(index: self.index)
    }
    
}

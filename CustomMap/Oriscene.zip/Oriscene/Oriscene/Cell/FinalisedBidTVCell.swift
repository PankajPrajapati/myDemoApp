//
//  BidsTVCell.swift
//  Oriscene
//
//  Created by Parth on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol FinalisedBidListDelegate {
    func btnDownloadClicked(index : NSInteger) -> Void
}

class FinalisedBidTVCell: UITableViewCell {

    var index : NSInteger = -1
    var delegate : FinalisedBidListDelegate?
    
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var lblTime: UILabel!
    @IBOutlet var imgUserPic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblPostDesc: UILabel!
    @IBOutlet var lblDesc: UILabel!
    @IBOutlet var btnDownload: UIButton!
    
    @IBOutlet var heightConstBtnDownload: NSLayoutConstraint!
    @IBOutlet var topSpaceConstBtnDownload: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layoutIfNeeded()
        viewContainer.layer.cornerRadius = 3.0
        //        viewContainer.layer.masksToBounds = true
        viewContainer.layer.borderColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.5).cgColor
        viewContainer.layer.borderWidth = 1.0
        
        viewContainer.layer.shadowColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewContainer.layer.shadowOpacity = 1.0
        viewContainer.layer.shadowOffset = CGSize.zero
        viewContainer.layer.shadowRadius = 7.0
        
        imgUserPic.layer.cornerRadius = imgUserPic.frame.size.height / 2.0
        imgUserPic.layer.masksToBounds = true
        
        btnDownload.layer.cornerRadius = 3.0
        btnDownload.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func btnDownloadAction(_ sender: Any) {
        delegate?.btnDownloadClicked(index: index)
    }
    
}

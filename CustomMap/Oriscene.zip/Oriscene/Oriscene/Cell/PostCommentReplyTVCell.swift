//
//  PostCommentTVCell.swift
//  Oriscene
//
//  Created by Parth on 11/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol PostCommentReplyDelegate {
    func btnCommentReplyClicked(index : NSInteger) -> Void
    func btnSubmitReplyClicked(index : NSInteger) -> Void
    func btnEditReplyClicked(index : NSInteger) -> Void
    func btnDeleteReplyClicked(index : NSInteger) -> Void
}

class PostCommentReplyTVCell: UITableViewCell {

    var delegate : PostCommentReplyDelegate?
    var index : NSInteger = -1
    
    @IBOutlet var imgUserProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblComment: UILabel!
    @IBOutlet var lblTime: UILabel!
    
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet var heightConstEditDeleteButton: NSLayoutConstraint!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layoutIfNeeded()
        imgUserProfilePic.layer.cornerRadius = imgUserProfilePic.frame.size.height/2
        imgUserProfilePic.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnEditAction(_ sender: Any) {
        delegate?.btnEditReplyClicked(index: index)
      
    }
    
    @IBAction func btnDeleteAction(_ sender: Any) {
        delegate?.btnDeleteReplyClicked(index: index)
    }
}

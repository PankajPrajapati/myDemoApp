//
//  UserProfileHeaderView.swift
//  Oriscene
//
//  Created by Parth on 24/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

enum CurrentPostType: Int {
    case SHARE_POST = 0, SELL_POST
}

protocol UserProfileHeaderViewDelegate {
    func btnSharePostSelected() -> Void
    func btnSellPostSelected() -> Void
}

class UserProfileHeaderView: UITableViewHeaderFooterView {
    
    var delegate : UserProfileHeaderViewDelegate?
    var currentPostType : NSInteger = -1
    
    @IBOutlet var btnSharePost: UIButton!
    @IBOutlet var btnSellPost: UIButton!
    
    @IBOutlet var lblSharePost: UILabel!
    @IBOutlet var lblSellPost: UILabel!
    @IBOutlet var viewBackground: UIView!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "UserProfileHeaderView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        let objects = Bundle.main.loadNibNamed("UserProfileHeaderView", owner: self, options: nil)
        let nibView = objects?.first! as! UITableViewHeaderFooterView
        let contentView = self.contentView
        let contentViewSize = contentView.frame.size
        nibView.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(contentViewSize.width), height: CGFloat(contentViewSize.height))
        contentView.addSubview(nibView as UIView)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
//        fatalError("init(coder:) has not been implemented")
    }
    
    @IBAction func btnSharePostAction(_ sender: Any) {
        if currentPostType != CurrentPostType.SHARE_POST.rawValue {
            currentPostType = CurrentPostType.SHARE_POST.rawValue
            delegate?.btnSharePostSelected()
        }
    }
    
    @IBAction func btnSellPostAction(_ sender: Any) {
        if currentPostType != CurrentPostType.SELL_POST.rawValue {
            currentPostType = CurrentPostType.SELL_POST.rawValue
            delegate?.btnSellPostSelected()
        }
    }
}

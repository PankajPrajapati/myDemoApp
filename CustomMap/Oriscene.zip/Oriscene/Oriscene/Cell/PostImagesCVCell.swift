//
//  PostImagesCVCell.swift
//  Oriscene
//
//  Created by Parth on 10/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class PostImagesCVCell: UICollectionViewCell {

    @IBOutlet var imgPostImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.layoutIfNeeded()
    }

}

//
//  TimeTblCell.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 24/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class TimeTblCell: UITableViewCell {

    @IBOutlet weak var lblTime: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

//
//  RevenueListTVCell.swift
//  Oriscene
//
//  Created by Parth on 12/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class RevenueListTVCell: UITableViewCell {

    var index : NSInteger = -1
    
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var imgRevenue: UIImageView!
    @IBOutlet var lblRevenueText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.layoutIfNeeded()
        viewContainer.layer.cornerRadius = 3.0
//        viewContainer.layer.masksToBounds = true
        viewContainer.layer.borderColor = UIColor.init(colorLiteralRed: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.5).cgColor
        viewContainer.layer.borderWidth = 1.0
        
        viewContainer.layer.shadowColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewContainer.layer.shadowOpacity = 1.0
        viewContainer.layer.shadowOffset = CGSize.zero
        viewContainer.layer.shadowRadius = 7.0
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

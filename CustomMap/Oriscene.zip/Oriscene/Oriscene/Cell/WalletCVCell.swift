//
//  WalletCVCell.swift
//  Oriscene
//
//  Created by TriState  on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class WalletCVCell: UICollectionViewCell {
    
}

//
//  FollowersTVCell.swift
//  Oriscene
//
//  Created by Parth on 29/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol FollowersDelegate {
    func btnUnFollowClicked(index : NSInteger) -> Void
}

class FollowingTVCell: UITableViewCell {

    var index : NSInteger = -1
    var delegate : FollowersDelegate?
    
    @IBOutlet var imgUserPic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var btnUnFollow: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layoutIfNeeded()
        imgUserPic.layer.cornerRadius = imgUserPic.frame.size.height / 2.0
        imgUserPic.layer.masksToBounds = true
        btnUnFollow.layer.cornerRadius = 3.0
        btnUnFollow.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnUnFollowAction(_ sender: Any) {
        delegate?.btnUnFollowClicked(index: index)
    }
    
}

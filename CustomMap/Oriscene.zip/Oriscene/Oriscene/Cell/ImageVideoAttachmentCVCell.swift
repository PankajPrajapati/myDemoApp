//
//  ImageVideoAttachmentCVCell.swift
//  Oriscene
//
//  Created by Parth on 15/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol AttachmentCreatePostDelegate {
    func removeAttachment(index : NSInteger) -> Void
}

class ImageVideoAttachmentCVCell: UICollectionViewCell {

    var index : NSInteger = -1
    var delegate : AttachmentCreatePostDelegate?
    
    @IBOutlet var imgAttachment: UIImageView!
    @IBOutlet var btnRemoveAttachment: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        layoutIfNeeded()
        btnRemoveAttachment.layer.cornerRadius = btnRemoveAttachment.frame.size.height / 2.0
        btnRemoveAttachment.layer.masksToBounds = true
        
    }
    @IBAction func btnRemoveAttachmentAction(_ sender: Any) {
        delegate?.removeAttachment(index: index)
    }
    

}

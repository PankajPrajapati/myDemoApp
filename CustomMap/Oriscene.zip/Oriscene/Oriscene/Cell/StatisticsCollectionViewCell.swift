//
//  StatisticsCollectionViewCell.swift
//  Oriscene
//
//  Created by Pragnesh Dixit on 23/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class StatisticsCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lblDivider: UILabel!
    @IBOutlet weak var lblStatisticsTypes: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

//
//  PostListTVCell.swift
//  Oriscene
//
//  Created by Parth on 10/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol PostListingDelegate {
    func postLikeClicked(indexOfPost: NSInteger) -> Void
    func postUnLikeClicked(indexOfPost: NSInteger) -> Void
    func postViewClicked(indexOfPost: NSInteger) -> Void
    func postCommentClicked(indexOfPost: NSInteger) -> Void
    func postReplyClicked(indexOfPost: NSInteger) -> Void
    func postFollowClicked(indexOfPost: NSInteger) -> Void
    func postDeleteClicked(indexOfPost: NSInteger) -> Void
    
    func openUserProfileScreen(indexOfPost: NSInteger) -> Void
    
    func postEAClicked(indexOfPost: NSInteger) -> Void
    func postChatClicked(indexOfPost: NSInteger) -> Void
    func postBidClicked(indexOfPost: NSInteger) -> Void
    func postViewMoreClicked(indexOfPost: NSInteger) -> Void
    
    func openPostDetail(indexOfPost: NSInteger) -> Void
    func openPostAttachment(indexOfPost: NSInteger) -> Void
    func postDescriptionEditClicked(indexOfPost: NSInteger) -> Void
}

class PostListTVCell: UITableViewCell,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var arrPostImages = [Dictionary<String,Any>]()
    var arrPostAction = [Dictionary<String,Any>]()
    var arrMoreAction = [Dictionary<String,Any>]()
    var dictPostDtl = Dictionary<String,Any>()
    var index : NSInteger = -1
    var delegate : PostListingDelegate?
    var currentPostType : NSInteger = -1
    
    @IBOutlet var viewTop: UIView!
    @IBOutlet var viewBottom: UIView!
    @IBOutlet var viewMiddle: UIView!
    @IBOutlet var viewBottomForSellPost: UIView!
    
    @IBOutlet var imgProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblCategory: UILabel!    
    
    @IBOutlet var cvPostImages: UICollectionView!
    @IBOutlet var lblPostDetail: UILabel!
    @IBOutlet var lblOrgText: UILabel!
    @IBOutlet var lblShareText: UILabel!
    @IBOutlet var lblSeperaterForDtlOrgText: UILabel!

    @IBOutlet weak var cvPostAction: UICollectionView!
    
    @IBOutlet var btnLike: UIButton!
    @IBOutlet var btnUnlike: UIButton!
    @IBOutlet var btnView: UIButton!
    @IBOutlet var btnComment: UIButton!
    @IBOutlet var btnShare: UIButton!
    @IBOutlet var btnEA: UIButton!
    @IBOutlet var btnChat: UIButton!
    @IBOutlet var btnBid: UIButton!
    
    @IBOutlet weak var btnDescriptionEdit: UIButton!
    @IBOutlet weak var widthBtnDescriptionEdit: NSLayoutConstraint!
    
    @IBOutlet var lblLocation: UILabel!
    @IBOutlet var imgTypeOfAttachment: UIImageView!
    @IBOutlet var imgVideoSnapshot: UIImageView!
    
    @IBOutlet var heightConstLocation: NSLayoutConstraint!
    @IBOutlet var heightConstImageType: NSLayoutConstraint!
    
    @IBOutlet weak var viewMoreContainer: UIView!
    @IBOutlet weak var cvMoreAction: UICollectionView!
    
    @IBOutlet weak var btnFollow: UIButton!
    @IBOutlet weak var btnPrimePost: UIButton!
    @IBOutlet weak var btnMore: UIButton!
    
    @IBOutlet weak var topSpaceLblUserName: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.cvPostAction.register(UINib(nibName: "PostActionCVCell", bundle: nil), forCellWithReuseIdentifier: "PostActionCVCell")
        
        btnLike.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnLike.layer.borderWidth = 1.0
        btnLike.layer.cornerRadius = 12.0
        btnLike.layer.masksToBounds = true
        
        btnUnlike.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnUnlike.layer.borderWidth = 1.0
        btnUnlike.layer.cornerRadius = 12.0
        btnUnlike.layer.masksToBounds = true
        
        btnView.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnView.layer.borderWidth = 1.0
        btnView.layer.cornerRadius = 12.0
        btnView.layer.masksToBounds = true
        
        btnComment.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnComment.layer.borderWidth = 1.0
        btnComment.layer.cornerRadius = 12.0
        btnComment.layer.masksToBounds = true
        
        btnShare.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnShare.layer.borderWidth = 1.0
        btnShare.layer.cornerRadius = 12.0
        btnShare.layer.masksToBounds = true
        
        btnEA.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnEA.layer.borderWidth = 1.0
        btnEA.layer.cornerRadius = 12.0
        btnEA.layer.masksToBounds = true
        
        btnChat.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnChat.layer.borderWidth = 1.0
        btnChat.layer.cornerRadius = 12.0
        btnChat.layer.masksToBounds = true
        
        btnBid.layer.borderColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        btnBid.layer.borderWidth = 1.0
        btnBid.layer.cornerRadius = 12.0
        btnBid.layer.masksToBounds = true
        
        self.layoutIfNeeded()
        self.updateConstraintsIfNeeded()
        imgProfilePic.layer.cornerRadius = imgProfilePic.frame.size.height/2.0
        imgProfilePic.layer.masksToBounds = true
        
        let tapForLabel = UITapGestureRecognizer(target: self, action: #selector(tapFunction))
        tapForLabel.numberOfTapsRequired = 1
        lblUserName.isUserInteractionEnabled = true
        lblUserName.addGestureRecognizer(tapForLabel)
        
        let tapForImage = UITapGestureRecognizer(target: self, action: #selector(tapFunction))
        tapForImage.numberOfTapsRequired = 1
        lblUserName.isUserInteractionEnabled = true
        lblUserName.addGestureRecognizer(tapForImage)
        
        let tapForImageAttachment = UITapGestureRecognizer(target: self, action: #selector(tapImageAttachment))
        tapForImageAttachment.numberOfTapsRequired = 1
        imgTypeOfAttachment.isUserInteractionEnabled = true
        imgTypeOfAttachment.addGestureRecognizer(tapForImageAttachment)
//        self.viewMoreContainer.isHidden = true
        
        self.viewMoreContainer.transform =  CGAffineTransform(translationX: 500, y: 0)
    }
    
    override func layoutSubviews() {
        cvPostImages.register(PostImagesCVCell.self, forCellWithReuseIdentifier: "PostImagesCVCell")
        cvPostImages.register(UINib.init(nibName: "PostImagesCVCell", bundle: nil), forCellWithReuseIdentifier: "PostImagesCVCell")
        cvMoreAction.register(UINib.init(nibName: "PostMoreActionCVCell", bundle: nil), forCellWithReuseIdentifier: "PostMoreActionCVCell")
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    //MARK:- Button Action
    @IBAction func btnLikeAction(_ sender: AnyObject) {
        btnLike.isSelected = !btnLike.isSelected
        btnUnlike.isSelected = !btnLike.isSelected
        delegate?.postLikeClicked(indexOfPost: index)
    }
    @IBAction func btnUnlikeAction(_ sender: AnyObject) {
        btnUnlike.isSelected = !btnUnlike.isSelected
        btnLike.isSelected = !btnUnlike.isSelected
        delegate?.postUnLikeClicked(indexOfPost: index)
    }
    @IBAction func btnViewAction(_ sender: AnyObject) {
        btnView.isSelected = !btnView.isSelected
        delegate?.postViewClicked(indexOfPost: index)
    }
    @IBAction func btnCommentAction(_ sender: AnyObject) {
        btnComment.isSelected = !btnComment.isSelected
        delegate?.postCommentClicked(indexOfPost: index)
    }
    @IBAction func btnShareAction(_ sender: AnyObject) {
        btnShare.isSelected = !btnShare.isSelected
        delegate?.postReplyClicked(indexOfPost: index)
    }
    
    @IBAction func btnEAAction(_ sender: Any) {
//        btnEA.isSelected = !btnEA.isSelected
        delegate?.postEAClicked(indexOfPost: index)
    }
    @IBAction func btnChatAction(_ sender: Any) {
//        btnChat.isSelected = !btnChat.isSelected
        delegate?.postChatClicked(indexOfPost: index)
    }
    
    @IBAction func btnBidAction(_ sender: Any) {
        delegate?.postBidClicked(indexOfPost: index)
    }
    
    @IBAction func btnEditDescriptionClickAction(_ sender: Any) {
        delegate?.postDescriptionEditClicked(indexOfPost: index)
    }
    @IBAction func btnMoreClickAction(_ sender: Any) {
        
        self.viewMoreContainer.isHidden = false
        self.cvMoreAction.reloadData()
        //        UIView.animate(withDuration: 0.0, animations: { () -> Void in
        //         self.viewMoreContainer.alpha = 0.0
        //        }, completion: { (_ finished : Bool) -> Void in
        //            UIView.animate(withDuration: 0.3, animations: { () -> Void in
        //                 self.viewMoreContainer.alpha = 1.0
        //            })
        //        })
        //
        //       self.cvMoreAction.reloadData()
        UIView.animate(withDuration: 0.7, delay: 0.0, usingSpringWithDamping: 0.8,
                       initialSpringVelocity: 0.8, options: [], animations: {
                        self.viewMoreContainer.transform = CGAffineTransform(scaleX: 1, y: 1)
        }, completion: {(_ finished : Bool) -> Void in
            self.viewMoreContainer.layoutIfNeeded()
            
        })
    }
    @IBAction func btnCloseMoreClickAction(_ sender: Any) {
        //
        //        UIView.animate(withDuration: 0.3, animations: {
        //            self.viewMoreContainer.alpha = 0.0
        //        }) { (Bool) in
        //             self.viewMoreContainer.isHidden = true
        //        }
        UIView.animate(withDuration: 0.7, delay: 0.0, usingSpringWithDamping: 0.8,
                       initialSpringVelocity: 0.8, options: [], animations: {
                        self.viewMoreContainer.transform =  CGAffineTransform(translationX: 500, y: 0)
        })
    }
    @IBAction func btnFollowAction(_ sender: Any) {
        delegate?.postFollowClicked(indexOfPost: index)
    }
    
    // MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.cvPostImages {
            return arrPostImages.count
        } else if collectionView == self.cvPostAction {
            return arrPostAction.count
        }
        else {
            //More Action
            return arrMoreAction.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell : UICollectionViewCell!
        if collectionView == self.cvPostImages {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PostImagesCVCell", for: indexPath) as! PostImagesCVCell
            let dictImages = arrPostImages[indexPath.row]
            cell.imgPostImage.contentMode = .scaleAspectFill
            
            var strBaseUrl = ""
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                strBaseUrl = IMAGE_ATTACHMENT_BASE_URL
            }
            else{
                strBaseUrl = SELL_IMAGE_ATTACHMENT_URL
            }
            
            if dictImages.keys.contains("attachment_name") {
                let strPhotoName = dictImages["attachment_name"] as! String
                if strPhotoName.characters.count != 0 {
                    let strUrl = strBaseUrl + (dictImages["attachment_name"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    cell.imgPostImage.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    cell.imgPostImage.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                cell.imgPostImage.image = #imageLiteral(resourceName: "default_img")
            }
            return cell
        } else if collectionView == self.cvPostAction  {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PostActionCVCell", for: indexPath) as! PostActionCVCell
//            print("========================")
//            print(dictPostDtl)
//            print("========================")
            let dictData = arrPostAction[indexPath.row]
            let intPostActionType = dictData["postActionType"] as! Int
            let dictPostDtlIndividual = dictPostDtl["postdetailindiv"] as! Dictionary<String,Any>
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                switch intPostActionType {
                case PostActionTypeSHARE.LIKE_POST.rawValue:
                    
                    if (dictPostDtlIndividual["ag_cls"] as AnyObject).int32Value == 1 {
                        cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                        cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    }
                    else{
                        cell.imgAction.image = UIImage (named: dictData["img_icon_unsel"] as! String)
                        cell.lblAction.textColor = UIColor.lightGray
                    }
                    cell.lblAction.text = (dictPostDtlIndividual["agree_count"] as AnyObject).stringValue
                    
                    break
                    
                case PostActionTypeSHARE.DISLIKE_POST.rawValue:
                    if (dictPostDtlIndividual["dag_cls"] as AnyObject).int32Value == 1 {
                        cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                        cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    }
                    else{
                        cell.imgAction.image = UIImage (named: dictData["img_icon_unsel"] as! String)
                        cell.lblAction.textColor = UIColor.lightGray
                    }
                    cell.lblAction.text = (dictPostDtlIndividual["dis_agree_count"] as AnyObject).stringValue
                    break
                case PostActionTypeSHARE.VIEW_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = dictData["view_count"] as! String?
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    
                    break
                case PostActionTypeSHARE.COMMENT_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = (dictData["comment_count"] as AnyObject).stringValue
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                    /*
                case PostActionTypeSHARE.FOLLOW_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = "Follow"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                case PostActionTypeSHARE.SHARE_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    cell.lblAction.text = "Share"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                    
                case PostActionTypeSHARE.DELETE_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    //                cell.lblAction.text = (dictData["need_to_dlt"] as AnyObject).stringValue
                    
                    break
                case PostActionTypeSHARE.PRIME_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    cell.lblAction.text = "Prime"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                */
                default:
                    
                    break
                    
                }
            }
            else{
                
                switch intPostActionType {
                case PostActionTypeSELL.EA_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)

                    cell.lblAction.text = "E.A."
                    
                    break
                    
                case PostActionTypeSELL.COMMENT_POST.rawValue:

                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    cell.lblAction.text = "Chat"

                    break
                case PostActionTypeSELL.BID_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = "Bid"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    
                    break
                case PostActionTypeSELL.EDIT_BID_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = "Edit Bid"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                case PostActionTypeSELL.VIEW_MORE_DETAIL_POST.rawValue:
                    
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    
                    cell.lblAction.text = "View More"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                    
                case PostActionTypeSELL.DELETE_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    cell.lblAction.text = ""
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                    
                case PostActionTypeSELL.SOLD_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon_sel"] as! String)
                    cell.lblAction.text = "SOLD"
                    cell.lblAction.textColor = UIColor.init(colorLiteralRed: 0.0/255.0, green: 102.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    break
                default:
                    
                    break
                    
                }
            }
            
            return cell
        }else {
            //More Action
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PostMoreActionCVCell", for: indexPath) as! PostMoreActionCVCell
            let dictData = arrMoreAction[indexPath.row]
            cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
           
            /* let intPostActionType = dictData["moreActionType"] as! Int
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                switch intPostActionType {
                case PostMoreActionTypeSHARE.SHARE_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    break
                    
                case PostMoreActionTypeSHARE.DELETE_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    //                cell.lblAction.text = (dictData["need_to_dlt"] as AnyObject).stringValue
                    
                    break
                case PostActionTypeSHARE.PRIME_POST.rawValue:
                    cell.imgAction.image = UIImage (named: dictData["img_icon"] as! String)
                    break
                    
                default:
                    
                    break
                    
                }
            }
             */

            
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath: IndexPath) -> CGSize{
        if collectionView == self.cvPostImages {
            return CGSize(width: UIScreen.main.bounds.size.width - 26, height: 160);
        } else if collectionView == self.cvPostAction {
             let dictData = arrPostAction[sizeForItemAtIndexPath.row]
            var strCount : String = String()
            let intPostActionType = dictData["postActionType"] as! Int
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                switch intPostActionType {
                case PostActionTypeSHARE.LIKE_POST.rawValue:
                    let temp = "\(dictData["agree_count"]!)" //(dictData["agree_count"] as AnyObject).stringValue
                    if temp == "" {
                        strCount = " "
                    }else{
                        strCount = temp
                    }
                    
                    break
                    
                case PostActionTypeSHARE.DISLIKE_POST.rawValue:
                    let temp = "\(dictData["dis_agree_count"]!)" //( as AnyObject).stringValue
                    if temp == "" {
                        strCount = " "
                    }else{
                        strCount = temp
                    }
                    
                    break
                case PostActionTypeSHARE.VIEW_POST.rawValue:
                    let temp = "\(dictData["view_count"]!)"
//                    let temp = (dictData["view_count"] as AnyObject).stringValue
                    if temp == "" {
                        strCount = " "
                    }else{
                        strCount = temp
                    }
                    
                    break
                case PostActionTypeSHARE.COMMENT_POST.rawValue:
                    let temp = "\(dictData["comment_count"]!)"
//                    let temp = (dictData["comment_count"] as AnyObject).stringValue
                    if temp == "" {
                        strCount = " "
                    }else{
                        strCount = temp
                    }
                    
                    break
//                case PostActionTypeSHARE.FOLLOW_POST.rawValue:
//                    strCount = "Follow"
//                    break
//                case PostActionTypeSHARE.SHARE_POST.rawValue:
//                    strCount = "Share"
//                    //                return CGSize(width: 38, height: 35);
//                    break
//                case PostActionTypeSHARE.DELETE_POST.rawValue:
//                    strCount = " "
//                    return CGSize(width: 47, height: 35);
//                    
//                case PostActionTypeSHARE.PRIME_POST.rawValue:
//                    strCount = "Prime"
//                    break
                    
                default:
                    
                    break
                    
                }
            }
            else{
                switch intPostActionType {
                case PostActionTypeSELL.EA_POST.rawValue:
                    strCount = "E.A."
                    
                    break
                    
                case PostActionTypeSELL.COMMENT_POST.rawValue:
                    strCount = "Chat"
                    
                    break
                case PostActionTypeSELL.BID_POST.rawValue:
                    strCount = "Bid"
                    
                    break
                case PostActionTypeSELL.EDIT_BID_POST.rawValue:
                    strCount = "Edit Bid"
                    
                    break
                case PostActionTypeSELL.VIEW_MORE_DETAIL_POST.rawValue:
                    strCount = "View More"
                    break
                case PostActionTypeSELL.SOLD_POST.rawValue:
                    strCount = "SOLD"
                    break
                case PostActionTypeSELL.DELETE_POST.rawValue:
                    return CGSize(width: 47, height: 35);
                    
                default:
                    
                    break
                    
                }
            }
            
            var charcount = strCount.characters.count
            charcount = 57 + (charcount * 7)
            
            return CGSize(width: charcount, height: 35);
            
        }else{
             return CGSize(width: self.cvMoreAction.frame.size.width / 3, height: 50);
        }
    }
    
    // MARK: - UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView == self.cvPostImages {
            delegate?.openPostDetail(indexOfPost: index)
        } else if collectionView == self.cvPostAction {
            let dictData = arrPostAction[indexPath.row]
            let intPostActionType = dictData["postActionType"] as! Int
            
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                switch intPostActionType {
                case PostActionTypeSHARE.LIKE_POST.rawValue:
                    delegate?.postLikeClicked(indexOfPost: index)
                    
                    break
                    
                case PostActionTypeSHARE.DISLIKE_POST.rawValue:
                    delegate?.postUnLikeClicked(indexOfPost: index)
                    
                    break
                case PostActionTypeSHARE.VIEW_POST.rawValue:
                    delegate?.postViewClicked(indexOfPost: index)
                    
                    break
                case PostActionTypeSHARE.COMMENT_POST.rawValue:
                    delegate?.postCommentClicked(indexOfPost: index)
                    
                    break
                    /*
                case PostActionTypeSHARE.FOLLOW_POST.rawValue:
                    delegate?.postFollowClicked(indexOfPost: index)
                    
                    break
                case PostActionTypeSHARE.SHARE_POST.rawValue:
                    delegate?.postReplyClicked(indexOfPost: index)
                    
                    break
                    
                case PostActionTypeSHARE.DELETE_POST.rawValue:
                    delegate?.postDeleteClicked(indexOfPost: index)
                    break
                    
                case PostActionTypeSHARE.PRIME_POST.rawValue:
                    break
                    */
                default:
                    
                    break
                    
                }
            }
            else{
                switch intPostActionType {
                case PostActionTypeSELL.EA_POST.rawValue:
                    delegate?.postEAClicked(indexOfPost: index)
                    
                    break
                    
                case PostActionTypeSELL.COMMENT_POST.rawValue:
                    delegate?.postChatClicked(indexOfPost: index)
                    
                    break
                case PostActionTypeSELL.BID_POST.rawValue:
                    delegate?.postBidClicked(indexOfPost: index)
                    
                    break
                case PostActionTypeSELL.EDIT_BID_POST.rawValue:
                    delegate?.postBidClicked(indexOfPost: index)
                    
                    break
                case PostActionTypeSELL.VIEW_MORE_DETAIL_POST.rawValue:
                    delegate?.postViewMoreClicked(indexOfPost: index)
                    break
                case PostActionTypeSELL.DELETE_POST.rawValue:
                    delegate?.postDeleteClicked(indexOfPost: index)
                    break
                    
                case PostActionTypeSELL.SOLD_POST.rawValue:
                    
                    break
                default:
                    
                    break
                    
                }
            }
        }
        else {
            //more action
            let dictData = arrMoreAction[indexPath.row]
            let intPostMoreActionType = dictData["moreActionType"] as! Int
            
            switch intPostMoreActionType {
            case PostMoreActionTypeSHARE.SHARE_POST.rawValue:
                delegate?.postReplyClicked(indexOfPost: index)
                break
                
            case PostMoreActionTypeSHARE.EDIT_POST.rawValue:
                delegate?.postDescriptionEditClicked(indexOfPost: index)
                
                break
                
            case PostMoreActionTypeSHARE.DELETE_POST.rawValue:
                delegate?.postDeleteClicked(indexOfPost: index)
                break
            default:
                
                break
            }
        }
    }
    
    // MARK: - Custom Method
    func reloadImages() -> Void {
        cvPostImages.reloadData()
    }
    
    // MARK: - TapGesture Method
    func tapFunction(sender:UITapGestureRecognizer) {
        print("tap working")
        delegate?.openUserProfileScreen(indexOfPost: index)
    }
    
    func tapImageAttachment(sender:UITapGestureRecognizer) {
        delegate?.openPostAttachment(indexOfPost: index)
    }
}

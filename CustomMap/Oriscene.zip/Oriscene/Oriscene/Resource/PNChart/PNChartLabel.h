//
//  PNChartLabel.h
//  PNChart
//
//  Created by kevin on 10/3/13.
//  Copyright (c) 2013年 kevinzhow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PNChartLabel : UILabel

@end

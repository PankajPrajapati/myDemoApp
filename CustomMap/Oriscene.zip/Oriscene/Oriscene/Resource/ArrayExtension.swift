//
//  ArrayExtension.swift
//  Oriscene
//
//  Created by Tristate on 13/01/17.
//  Copyright © 2017 Tristate. All rights reserved.
//

import Foundation

extension NSArray {
    
    func arrayByReplacingNullsWithBlanks() -> [AnyObject] {
        var replaced :  [AnyObject] = (self as [AnyObject])
        let nul : AnyObject = NSNull()
        let blank = ""
//      print(self)
        for index in 0..<replaced.count {
            let object = replaced[index] as AnyObject
            
            if  object === nul {
                replaced[index] =  blank as AnyObject
            }
            
            else if object is [String : AnyObject] {
                replaced[index] = (object as! NSDictionary).dictionaryByReplacingNullsWithBlanks() as AnyObject
            }
            else if object is [AnyObject] {
                replaced[index] = (object as! NSArray).arrayByReplacingNullsWithBlanks as AnyObject
            }
        }
        return replaced as [AnyObject]
    }
}

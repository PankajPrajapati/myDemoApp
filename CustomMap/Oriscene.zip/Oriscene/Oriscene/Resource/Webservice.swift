//
//  WebService.swift
//  DemoWebService
//
//  Created by Pragnesh Dixit on 07/01/15.
//  Copyright (c) 2015 TriState Technology. All rights reserved.
//

import Foundation
import UIKit


typealias ResponseReceivedSuccessfully = (_ dict:Dictionary<String, Any>?)->Void
typealias ResponseFail = (_ error:NSError?)->Void
typealias DataRateProgress = (_ progressInPercent:Float)->Void


public class WebService: NSObject,NSURLConnectionDelegate,NSURLConnectionDataDelegate
{
    
    public override init(){}
    
    //let WEBSERVICE_URL="http://Oriscene/webservices/main.php"
    private  var expectedContentLength:Int64?
    private var conn:NSURLConnection!
    private var objURL:NSString!
    private var objParameter:NSMutableDictionary?
    public  var mutableData:NSMutableData?
    private  var responseSuccessful:ResponseReceivedSuccessfully?
    private  var responseFail:ResponseFail?
    private  var progressblock:DataRateProgress?
    public var Busy:Bool!
    private var encryptionOn:Bool!;
    
    func callGetWebServiceUsingURL(url:NSURL,onSuccessfulResponse:@escaping (_ dict:Dictionary<String, Any>?)->(),onFailResponse:@escaping (_ error:NSError?)->()){
        
        self.cancelWebservice();
        responseSuccessful = onSuccessfulResponse;
        responseFail = onFailResponse;
        Busy = true;
        mutableData = NSMutableData();
        let request:NSURLRequest=NSURLRequest(url: url as URL)
        conn=NSURLConnection(request:request as URLRequest, delegate: self)
        encryptionOn = false;
    }
    
    
    func callJSONMethod(methodName:NSString,parameters:NSMutableDictionary?,isEncrpyted:Bool,onSuccessfulResponse:@escaping (_ dict:Dictionary<String, Any>?)->(),onFailResponse:@escaping (_ error:NSError?)->()){
      
        //Append Login User Id
//        loggedUser
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        
        if userDefault.keys.contains("userData") {
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            if dictUser.keys.contains("reporter_id") {
                parameters?["loggedUser"] = dictUser["reporter_id"] as? String
            }
        }
        
        Busy = true;
        var url:NSURL=NSURL()
        self.cancelWebservice()
        encryptionOn=isEncrpyted;
        responseSuccessful=onSuccessfulResponse;
        responseFail=onFailResponse;
        if(encryptionOn  == false){
            url=NSURL(string:WEBSERVICE_URL )!
        }
        else
        {
            
        }
        
        let request:NSMutableURLRequest=NSMutableURLRequest(url: url as URL)
        request.httpMethod="POST"
        request .setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
      
        let requestDict = NSMutableDictionary()
        requestDict["method_name"] = methodName
        requestDict["body"] = parameters!
      
        let jsonString:NSString=self.getJsonFromDictionary(dictData: requestDict)
        let strRequest:AnyObject = NSString(format:"json=%@",jsonString)
     
        let stringValue = strRequest as? String
        
        print(stringValue ?? "")
        
        let data = stringValue?.data(using: .utf8)
        request.httpBody=data! as Data
        mutableData = NSMutableData()

//        conn = NSURLConnection(request: request as URLRequest, delegate: self, startImmediately: false)
        conn = NSURLConnection(request:request as URLRequest, delegate: self)
        conn.schedule(in: RunLoop.main, forMode: RunLoopMode.defaultRunLoopMode)
        conn.start()
    }
    
    func callJSONMethod(methodName:NSString,imageData:NSData?,attachmentKey:NSString,parameters:NSMutableDictionary?,isEncrpyted:Bool,onSuccessfulResponse:@escaping (_ dict:Dictionary<String, Any>?)->(),onFailResponse:@escaping (_ error:NSError?)->(),onProgressResponse:@escaping (_ progressInPercent:Float)->())->Void{
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        
        if userDefault.keys.contains("userData") {
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            if dictUser.keys.contains("reporter_id") {
                parameters?["loggedUser"] = dictUser["reporter_id"] as? String
            }
        }
        
        Busy = true;
        var url:NSURL=NSURL()
        self.cancelWebservice()
        encryptionOn=isEncrpyted;
        responseSuccessful=onSuccessfulResponse;
        responseFail=onFailResponse;
        progressblock=onProgressResponse;
        if(encryptionOn  == false){
            url=NSURL(string:WEBSERVICE_URL )!
        }
        let body:NSMutableData=NSMutableData()
        let request:NSMutableURLRequest=NSMutableURLRequest(url: url as URL)
        request.httpMethod="POST"
        let boundry:NSString="---------------------------14737809831466499882746641449"
        let contentType:NSString=NSString(format: "multipart/form-data; boundary=%@", boundry)
        request .setValue(contentType as String, forHTTPHeaderField: "Content-Type")
        let requestDict = NSMutableDictionary()
        requestDict["method_name"] = methodName
        requestDict["body"] = parameters!
        let jsonString:NSString=self.getJsonFromDictionary(dictData: requestDict)
        var strRequest:NSString=NSString()
        if(encryptionOn==true){
          //  strRequest=NSString(format:"%@",jsonString.convertToCipherTextDirectWithNumber(true))
            // strRequest = [NSString stringWithFormat:@"%@",[jsonString convertToCipherTextDirectWithNumber:YES]];
        }
        else{
            strRequest = jsonString;
        }
        
        print(strRequest )
        
        let data=strRequest.data(using: String.Encoding.utf8.rawValue)
        body.append(NSString(format:"--%@\r\n", boundry).data(using: String.Encoding.utf8.rawValue)!)
        let paramsFormat:NSString = NSString(format:"Content-Disposition: form-data; name=\"%@\"\r\n\r\n","json")
        body.append(paramsFormat.data(using: String.Encoding.utf8.rawValue)!)
        body.append(data!)
        body.append(NSString(format:"\r\n").data(using: String.Encoding.utf8.rawValue)!)
        
        // file
        body.append(NSString(format:"--%@\r\n", boundry).data(using: String.Encoding.utf8.rawValue)!)
//        body.append(NSString(format:"Content-Disposition: attachment; name=\"pi_uploaded_image\"; filename=\"temp.png\"\r\n").data(using: String.Encoding.utf8.rawValue)!)
       
        // body.append(NSString(format:"Content-Disposition: attachment; name=\"profilePic\"; filename=\"temp.png\"\r\n").data(using: String.Encoding.utf8.rawValue)!)
        
        body.append(NSString(format:"Content-Disposition: attachment; name=\"%@\"; filename=\"temp.png\"\r\n",attachmentKey).data(using: String.Encoding.utf8.rawValue)!)
        body.append(NSString(format:"Content-Type: application/octet-stream\r\n\r\n").data(using: String.Encoding.utf8.rawValue)!)
        body.append(NSData(data: imageData! as Data) as Data)
        body.append(NSString(format:"\r\n").data(using: String.Encoding.utf8.rawValue)!)
        body.append(NSString(format:"--%@--\r\n",boundry).data(using: String.Encoding.utf8.rawValue)!)
        request.httpBody=body as Data
        mutableData = NSMutableData()
        conn = NSURLConnection(request:request as URLRequest, delegate: self)
      
        conn.schedule(in: RunLoop.main, forMode: RunLoopMode.defaultRunLoopMode)
        conn.start()
        
        
    }
    
    
    func callJSONMethod_Video(methodName:NSString,imageData:NSData?,attachmentKey:NSString,filename:NSString,parameters:NSMutableDictionary?,isEncrpyted:Bool,onSuccessfulResponse:@escaping (_ dict:Dictionary<String, Any>?)->(),onFailResponse:@escaping ( _ error:NSError?)->(),onProgressResponse:@escaping (_ progressInPercent:Float)->())->Void{
        
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        
        if userDefault.keys.contains("userData") {
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            if dictUser.keys.contains("reporter_id") {
                parameters?["loggedUser"] = dictUser["reporter_id"] as? String
            }
        }
        
        Busy = true;
        var url:NSURL=NSURL()
        self.cancelWebservice()
        encryptionOn=isEncrpyted;
        responseSuccessful=onSuccessfulResponse;
        responseFail=onFailResponse;
        progressblock=onProgressResponse;
        if(encryptionOn  == false){
            url=NSURL(string:WEBSERVICE_URL )!
        }
        let body:NSMutableData=NSMutableData()
        let request:NSMutableURLRequest=NSMutableURLRequest(url: url as URL)
        request.httpMethod="POST"
        let boundry:NSString="---------------------------14737809831466499882746641449"
        let contentType:NSString=NSString(format: "multipart/form-data; boundary=%@", boundry)
        request .setValue(contentType as String, forHTTPHeaderField: "Content-Type")
        let requestDict = NSMutableDictionary()
        requestDict["method_name"] = methodName
        requestDict["body"] = parameters!
        let jsonString:NSString=self.getJsonFromDictionary(dictData: requestDict)
        var strRequest:NSString=NSString()
        if(encryptionOn==true){
            //  strRequest=NSString(format:"%@",jsonString.convertToCipherTextDirectWithNumber(true))
            // strRequest = [NSString stringWithFormat:@"%@",[jsonString convertToCipherTextDirectWithNumber:YES]];
        }
        else{
            strRequest = jsonString;
        }
        
        print(strRequest )
        
        let data=strRequest.data(using: String.Encoding.utf8.rawValue)
        body.append(NSString(format:"--%@\r\n", boundry).data(using: String.Encoding.utf8.rawValue)!)
        let paramsFormat:NSString = NSString(format:"Content-Disposition: form-data; name=\"%@\"\r\n\r\n","json")
        body.append(paramsFormat.data(using: String.Encoding.utf8.rawValue)!)
        body.append(data!)
        body.append(NSString(format:"\r\n").data(using: String.Encoding.utf8.rawValue)!)
        
        // file
        body.append(NSString(format:"--%@\r\n", boundry).data(using: String.Encoding.utf8.rawValue)!)
        //        body.append(NSString(format:"Content-Disposition: attachment; name=\"pi_uploaded_image\"; filename=\"temp.png\"\r\n").data(using: String.Encoding.utf8.rawValue)!)
        
        // body.append(NSString(format:"Content-Disposition: attachment; name=\"profilePic\"; filename=\"temp.png\"\r\n").data(using: String.Encoding.utf8.rawValue)!)
        
        body.append(NSString(format:"Content-Disposition: attachment; name=\"%@\"; filename=\"%@\"\r\n",attachmentKey,filename).data(using: String.Encoding.utf8.rawValue)!)
        body.append(NSString(format:"Content-Type: application/octet-stream\r\n\r\n").data(using: String.Encoding.utf8.rawValue)!)
        body.append(NSData(data: imageData! as Data) as Data)
        body.append(NSString(format:"\r\n").data(using: String.Encoding.utf8.rawValue)!)
        body.append(NSString(format:"--%@--\r\n",boundry).data(using: String.Encoding.utf8.rawValue)!)
        request.httpBody=body as Data
        mutableData = NSMutableData()
        conn = NSURLConnection(request:request as URLRequest, delegate: self)
        
        conn.schedule(in: RunLoop.main, forMode: RunLoopMode.defaultRunLoopMode)
        conn.start()
        
        
    }
    
    func cancelWebservice() ->Void{
        Busy = false;
        if ((mutableData) != nil){
            mutableData?.length=0;
            mutableData = nil;
        }
        if((conn) != nil){
            conn?.cancel()
            conn = nil;
        }
    }
    
    // MARK: -  Download support (NSURLConnectionDelegate)
    public func connection (_ connection: NSURLConnection,didReceive response: URLResponse)
    {
        expectedContentLength=response.expectedContentLength;
    }
    
    public func connection(_ connection: NSURLConnection, didReceive data: Data)
    {
        mutableData?.append(data as Data);
        let returnString=NSString(data: mutableData! as Data, encoding: String.Encoding.utf8.rawValue)
        print(returnString as Any)
    }
    
    public func connectionDidFinishLoading(_ connection: NSURLConnection)
    {
        Busy = false;
        var returnString=NSString(data: mutableData! as Data, encoding: String.Encoding.utf8.rawValue)
        returnString = returnString?.replacingOccurrences(of: "__u0022__", with: "''") as NSString?
        returnString = returnString?.replacingOccurrences(of: "__u0026__", with: "&") as NSString?
        returnString = returnString?.replacingOccurrences(of: "__u000a__", with: "\\n") as NSString?
        
        print("========")
        print(returnString as Any)
        print("========")
        var obj:AnyObject?
        let dict:  [String: Any]?
//        let dict:  [String: Any] = self.getJsonDictFromString(text: returnString! as String)! as [String: Any]
        obj = self.getJsonDictFromString(text: returnString! as String) as AnyObject?
        if(obj is Dictionary<String, Any>){
            //dict = (obj as! NSDictionary) as? [String : Any]
          dict = (obj as! NSDictionary).dictionaryByReplacingNullsWithBlanks() 
//            print("===================")
//            print(newDictData)
        }
        else{
            dict = Dictionary<String,Any>()

        }
      
        
//        let dictnew =  dict!.removeNullValueFromDic
        if ((mutableData) != nil){
            mutableData = nil;
            mutableData?.length=0;
        }
        if((conn) != nil){
            conn?.cancel()
            conn = nil;
        }
        responseSuccessful!(dict)
       
        if !(dict?.isEmpty)! {
            if dict?["status"] as! String == "5"{
                deActiveUserAccount(dictData: dict!)
            }
            if dict?["status"] as! String == "2" {
                selectCategory(dictData: dict!)
            }
        }
    }
    public func connection(_ connection: NSURLConnection, didSendBodyData bytesWritten: Int, totalBytesWritten : Int,
        totalBytesExpectedToWrite : Int){
        
        if (self.progressblock != nil) {
            let percent: Float = Float(totalBytesWritten) * 100.0 / Float(totalBytesExpectedToWrite)
            print("PER - \(percent)")
            self.progressblock!(percent)
        }
           
    }
     
    @nonobjc public func connection(connection: NSURLConnection, didFailWithError error: Error)
    {
        Busy = false;
        if ((mutableData) != nil){
            mutableData?.length=0;
            mutableData = nil;
        }
        if((conn) != nil){
            conn?.cancel()
            conn = nil;
        }
        responseFail!(error as NSError?)
        
    }
    
    // MARK: -  Custom Method for convert dictionary to string
    func getJsonDictFromString(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    func getJsonFromDictionary(dictData:NSDictionary)->NSString{
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: dictData, options: .prettyPrinted)
            
            if let json = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue) {
                return json
            }
            else
            {
               return "Not Found"
            }
            

        } catch {
            print(error.localizedDescription)
            return "Error"
        }
        
    }
    
    deinit {
        if ((mutableData) != nil){
            mutableData?.length=0;
            mutableData = nil;
        }
        if((conn) != nil){
            conn?.cancel()
            conn = nil;
        }
    }
    
    
    // MARK: -  Challange Method for Https
    public func connection(_ connection: NSURLConnection, didReceive challenge: URLAuthenticationChallenge) {
        if (challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust) {
            if ("www.estatemate.co.za" == challenge.protectionSpace.host) {
                challenge.sender?.use(URLCredential(trust: challenge.protectionSpace.serverTrust!), for: challenge)
            }
        }
        challenge.sender?.continueWithoutCredential(for: challenge)
    }
    
    public func connection(_ connection: NSURLConnection, canAuthenticateAgainstProtectionSpace protectionSpace: URLProtectionSpace) -> Bool {
        return (protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust)
    }
    
    //MARK:- Custom Methods
    func deActiveUserAccount(dictData : Dictionary<String,Any>) -> Void {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let userDefault = UserDefaults.standard
        appDelegate.hideMenu()
        
        if let dictBussiness = dictData["business_data"] {
            userDefault.set(dictBussiness, forKey: "business_data")
        }
        let dictData = dictData["user_data"] as! NSDictionary
        let dictMutable = NSMutableDictionary.init(dictionary: dictData)
        for (_, element) in dictMutable.allKeys.enumerated() {
            let tmpValue = dictMutable[element]
            if (tmpValue is NSNull) {
                dictMutable[element] = ""
            }
        }
        print(dictMutable)
        userDefault.set(dictMutable, forKey: "userData")
        userDefault.synchronize()
        
        let vcNav = appDelegate.window?.rootViewController as! UINavigationController
        let userDefaultNew = UserDefaults.standard.dictionaryRepresentation()
        if userDefaultNew.keys.contains("userData") {

                if (vcNav.visibleViewController?.isKind(of: BasicInformationViewController.self))!
                {
                    let vcBasic = vcNav.visibleViewController as! BasicInformationViewController
                    vcBasic.setActiveDeActiveData()
                }else{
                
                    let vcNav = appDelegate.window?.rootViewController as! UINavigationController
                    for (_,element) in vcNav.viewControllers.enumerated(){
                        if element.isKind(of: BasicInformationViewController.self) {
                            let vcBasic = element as! BasicInformationViewController
                           vcBasic.setActiveDeActiveData()
                            vcNav.setViewControllers([vcBasic], animated: false)
                           appDelegate.window?.rootViewController = vcNav
                            return
                        }
                    }
                    let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
                    let vcBasic = storyBoard.instantiateViewController(withIdentifier: "BasicInformationViewController") as! BasicInformationViewController
                    vcNav.setViewControllers([vcBasic], animated: false)
                    appDelegate.window?.rootViewController = vcNav
                }
        }
    }
    
      func selectCategory(dictData : Dictionary<String,Any>) -> Void {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.hideMenu()
        
        let vcNav = appDelegate.window?.rootViewController as! UINavigationController
        
            if (vcNav.visibleViewController?.isKind(of: CategoriesViewController.self))!
            {
                let vcCategories = vcNav.visibleViewController as! CategoriesViewController
                vcCategories.isNeedToSelect = true
            }
            else{
                let vcNav = appDelegate.window?.rootViewController as! UINavigationController
                for (_,element) in vcNav.viewControllers.enumerated(){
                    if element.isKind(of: CategoriesViewController.self) {
                        let vcCategories = element as! CategoriesViewController
                       vcCategories.isNeedToSelect = true
                        vcNav.setViewControllers([vcCategories], animated: false)
                        appDelegate.window?.rootViewController = vcNav
                        return
                    }
                }
                let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
                let vcCategories = storyBoard.instantiateViewController(withIdentifier: "CategoriesViewController") as! CategoriesViewController
                vcCategories.isNeedToSelect = true
              
                vcNav.viewControllers.append(vcCategories)
                appDelegate.window?.rootViewController = vcNav
            }
        }
}




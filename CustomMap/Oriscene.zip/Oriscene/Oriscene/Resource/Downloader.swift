//
//  Downloader.swift
//  Oriscene
//
//  Created by Parth on 23/12/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

import Foundation

class HttpDownloader {
    
    class func loadFileSync(url: NSURL, completion:(_ path:String, _ error:NSError?) -> Void) {
        let documentsUrl =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        let destinationUrl = documentsUrl?.appendingPathComponent(url.lastPathComponent!)
        if FileManager().fileExists(atPath: destinationUrl!.path) {
            print("file already exists [\(destinationUrl?.path)]")
            completion(destinationUrl!.path, nil)
        } else if let dataFromURL = NSData(contentsOf: url as URL){
            if dataFromURL.write(to: destinationUrl!, atomically: true) {
                print("file saved [\(destinationUrl?.path)]")
                completion(destinationUrl!.path, nil)
            } else {
                print("error saving file")
                let error = NSError(domain:"Error saving file", code:1001, userInfo:nil)
                completion(destinationUrl!.path, error)
            }
        } else {
            let error = NSError(domain:"Error downloading file", code:1002, userInfo:nil)
            completion(destinationUrl!.path, error)
        }
    }
    /*
    class func loadFileAsync(url: NSURL, completion:@escaping (_ path:String, _ error:NSError?) -> Void) {
        let documentsUrl =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first as! NSURL
        let destinationUrl = documentsUrl.appendingPathComponent(url.lastPathComponent!)
        if FileManager().fileExists(atPath: destinationUrl!.path) {
            print("file already exists [\(destinationUrl?.path)]")
            completion(destinationUrl!.path, nil)
        } else {
            let sessionConfig = URLSessionConfiguration.default
            let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
            let request = NSMutableURLRequest(url: url as URL)
            request.httpMethod = "GET"
            
            let task = session.dataTask(with: request as URLRequest, completionHandler: { ( data, response , error ) in
                
                if (error == nil) {
                    if let response = response as? HTTPURLResponse {
                        print("response=\(response)")
                        if response.statusCode == 200 {
                            
                            let dataNew = data! as Data
                            
                            do {
                                if try dataNew.write(to: destinationUrl!) == true {
                                    completion(destinationUrl!.path, error as NSError?)
                                }
                                else{
                                    let error = NSError(domain:"Error saving file", code:1001, userInfo:nil)
                                    completion(destinationUrl!.path, error as NSError?)
                                }
                            }
                            catch{
                                completion(destinationUrl!.path, error as NSError?)
                            }
//                            if dataNew.writeToURL(destinationUrl, atomically: true) {
//                                print("file saved [\(destinationUrl?.path)]")
//                                completion(destinationUrl!.path, error as NSError?)
//                            } else {
//                                print("error saving file")
//                                let error = NSError(domain:"Error saving file", code:1001, userInfo:nil)
//                                completion(destinationUrl!.path, error)
//                            }
                        }
                    }
                }
                else {
                    print("Failure: \(error?.localizedDescription)");
                    completion(destinationUrl!.path, error as NSError?)
                }
            })
            task.resume()
        }
    }*/
}

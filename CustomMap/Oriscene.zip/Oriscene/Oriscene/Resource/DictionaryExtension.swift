//
//  DictionaryExtension.swift
//  Oriscene
//
//  Created by Tristate on 13/01/17.
//  Copyright © 2017 Tristate. All rights reserved.
//

import Foundation
 extension NSDictionary {
    
    func dictionaryByReplacingNullsWithBlanks() -> [String : AnyObject] {
        var replaced :  [String: Any] = (self as? [String : Any])!
        let nul : AnyObject = NSNull()
        let blank = ""
//        print(self)
    for (key,value) in self {
        
        if  value as AnyObject? === nul {
            replaced[key as! String] =  blank
        }
        else if value is [String : AnyObject] {
            replaced[key as! String] = (value as AnyObject).dictionaryByReplacingNullsWithBlanks()
        }
        else if value is [AnyObject] {
            replaced[key as! String] = (value as! NSArray).arrayByReplacingNullsWithBlanks()
        }
            
        }
        return replaced as [String : AnyObject]
    }
}

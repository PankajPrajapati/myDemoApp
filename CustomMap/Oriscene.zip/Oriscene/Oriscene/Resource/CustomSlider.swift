//
//  CustomSlider.swift
//  Oriscene
//
//  Created by Tristate on 12/24/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class CustomSlider: UISlider {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    */
    override func draw(_ rect: CGRect) {
        self.thumbTintColor = UIColor.clear
    }
    override func trackRect(forBounds bounds: CGRect) -> CGRect {
       let rect:CGRect = CGRect (x:0, y: 12, width:self.frame.width, height: 5)
        return rect
    }
}

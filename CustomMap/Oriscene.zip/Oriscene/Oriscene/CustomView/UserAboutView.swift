//
//  UserAboutView.swift
//  Oriscene
//
//  Created by Parth on 28/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol UserAboutViewDelegate {
    func hideUserAboutView() -> Void
}

class UserAboutView: UIView {

    var delegate : UserAboutViewDelegate?
    
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var txtViewAboutUs: UITextView!
    @IBOutlet var viewContainer: UIView!
    
    @IBOutlet var btnClose: UIButton!
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "UserAboutView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        btnClose.isHidden = true
        
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        viewContainer.layer.borderWidth = 1.0
        viewContainer.layer.borderColor = UIColor.lightGray.cgColor
    }
    
    @IBAction func btnCloseAction(_ sender: Any) {
        delegate?.hideUserAboutView()
    }
    @IBAction func btnHideUserAboutViewAction(_ sender: Any) {
        delegate?.hideUserAboutView()
    }

}

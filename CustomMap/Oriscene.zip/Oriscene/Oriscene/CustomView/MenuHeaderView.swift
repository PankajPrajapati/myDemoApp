//
//  MenuHeaderView.swift
//  Oriscene
//
//  Created by Parth on 10/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol MenuHederViewDelegate {
    func EditProfileDetailClicked ()
}

class MenuHeaderView: UIView {
    
    var delegate : MenuHederViewDelegate?
    
    @IBOutlet var viewLayer1: UIView!
    @IBOutlet var viewLayer2: UIView!
    
    @IBOutlet var imgProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var btnEditProfileDetail: UIButton!
    
    @IBAction func btnEditProfileDetailAction(_ sender: AnyObject) {
        delegate?.EditProfileDetailClicked()
    }
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "MenuHeaderView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
//        self.layoutIfNeeded()
        imgProfilePic.layoutIfNeeded()
        imgProfilePic.layer.cornerRadius = imgProfilePic.frame.size.height/2
        imgProfilePic.layer.masksToBounds = true
//        imgProfilePic.layoutIfNeeded()
        
        btnEditProfileDetail.layer.cornerRadius = btnEditProfileDetail.frame.size.height/2
        btnEditProfileDetail.layer.masksToBounds = true
        btnEditProfileDetail.layer.borderColor = UIColor.lightGray.cgColor
        btnEditProfileDetail.layer.borderWidth = 1.0
        
        viewLayer1.layer.cornerRadius = viewLayer1.frame.size.height/2
        viewLayer1.layer.masksToBounds = true
        
        viewLayer2.layer.cornerRadius = viewLayer2.frame.size.height/2
        viewLayer2.layer.masksToBounds = true
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(btnEditProfileDetailAction(_:)))
        tap.numberOfTapsRequired = 1
        self.isUserInteractionEnabled = true
        self.addGestureRecognizer(tap)
    }
}

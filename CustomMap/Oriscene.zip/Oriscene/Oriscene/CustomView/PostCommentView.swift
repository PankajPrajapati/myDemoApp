//
//  PostCommentView.swift
//  Oriscene
//
//  Created by Parth on 11/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol PostCommentViewDelegate {
//    func btnCloseCommentClicked() -> Void
    func btnCloseCommentClickedWithData(index: NSInteger,dictComment : Dictionary<String,Any>) -> Void
}

class PostCommentView: ViewsBaseView,UITableViewDelegate,UITableViewDataSource, PostCommentDelegate, UITextViewDelegate, PostCommentSectionViewDelegate, CommentEditViewDelegate, PostCommentReplyDelegate ,UIAlertViewDelegate {
    
    
    
    var delegate : PostCommentViewDelegate?
    var intSelectedRowForComment : NSInteger = -1
    var intSelectedSectionForComment : NSInteger = -1
    let service = WebService()
    var arrComment = [Dictionary<String,Any>]()
    var arrReply = [Dictionary<String,Any>]()
    var dictPostData = Dictionary<String,Any>()
    
    var viewCommentEdit : CommentEditView? = nil
    var iDeleteIndex = NSInteger()
    var index = NSInteger()
    var textviewCheck: NSInteger = 0
    @IBOutlet var viewHeaderComment: UIView!
    @IBOutlet var tblComments: UITableView!
    @IBOutlet var viewWriteCommentContainer: UIView!
    @IBOutlet var btnSendComment: UIButton!
    @IBOutlet var txtViewWriteComment: UITextView!
    @IBOutlet var lblComment: UILabel!
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var viewShadowOfWriteCommentContainer: UIView!
    
    @IBOutlet var bottomConstContainerView: NSLayoutConstraint!
    @IBOutlet var heightConstViewWriteCommentContainer: NSLayoutConstraint!
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "PostCommentView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        tblComments.register(PostCommentTVCell.self, forCellReuseIdentifier: "PostCommentTVCell")
        tblComments.register(UINib.init(nibName: "PostCommentTVCell", bundle: nil), forCellReuseIdentifier: "PostCommentTVCell")
        
        tblComments.register(PostCommentTVCell.self, forCellReuseIdentifier: "PostCommentTVCell")
        tblComments.register(UINib.init(nibName: "PostCommentTVCell", bundle: nil), forCellReuseIdentifier: "PostCommentTVCell")
        
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        
        btnSendComment.layer.cornerRadius = btnSendComment.frame.size.height / 2
        btnSendComment.layer.masksToBounds = true
        
        viewShadowOfWriteCommentContainer.layer.shadowColor = UIColor.lightGray.cgColor
        viewShadowOfWriteCommentContainer.layer.shadowOpacity = 1
        viewShadowOfWriteCommentContainer.layer.shadowOffset = CGSize.zero
        viewShadowOfWriteCommentContainer.layer.shadowRadius = 10
        
        txtViewWriteComment.contentInset = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)
        
        tblComments.reloadData()
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
        
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func layoutSubviews() {
        tblComments.register(PostCommentReplyTVCell.self, forCellReuseIdentifier: "PostCommentReplyTVCell")
        tblComments.register(UINib.init(nibName: "PostCommentReplyTVCell", bundle: nil), forCellReuseIdentifier: "PostCommentReplyTVCell")
    }
    // MARK: - SetUp Data Method
    func setCommentData() -> Void {
        //   callWebserviceViewCommentsSharePost(dictParam: )
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
//            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
//                self.bottomConstContainerView?.constant = 100.0
//                //                self.scrollView.setContentOffset(CGPoint(x: 0.0, y: 0.0), animated: true)
//            } else {
//                self.bottomConstContainerView?.constant = endFrame?.size.height ?? 0.0
//            }
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.viewWriteCommentContainer.isHidden = false
                self.viewShadowOfWriteCommentContainer.isHidden = false
                self.bottomConstContainerView?.constant = 100.0
                
            } else {
                if textviewCheck == 1 {
                    self.viewWriteCommentContainer.isHidden = false
                    self.viewShadowOfWriteCommentContainer.isHidden = false
                    self.bottomConstContainerView?.constant = endFrame?.size.height ?? 0.0
                    
                } else {
                    self.viewWriteCommentContainer.isHidden = true
                    self.viewShadowOfWriteCommentContainer.isHidden = true
                    self.bottomConstContainerView?.constant = endFrame?.size.height ?? 0.0
                }
            }

           
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - UITableView DataSource
    /*
     func numberOfSections(in tableView: UITableView) -> Int {
     return 10
     }
     
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     if intSelectedSectionForComment == section {
     return 10
     }
     else{
     return 0
     }
     }
     
     func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
     let viewCommentSectionView = PostCommentSectionView.instanceFromNib() as! PostCommentSectionView
     viewCommentSectionView.lblComment.text = "Header"
     viewCommentSectionView.index = section
     viewCommentSectionView.delegate = self
     
     if section == intSelectedSectionForComment {
     viewCommentSectionView.viewReplyContainer.isHidden = false
     }
     else{
     viewCommentSectionView.viewReplyContainer.isHidden = true
     }
     
     viewCommentSectionView.txtViewReply.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
     viewCommentSectionView.txtViewReply.layer.borderWidth = 1.0
     viewCommentSectionView.txtViewReply.layer.cornerRadius = 3.0
     viewCommentSectionView.txtViewReply.layer.masksToBounds = true
     
     viewCommentSectionView.lblComment.text = "Nice Photo!"
     
     return viewCommentSectionView
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView .dequeueReusableCell(withIdentifier: "PostCommentReplyTVCell") as! PostCommentReplyTVCell
     cell.index = indexPath.row
     cell.lblComment.text = "Nice Photo!"
     return cell
     }
     
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
     //        if indexPath.row == intSelectedRowForComment {
     //            return 120.0
     //        }
     //        else{
     return 65.0
     //        }
     }
     
     func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
     if section == intSelectedSectionForComment {
     return 120.0
     }
     else{
     return 90.0
     }
     //        return UITableViewAutomaticDimension
     }
     
     //    func tableView(_ tableView: UITableView, estimatedHeightForHeaderInSection section: Int) -> CGFloat {
     //        return 120.0
     //    }
     
     func tableView(_ tableView: UITableView, estimatedHeightForFooterInSection section: Int) -> CGFloat {
     return 0.0
     }
     
     // MARK: - UITableView Delegate
     
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     
     }
     */
    
    
    // MARK: - UITableView DataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.arrComment.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if intSelectedSectionForComment == section {
            let dictComment = arrComment[section]
            arrReply = dictComment["reply_arr"] as! [Dictionary<String,Any>]
            return arrReply.count
        }
        else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let viewCommentSectionView = PostCommentSectionView.instanceFromNib() as! PostCommentSectionView
        viewCommentSectionView.lblComment.text = "Header"
        viewCommentSectionView.index = section
        viewCommentSectionView.delegate = self
        
        if section == intSelectedSectionForComment {
            viewCommentSectionView.viewReplyContainer.isHidden = false
        }
        else{
            viewCommentSectionView.viewReplyContainer.isHidden = true
        }
        
        viewCommentSectionView.txtViewReply.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        viewCommentSectionView.txtViewReply.layer.borderWidth = 1.0
        viewCommentSectionView.txtViewReply.layer.cornerRadius = 3.0
        viewCommentSectionView.txtViewReply.layer.masksToBounds = true
        
        let dictComment = arrComment[section] as Dictionary<String,Any>
        viewCommentSectionView.lblUserName.text = dictComment["name"] as! String?
        viewCommentSectionView.lblComment.text = dictComment["comment"] as! String?
        
        viewCommentSectionView.lblComment.sizeToFit()
        print("=================")
        print(dictComment)
        print("=================")
        var reply = "\(dictComment["replies_count"] as! String)"
        if reply.characters.count > 0  && reply != "0" {
            reply = "reply" + "(\(reply))"
        } else {
            reply = "reply"
        }
        
        if let keyEditAllow = dictComment["edit_delete_allow"]  {
            
            if  keyEditAllow as! String == "1" {
                viewCommentSectionView.btnEdit.isHidden = false;
                viewCommentSectionView.btnDelete.isHidden = false;
            }
            else{
                viewCommentSectionView.btnEdit.isHidden = true;
                viewCommentSectionView.btnDelete.isHidden = true;
            }
        }
        else{
            viewCommentSectionView.btnEdit.isHidden = true;
            viewCommentSectionView.btnDelete.isHidden = true;
        }
        if let strDate = dictComment["commented_date"] {
            viewCommentSectionView.lblTime.text = convertStringToDate(strDate: strDate as! String)
        }else{
            viewCommentSectionView.lblTime.text = ""
        }
        viewCommentSectionView.btnReply.setTitle( reply , for: .normal )
        
        let dictUserData = dictComment["user_data"] as! Dictionary<String,Any>
        if dictUserData.keys.contains("photo") {
            let strPhotoName = dictUserData["photo"] as! String
            if strPhotoName.characters.count != 0 {
                let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                let fileUrl = NSURL(string: strUrl)
                
                viewCommentSectionView.imgUserProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                    if error != nil {
                        print("Failed: \(error)")
                    } else {
                        print("Success")
                    }
                }
            }
            else{
                viewCommentSectionView.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        else{
            viewCommentSectionView.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
        }
        
        return viewCommentSectionView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "PostCommentReplyTVCell") as! PostCommentReplyTVCell
        let dictReply = arrReply[indexPath.row]
        cell.index = indexPath.row
        cell.delegate = self
        cell.lblUserName.text = dictReply["name"] as! String?
        cell.lblComment.text = dictReply["reply"] as! String?
        print("=================")
        print(dictReply)
        print("=================")
        if let keyEditAllow = dictReply["edit_delete_allow"]  {
            
            if  keyEditAllow as! String == "1" {
                cell.btnEdit.isHidden = false;
                cell.btnDelete.isHidden = false;
                cell.heightConstEditDeleteButton.constant = 31.0
            }
            else{
                cell.btnEdit.isHidden = true;
                cell.btnDelete.isHidden = true;
                cell.heightConstEditDeleteButton.constant = 0.0
            }
        }
        else{
            cell.btnEdit.isHidden = true;
            cell.btnDelete.isHidden = true;
            cell.heightConstEditDeleteButton.constant = 0.0
        }
        
        if let strDate = dictReply["reply_date"] {
            cell.lblTime.text = convertStringToDate(strDate: strDate as! String)
        }else{
            cell.lblTime.text = ""
        }
        
        let dictUserData = dictReply["user_data"] as! Dictionary<String,Any>
        if dictUserData.keys.contains("photo") {
            let strPhotoName = dictUserData["photo"] as! String
            if strPhotoName.characters.count != 0 {
                let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                let fileUrl = NSURL(string: strUrl)
                
                cell.imgUserProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                    if error != nil {
                        print("Failed: \(error)")
                    } else {
                        print("Success")
                    }
                }
            }
            else{
                cell.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        else{
            cell.imgUserProfilePic.image = #imageLiteral(resourceName: "default_img")
        }
        cell.contentView.setNeedsLayout()
        cell.contentView.layoutIfNeeded()
        
        return cell
    }
    
    //    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    ////        if indexPath.row == intSelectedRowForComment {
    ////            return 120.0
    ////        }
    ////        else{
    //            return 65.0
    ////        }
    //    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        let dictComment = arrComment[section] as Dictionary<String,Any>
        let height = self.tableSectionHeightCelculate(widths: tableView.frame.size.width - 54, strText: dictComment["comment"] as! String)
        
        if section == intSelectedSectionForComment {
            return 116 + height
        }
        else{
            return 86 + height
        }
        //        return UITableViewAutomaticDimension
    }
    func tableSectionHeightCelculate(widths : CGFloat,strText : String) -> CGFloat {
        
        let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: widths, height: 0))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = UIFont.init(name: "HelveticaNeueCyr-Light_0", size: 14)
        label.text = strText
        label.sizeToFit()
        var labelHeight = self.lines(yourLabel: label)
        labelHeight = labelHeight * 13
        return CGFloat(labelHeight)
    }
    func lines(yourLabel:UILabel) -> Int{
        var lineCount = 0;
        let textSize = CGSize(width: yourLabel.frame.size.width, height: CGFloat(Float.infinity));
        let rHeight = lroundf(Float(yourLabel.sizeThatFits(textSize).height))
        let charSize = lroundf(Float(yourLabel.font.lineHeight));
        lineCount = rHeight/charSize
        return lineCount
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    //    func tableView(_ tableView: UITableView, estimatedHeightForHeaderInSection section: Int) -> CGFloat {
    //        return 120.0
    //    }
    func tableView(_ tableView: UITableView, estimatedHeightForFooterInSection section: Int) -> CGFloat {
        return 0.0
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    
    
    
    // MARK: - Action Method
//    @IBAction func btnCloseCommentAction(_ sender: AnyObject) {
//        delegate?.btnCloseCommentClicked()
//        perform(#selector(resetCommentView), with: nil, afterDelay: 0.2)
//
////        var arrPostAction = [Dictionary<String,Any>]()
////        arrPostAction = dictPostData["arrPostAction"] as! [Dictionary<String, Any>]
////        for (index, var dictPost) in arrPostAction.enumerated() {
////            
////            if dictPost.keys.contains("comment_count") {
////                let newCount : String = String (arrComment.count)
////                dictPost["comment_count"] = newCount
////                print("==============+++++==========")
////                print(newCount)
////                arrPostAction[index] = dictPost
////                print("==============+++++==========")
////                print(arrPostAction)
////            }
////        }
////        dictPostData["arrPostAction"] = arrPostAction
////        
////        delegate?.btnCloseCommentClickedWithData(index: index, dictComment: dictPostData)
//        
//    }
    @IBAction func btnCloseCommentAction(_ sender: AnyObject) {
        //delegate?.btnCloseCommentClicked()
        var arrPostAction = [Dictionary<String,Any>]()
        arrPostAction = dictPostData["arrPostAction"] as! [Dictionary<String, Any>]
        for (index, var dictPost) in arrPostAction.enumerated() {
            
            if dictPost.keys.contains("comment_count") {
                let newCount  =  arrComment.count
                dictPost["comment_count"] = newCount
                print("==============+++++==========")
                print(newCount)
                arrPostAction[index] = dictPost
                print("==============+++++==========")
                print(arrPostAction)
            }
        }
        dictPostData["arrPostAction"] = arrPostAction
        
        delegate?.btnCloseCommentClickedWithData(index: index, dictComment: dictPostData)
        perform(#selector(resetCommentView), with: nil, afterDelay: 0.2)
        
    }
    @IBAction func btnSendCommentAction(_ sender: AnyObject) {
//        self.endEditing(true)
        self.endEditing(true)
        if self.txtViewWriteComment.text == "Write your comment" || self.txtViewWriteComment.text == ""{
            return
        }
        
        let dictParam = NSMutableDictionary()
        let dictPostDtlIndividual = dictPostData["postdetailindiv"] as! Dictionary<String,Any>
        dictParam["postId"] = dictPostDtlIndividual["post_id"] as! String;
        
        dictParam["comment"] = txtViewWriteComment.text
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertComment", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        self.txtViewWriteComment.text = "Write your comment"
                        self.txtViewWriteComment.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
//                        self.callWebserviceViewCommentsSharePost()
                        
                        let dictComment = dict?["data"] as! Dictionary<String,Any>
                        self.arrComment.insert(dictComment, at: 0)
                        self.tblComments.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    // MARK: - PostCommentReplyDelegate
    
    func btnCommentReplyClicked(index: NSInteger) {
        intSelectedRowForComment = index
        tblComments.reloadData()
    }
    
    func btnSubmitReplyClicked(index: NSInteger) {
        intSelectedRowForComment = -1
        let indexPath = IndexPath.init(row: index, section: 0) as IndexPath
        tblComments.reloadRows(at: [indexPath], with: UITableViewRowAnimation.fade)
        self.endEditing(true)
    }
    
    func btnEditReplyClicked(index: NSInteger) {
        let dictComment = arrReply[index] as Dictionary<String,Any>
        
        self.viewCommentEdit?.dictCommentData = dictComment
        self.viewCommentEdit?.index = index
        self.viewCommentEdit?.isSectionEdit = false
        self.viewCommentEdit?.displayCommentForReply()
        self.viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewCommentEdit?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewCommentEdit?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    func btnDeleteReplyClicked(index: NSInteger) {
        //call delete webservice for replyDelete and reload data
        self.endEditing(true)
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Sure want to delete reply?", delegate:self, cancelButtonTitle: "No")
        alertWarning.addButton(withTitle: "Yes")
        alertWarning.tag = 2
        iDeleteIndex = index
        alertWarning.show()
    }
    
    // MARK: - PostCommentSectionViewDelegate
    
    func btnCommentSectionViewReplyClicked(index: NSInteger) {
        self.endEditing(true)
        intSelectedSectionForComment = index
        tblComments.reloadData()
    }
    
    func btnSubmitSectionViewReplyClicked(index: NSInteger, strReply: String) {
        self.endEditing(true)
        if strReply == "Your Reply" || strReply == ""{
            return
        }

        let dictComment = arrComment[index] as Dictionary<String,Any>
        
        let dictParam = NSMutableDictionary()
        dictParam["postId"] = dictComment["post_id"] as! String;
        dictParam["comId"] = dictComment["com_id"] as! String;
        dictParam["reply"] = strReply
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
        dictParam["userId"] = dictUser["reporter_id"] as? String
        
        
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "insertReply", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        //                       self.commentWebservieccall()
                        
                        let dictComment = dict?["data"] as! Dictionary<String,Any>
                        self.arrReply = dictComment["reply_arr"] as! [Dictionary<String,Any>]
                        self.arrComment[index] = dictComment
                        self.tblComments.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
        
    }
    
    func btnCommentSectionDeleteClicked(index: NSInteger) {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Sure want to delete comment?", delegate:self, cancelButtonTitle: "No")
        alertWarning.addButton(withTitle: "Yes")
        alertWarning.tag = 1
        iDeleteIndex = index
        alertWarning.show()
    }
    func btnCommentSectionEditClicked(index: NSInteger) {
        
        self.viewCommentEdit?.dictCommentData =  arrComment[index] as Dictionary<String,Any>
        self.viewCommentEdit?.index = index
        self.viewCommentEdit?.isSectionEdit = true
        self.viewCommentEdit?.displayCommentForSection()
        self.viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.0, animations: {() -> Void in
            self.viewCommentEdit?.alpha = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.viewCommentEdit?.alpha = 1.0
            }, completion: { _ in })
        })
    }
    
    
    // MARK: - CommentEdit Delegate
    func hideCommentEditView() {
        viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewCommentEdit?.alpha = 0.0
        }) { (Bool) in
            self.viewCommentEdit?.isHidden = true
        }
    }
    
    func saveSectionCommentEditView(sectionIndex : NSInteger,dictComment : Dictionary<String,Any>) -> Void {
        
        viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewCommentEdit?.alpha = 0.0
        }) { (Bool) in
            self.viewCommentEdit?.isHidden = true
        }
        arrComment[sectionIndex] = dictComment
        //reload section if needed
        tblComments.reloadData()
        
    }
    
    func saveReplyCommentEditView(cellIndex : NSInteger,dictComment : Dictionary<String,Any>) -> Void{
        viewCommentEdit?.isHidden = false
        
        UIView.animate(withDuration: 0.3, animations: {
            self.viewCommentEdit?.alpha = 0.0
        }) { (Bool) in
            self.viewCommentEdit?.isHidden = true
        }
        arrReply[cellIndex] = dictComment
        var dictComment = arrComment[intSelectedSectionForComment]
        dictComment["reply_arr"] = arrReply
        arrComment[intSelectedSectionForComment] = dictComment
        
        //reload section if needed
        tblComments.reloadData()
    }
    
    
    // MARK: - UITextViewDelegate
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        
        let length = textView.text.characters.count as Int
        
        if length > 0 {
            lblComment.text = textView.text
            textView.textColor = UIColor.black
        }
        else{
            lblComment.text = "Hi"
            textView.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        }
    }
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        textviewCheck = 1
        if textView.text == "Write your comment" {
            textView.text = ""
            textView.textColor = UIColor.black
        }
        let length = textView.text.characters.count as Int
        if length > 0 {
            lblComment.text = textView.text
        }
        else{
            lblComment.text = "Hi"
        }
        //        lblComment.text = txtViewWriteComment.text
        return true
    }
    func textFieldReplyShouldBeginEditing(_ textField: UITextField) -> Bool{
        textviewCheck = 0
        return true
    }
    func textFieldReplyShouldEndEditing(_ textField: UITextField) -> Bool{
        
        return true
    }
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        
        if textView.text.characters.count>0 {
            textView.textColor = UIColor.black
        }
        else{
            textView.text = "Write your comment"
            textView.textColor = UIColor.init(red: 122.0/255.0, green: 126.0/255.0, blue: 134.0/255.0, alpha: 1.0)
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        
    }
    
    
    //MARK:- AlertView Delegate Method
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if buttonIndex == 0 {
            //No
            
        }
        else{
            //yes
            self.endEditing(true)
            if alertView.tag == 1 {
                callWebserviceDeleteSectionCommentPost(index:iDeleteIndex)
            }
            else {
                callWebserviceDeleteReplyCommentPost(index:iDeleteIndex)
            }
        }
    }
    
    // MARK: - Custom Method
    
    func reloadComments() -> Void {
        print(dictPostData)
        if viewCommentEdit == nil {
            viewCommentEdit = CommentEditView.instanceFromNib() as? CommentEditView
            viewCommentEdit?.frame = UIScreen.main.bounds
            viewCommentEdit?.isHidden = true
            viewCommentEdit?.delegate = self
            viewCommentEdit?.alpha = 0.0
            self.addSubview(viewCommentEdit!)
        }
        callWebserviceViewCommentsSharePost()
    }
    
    func resetCommentView() -> Void {
        if arrComment.count > 0 {
            arrComment.removeAll()
        }
        tblComments.reloadData()
    }
    
    func lineCount(for label: UITextView) -> Int {
        let labelWidth: CGFloat = label.frame.size.width
        var lineCount = 0
        let textSize = CGSize(width: labelWidth, height: CGFloat(MAXFLOAT))
        let rHeight = lroundf(Float(label.sizeThatFits(textSize).height))
        lineCount = Int(rHeight / 15)
        return lineCount
    }
    
    //MARK:- Date Function
    func convertStringToDate(strDate : String) -> String {
        
        let dateFormater = DateFormatter()
//        dateFormater.timeZone = TimeZone.current
        
        dateFormater.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let newDate  =  dateFormater.date(from: strDate)
        dateFormater.locale = Locale.init(identifier: "en_US")
        dateFormater.dateFormat = "MMM dd, yyyy HH:mm a"
        let strNewDate = dateFormater.string(from: newDate!)
        
        return strNewDate
    }
    
    
    //MARK:- Webservice Method
    //MARK:- Webservice Method
    func callWebserviceViewCommentsSharePost() -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            let dictPostDtlIndividual = dictPostData["postdetailindiv"] as! Dictionary<String,Any>
            let strPostId = dictPostDtlIndividual["post_id"] as! String
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = strPostId
            dictParam["type"] = "view"
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            service.callJSONMethod(methodName: "viewTheComment", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        var arrComment = [Dictionary<String,Any>]()
                        arrComment = dict?["data"] as! [Dictionary<String,Any>]
                        print(arrComment.count)
                        print(arrComment)
                        
                        self.intSelectedRowForComment = -1
                        self.intSelectedSectionForComment = -1
                        self.arrComment = arrComment
                        self.tblComments.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceDeleteSectionCommentPost(index: NSInteger) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            let dictComment = arrComment[index] as Dictionary<String,Any>
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            let dictParam = NSMutableDictionary()
            
            dictParam["forEdite"] = "0"
            dictParam["comment"] = ""
            
            dictParam["comId"] = dictComment["com_id"]
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            
            //{"method_name":"editDeleteComment","body":{"forEdit":"","comment":"","comId":"","userId":""}}
            
            service.callJSONMethod(methodName: "editDeleteComment", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        self.intSelectedRowForComment = -1
                        self.intSelectedSectionForComment = -1
                        self.arrComment.remove(at: index)
                        self.tblComments.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    
    func callWebserviceDeleteReplyCommentPost(index: NSInteger) -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            let dictReply = arrReply[index] as Dictionary<String,Any>
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            let dictParam = NSMutableDictionary()
            dictParam["forEdit"] = "0"
            dictParam["reply"] = ""
            
            dictParam["comId"] = dictReply["com_id"]
            dictParam["repId"] = dictReply["rep_id"]
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            //{"method_name":"editDeleteReply","body":{"forEdit":"","reply":"","comId":"","repId":"","userId":""}}
            
            service.callJSONMethod(methodName: "editDeleteReply", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        
                        self.arrReply.remove(at: index)
                        
                        var dictComment = self.arrComment[self.intSelectedSectionForComment]
                        dictComment["reply_arr"] = self.arrReply
                        
                        var reply : Int = Int("\(dictComment["replies_count"]!)")!
                        reply = reply - 1
                        let strReply :String = String(describing: reply)
                        dictComment["replies_count"] = strReply
                        self.arrComment[self.intSelectedSectionForComment] = dictComment
                        
                        self.tblComments.reloadData()
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
}

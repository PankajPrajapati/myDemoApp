//
//  CategorySectionHeader.swift
//  Oriscene
//
//  Created by Parth on 29/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol CategorySectionHeaderDelegate {
    
    func btnExpnandColspanClicked(index: NSInteger) -> Void    
    func btnSelectCategoryClicked(index: NSInteger) -> Void

}

class CategorySectionHeader: UIView {

    var delegate : CategorySectionHeaderDelegate?
    var index : NSInteger = -1
    
    @IBOutlet var lblCategoryTitle: UILabel!
    @IBOutlet var btnSelect: UIButton!
    @IBOutlet var btnExpand: UIButton!
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "CategorySectionHeader", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    @IBAction func btnSelectAction(_ sender: Any) {
        delegate?.btnSelectCategoryClicked(index: index)
    }
    @IBAction func btnExpandColspanAction(_ sender: Any) {
        delegate?.btnExpnandColspanClicked(index: index)
    }
}

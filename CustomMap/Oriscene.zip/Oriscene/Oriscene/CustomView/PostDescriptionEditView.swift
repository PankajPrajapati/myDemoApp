//
//  PostDescriptionEditView.swift
//  Oriscene
//
//  Created by Tristate on 12/30/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol PostDescriptionEditViewDelegate {
    func hideDescriptionEditView() -> Void
    func savePostDescriptionEditView(indexOfPost : NSInteger, dictComment : Dictionary<String,Any>) -> Void
}

class PostDescriptionEditView: ViewsBaseView, UITextFieldDelegate {

   // @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var textViewContainer: UIView!
    @IBOutlet weak var btnBottomConstCommentEditView: NSLayoutConstraint!
    
    @IBOutlet weak var txtDescription: UITextField!
    var delegate : PostDescriptionEditViewDelegate?
    var dictPostData = Dictionary<String,Any>()
    var service = WebService()
    var index = NSInteger()
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    
    */
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "PostDescriptionEditView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        
        textViewContainer.layer.cornerRadius = 3.0
        textViewContainer.layer.masksToBounds = true
        textViewContainer.layer.borderWidth = 1.0
        textViewContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.btnBottomConstCommentEditView?.constant = 0.0
            } else {
                self.btnBottomConstCommentEditView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
     // MARK: - Button Click Action
    
    @IBAction func btnCloseClickAction(_ sender: Any) {
        self.endEditing(true)
        self.delegate?.hideDescriptionEditView()
    }
   
    @IBAction func btnSaveClickAction(_ sender: Any) {
        self.endEditing(true)
        //call description update webservice here
        if txtDescription.text != "" {
            callWebserviceEditPost()
        }
    }
    
    // MARK: - Custom Methods 
    
    func displayDescription() -> Void {
//        print("================")
//        print(dictPostData)
        print("================='")
        let dictPostDtlIndividual = dictPostData["postdetailindiv"] as! Dictionary<String,Any>
        txtDescription.text =  dictPostDtlIndividual["post_content"] as? String
    }
    
 // MARK: - Textfield Delegate Methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    //MARK:- Webservice Method
    func callWebserviceEditPost() -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            let dictPostDtlIndividual = dictPostData["postdetailindiv"] as! Dictionary<String,Any>
            let strPostId = dictPostDtlIndividual["post_id"] as! String
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
//            {"method_name":"editPost","body":{"postId":"","shareId":"","postType":"","contText":"","loggedUser":"","attType":""}}
            
            let dictParam = NSMutableDictionary()
            dictParam["postId"] = strPostId
            dictParam["loggedUser"] = dictUser["reporter_id"] as? String
            dictParam["shareId"] = dictPostData["share_id"] as? String
            dictParam["postType"] = dictPostDtlIndividual["post_type"] as! String
            dictParam["contText"] = txtDescription.text
            dictParam["attType"] = dictPostDtlIndividual["att_type"] as! String
            
            service.callJSONMethod(methodName: "editPost", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        print("===============")
                        print(dict!)
                        var dictPostDtlIndividual = self.dictPostData["postdetailindiv"] as! Dictionary<String,Any>
                       dictPostDtlIndividual["post_content"] = self.txtDescription.text
                        self.dictPostData["postdetailindiv"] = dictPostDtlIndividual
                        self.delegate?.savePostDescriptionEditView(indexOfPost: self.index, dictComment: self.dictPostData)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }

    
}

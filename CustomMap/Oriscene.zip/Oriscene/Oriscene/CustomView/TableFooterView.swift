//
//  TableFooterView.swift
//  Oriscene
//
//  Created by Tristate on 12/26/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class TableFooterView: UIView {

    @IBOutlet weak var indicator: UIActivityIndicatorView!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "TableFooterView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }

}

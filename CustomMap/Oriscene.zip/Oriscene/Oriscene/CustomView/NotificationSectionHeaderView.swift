//
//  NotificationSectionHeaderView.swift
//  Oriscene
//
//  Created by Parth on 11/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class NotificationSectionHeaderView: UIView {

    @IBOutlet var lblHeaderTitle: UILabel!
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "NotificationSectionHeaderView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}

//
//  PostShareView.swift
//  Oriscene
//
//  Created by Parth on 24/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

extension UIToolbar {
    
    func ToolbarPikerWallet(mySelect : Selector) -> UIToolbar {
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.barTintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        doneButton.tintColor = UIColor.white
        //        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        return toolBar
    }
    
}

protocol WalletPopupDelegate {
    func hideWalletPopupView() -> Void
    func btnAddmoneyClicked(strAmount : String)
}

class WalletPopupView: ViewsBaseView, UITextFieldDelegate {

    var delegate : WalletPopupDelegate?
    var index : NSInteger = -1
    
    
    
    @IBOutlet var viewWalletPopupContainer: UIView!
     @IBOutlet var lblTitle: UILabel!
     @IBOutlet var btnClose: UIButton!
    
    
    @IBOutlet var viewAmountContainer: UIView!
    @IBOutlet var btnAddmoney: UIButton!
    @IBOutlet var txtAmount: UITextField!
    
    @IBOutlet var bottomConstWalletPopView: NSLayoutConstraint!
   
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "WalletPopupView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        let toolBar = UIToolbar().ToolbarPikerAmount(mySelect: #selector(self.dismissPicker))
        txtAmount.inputAccessoryView = toolBar
        
        viewWalletPopupContainer.layer.cornerRadius = 3.0
        viewWalletPopupContainer.layer.masksToBounds = true
        viewAmountContainer.layer.cornerRadius = 3.0
        viewAmountContainer.layer.masksToBounds = true
        viewAmountContainer.layer.borderWidth = 1.0
        viewAmountContainer.layer.borderColor = UIColor.lightGray.cgColor
        
          
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    // MARK: - Keyboard Notification
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstWalletPopView?.constant = 0.0
            } else {
                self.bottomConstWalletPopView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    
  
    
    @IBAction func btnHideWalletPopup(_ sender: Any) {
         delegate?.hideWalletPopupView()
    }
    @IBAction func btnCloseAction(_ sender: Any) {
          delegate?.hideWalletPopupView()
    }
    @IBAction func btnAddMoneyAction(_ sender: Any) {
        
        if ((self.txtAmount.text?.characters.count)! > 0) {
            let value = Float(self.txtAmount.text!)
            if value! < 5 {
                self.showAlert(string: "Please Enter atleast $5")
            }
            else{
                delegate?.btnAddmoneyClicked(strAmount: self.txtAmount.text!)
            }
        }
        else{
            self.showAlert(string: "Please enter amount")
        }
    }
    
    
    // MARK: - UITextFieldDelegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if string.characters.count < 1 {
            return true
        }
        do {
            //            if textField == self.tmpTextField {
            let startIndex =  textField.text?.index((textField.text?.startIndex)!, offsetBy:range.location);
            let endIndex = textField.text?.index(startIndex!, offsetBy:range.length);
            var newString = textField.text?.replacingCharacters(in: startIndex!..<endIndex!, with: string)
            //                var newString = textField.text.replacingCharacters(inRange: range, with: string)
            let expression = "^([0-9]+)?(\\.([0-9]{1,4})?)?$"
            let regex = try NSRegularExpression(pattern: expression, options: .caseInsensitive)
            let numberOfMatches = regex.numberOfMatches(in: newString!, options: [], range: NSRange(location: 0, length: (newString?.characters.count)!))
            if numberOfMatches == 0 {
                return false
            }
            //            }
        }
        catch _ {
        }
        return true
        //        let allowedCharacters = CharacterSet.decimalDigits
        //        let characterSet = CharacterSet(charactersIn: string)
        //        return allowedCharacters.isSuperset(of: characterSet)
    }
    
    func dismissPicker() {
        self.endEditing(true)
    }
}

//
//  MenuView.swift
//  Oriscene
//
//  Created by Parth on 09/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol MenuDelegate {
    func hideMenuClicked ()
}

class MenuView: UIView, UITableViewDelegate, UITableViewDataSource, MenuHederViewDelegate{

    var delegate : MenuDelegate?
    var arrMenuList = [Dictionary<String,String>]()
    var intSelectedRow : NSInteger = -1
    let service = WebService()
    var postCount = ""

    var viewMenuHeader : MenuHeaderView = MenuHeaderView.instanceFromNib() as! MenuHeaderView
    
    @IBOutlet var btnHideMenu: UIButton!
    @IBOutlet var tblMenu: UITableView!
    @IBOutlet var viewDetailContainer: UIView!
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        tblMenu.register(MenuTVCell.self, forCellReuseIdentifier: "MenuTVCell")
        tblMenu.register(UINib.init(nibName: "MenuTVCell", bundle: nil), forCellReuseIdentifier: "MenuTVCell")
        
        viewDetailContainer.layer.shadowColor = UIColor.black.cgColor
        viewDetailContainer.layer.shadowOpacity = 1
        viewDetailContainer.layer.shadowOffset = CGSize.zero
        viewDetailContainer.layer.shadowRadius = 5
        self.layoutIfNeeded()
        
//        viewMenuHeader = MenuHeaderView.instanceFromNib() as! MenuHeaderView
        viewMenuHeader.layoutIfNeeded()
        viewMenuHeader.delegate = self
        viewMenuHeader.frame.origin.x = 0.0
        viewMenuHeader.frame.origin.y = 0.0
        viewMenuHeader.frame.size.width = viewDetailContainer.frame.size.width
        viewMenuHeader.frame.size.height = 160.0
        tblMenu.tableHeaderView = viewMenuHeader
        
        viewMenuHeader.imgProfilePic.image = UIImage.init(named: "default_img")
        
//        arrMenuList =
//            [ [ "imgMenuIcon" : "home_icon" , "imgMenuIconSel" : "home_icon_sel" , "menuTitle" : "Home"] , [ "imgMenuIcon" : "share_icon_menu" , "imgMenuIconSel" : "share_icon_menu_sel" , "menuTitle" : "Share Posts"] , [ "imgMenuIcon" : "sell_icon" , "imgMenuIconSel" : "sell_icon_sel" , "menuTitle" : "Sell Posts"] , [ "imgMenuIcon" : "noti_icon" , "imgMenuIconSel" : "noti_icon_sel" , "menuTitle" : "Notification"] , [ "imgMenuIcon" : "mess_icon" , "imgMenuIconSel" : "mess_icon_sel" , "menuTitle" : "Messages"] , [ "imgMenuIcon" : "rev_icon" , "imgMenuIconSel" : "rev_icon_sel" , "menuTitle" : "Revenue"] , [ "imgMenuIcon" : "follo_icon" , "imgMenuIconSel" : "follo_icon_sel" , "menuTitle" : "Followers"] , [ "imgMenuIcon" : "sett_icon" , "imgMenuIconSel" : "sett_icon_sel" , "menuTitle" : "Settings"] , [ "imgMenuIcon" : "invite_icon" , "imgMenuIconSel" : "invite_icon_sel" , "menuTitle" : "Invite Friends"] , [ "imgMenuIcon" : "faq_icon" , "imgMenuIconSel" : "faq_icon_sel" , "menuTitle" : "FAQ"] , [ "imgMenuIcon" : "about_icon" , "imgMenuIconSel" : "about_icon_sel" , "menuTitle" : "About Us"] , [ "imgMenuIcon" : "logout_icon" , "imgMenuIconSel" : "logout_icon_sel" , "menuTitle" : "Log Out"] ]
        
        arrMenuList =
            [ [ "imgMenuIcon" : "home_icon" , "imgMenuIconSel" : "home_icon_sel" , "menuTitle" : "Home"] , [ "imgMenuIcon" : "sell_icon" , "imgMenuIconSel" : "sell_icon_sel" , "menuTitle" : "Sell Posts"] , [ "imgMenuIcon" : "noti_icon" , "imgMenuIconSel" : "noti_icon_sel" , "menuTitle" : "Notification"] , [ "imgMenuIcon" : "mess_icon" , "imgMenuIconSel" : "mess_icon_sel" , "menuTitle" : "Messages"] , [ "imgMenuIcon" : "rev_icon" , "imgMenuIconSel" : "rev_icon_sel" , "menuTitle" : "Revenue"] , [ "imgMenuIcon" : "follo_icon" , "imgMenuIconSel" : "follo_icon_sel" , "menuTitle" : "Followers"] , [ "imgMenuIcon" : "sett_icon" , "imgMenuIconSel" : "sett_icon_sel" , "menuTitle" : "Settings"] , [ "imgMenuIcon" : "invite_icon" , "imgMenuIconSel" : "invite_icon_sel" , "menuTitle" : "Invite Friends"] , [ "imgMenuIcon" : "faq_icon" , "imgMenuIconSel" : "faq_icon_sel" , "menuTitle" : "FAQ"] , [ "imgMenuIcon" : "about_icon" , "imgMenuIconSel" : "about_icon_sel" , "menuTitle" : "About Us"] , [ "imgMenuIcon" : "logout_icon" , "imgMenuIconSel" : "logout_icon_sel" , "menuTitle" : "Log Out"] ]
        
        tblMenu.reloadData()
        RefreshUserDetail()
        self.callWebserviceNotification()
    }

    class func instanceFromNib() -> UIView {
        return UINib(nibName: "MenuView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    // MARK: - Action Method
    
    @IBAction func btnHideMenuAction(_ sender: AnyObject) {
        self.delegate?.hideMenuClicked()
    }
    
    // MARK: - UITableView Datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMenuList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "MenuTVCell") as! MenuTVCell
        let dictCategory = arrMenuList[indexPath.row]
        cell.lblMenuOption.text = dictCategory["menuTitle"]
        
        if intSelectedRow == indexPath.row {
            cell.imgMenuOption.image = UIImage (named: dictCategory["imgMenuIconSel"]!, in: nil
                , compatibleWith: nil)
            cell.backgroundColor = UIColor.blue
            cell.lblMenuOption.textColor = UIColor.white
        }
        else{
            cell.imgMenuOption.image = UIImage (named: dictCategory["imgMenuIcon"]!, in: nil
                , compatibleWith: nil)
            cell.backgroundColor = UIColor.white
            cell.lblMenuOption.textColor = UIColor.darkGray
            
        }
        cell.lblNotificationCount.layer.cornerRadius = 3
        cell.lblNotificationCount.layer.masksToBounds = true
        if indexPath.row == 2 && self.postCount != "0" {
            cell.lblNotificationCount.isHidden = false
            cell.lblNotificationCount.text = " \(self.postCount) "
        } else {
            cell.lblNotificationCount.isHidden = true
        }
        return cell
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if intSelectedRow == indexPath.row {
            if intSelectedRow == MenuIndex.LOGOUT.rawValue {
                setViewController()
            }
        }
        else{
            intSelectedRow = indexPath.row
            tblMenu.reloadData()
            
//            self.performSelector(onMainThread:#selector(setViewController), with: nil, waitUntilDone: false)
            
            setViewController()
        }
        delegate?.hideMenuClicked()
    }
    
    public func reloadDataForMenu(){
        tblMenu.reloadData()
    }
    
    func setViewController(){
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let navVC =  appDelegate.window?.rootViewController as! UINavigationController

        switch intSelectedRow {
        case MenuIndex.HOME.rawValue:
            let vcHome = storyBoard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            vcHome.currentPostType = CurrentSelectedPostType.BOTH.rawValue
            navVC.viewControllers = [vcHome]
            break
        /*
        case MenuIndex.SHARE_POSTS.rawValue:
            let vcHome = storyBoard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            vcHome.currentPostType = CurrentSelectedPostType.SHARE_POST.rawValue
            navVC.viewControllers = [vcHome]
            break 
             */
            
        case MenuIndex.SELL_POSTS.rawValue:
            let vcHome = storyBoard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            vcHome.currentPostType = CurrentSelectedPostType.SELL_POST.rawValue
            navVC.viewControllers = [vcHome]
            break
            
        case MenuIndex.NOTIFICATION.rawValue:
            let vcNotification = storyBoard.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
            navVC.viewControllers = [vcNotification]
            break
            
        case MenuIndex.MESSAGES.rawValue:
            let vcMessages = storyBoard.instantiateViewController(withIdentifier: "MessagesViewController") as! MessagesViewController
            navVC.viewControllers = [vcMessages]
            break
            
        case MenuIndex.REVENUE.rawValue:
            let vcRevenue = storyBoard.instantiateViewController(withIdentifier: "RevenueViewController") as! RevenueViewController
            navVC.viewControllers = [vcRevenue]
            break
            
        case MenuIndex.FOLLOWERS.rawValue:
            let vcFollowers = storyBoard.instantiateViewController(withIdentifier: "FollowersViewController") as! FollowersViewController
            navVC.viewControllers = [vcFollowers]
            break
            
        case MenuIndex.SETTINGS.rawValue:
            let vcSettings = storyBoard.instantiateViewController(withIdentifier: "SettingsViewController") as! SettingsViewController
            navVC.viewControllers = [vcSettings]
            break
            
        case MenuIndex.INVITE_FRIEND.rawValue:
            let vcInvite = storyBoard.instantiateViewController(withIdentifier: "InviteViewController") as! InviteViewController
            navVC.viewControllers = [vcInvite]
            break
            
        case MenuIndex.FAQ.rawValue:
            let vcFAQ = storyBoard.instantiateViewController(withIdentifier: "FaqViewController") as! FaqViewController
            navVC.viewControllers = [vcFAQ]
            break
            
        case MenuIndex.ABOUT_US.rawValue:
            let vcAboutUs = storyBoard.instantiateViewController(withIdentifier: "AboutUsViewController") as! AboutUsViewController
            navVC.viewControllers = [vcAboutUs]
            break
            
        case MenuIndex.LOGOUT.rawValue:
            
            logout()
            
            break
            
        default:
            break
        }
    }
    
    func logout() -> Void {
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let navVC =  appDelegate.window?.rootViewController as! UINavigationController
        
        let alert:UIAlertController=UIAlertController(title: Constant.APP_NAME, message: "Sure want to logout?", preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
        }
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default)
        {
            
            UIAlertAction in
            
            self.endEditing(true)
            
            let userDefault = UserDefaults.standard
            userDefault.removeObject(forKey: "isLogin")
            userDefault.removeObject(forKey: "userData")
            userDefault.removeObject(forKey: "business_data")
            
            for (_, element) in navVC.viewControllers.enumerated(){
                if element.isKind(of: LoginViewController.self) {
                    navVC.popToViewController(element, animated: true)
                    return
                }
            }
            
            let vcLogin = storyBoard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            navVC.setViewControllers([vcLogin], animated: true)
        }
        // Add the actions
        alert.addAction(cancelAction)
        alert.addAction(okAction)
        appDelegate.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    // MARK: - MenuHederViewDelegate
    func EditProfileDetailClicked() {
        delegate?.hideMenuClicked()
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let navVC =  appDelegate.window?.rootViewController as! UINavigationController
        
        let vcBasicInfo = storyBoard.instantiateViewController(withIdentifier: "BasicInformationViewController") as! BasicInformationViewController
        vcBasicInfo.isPopAllowed = true
        navVC.pushViewController(vcBasicInfo, animated: true)
    }
    
    // MARK: - RefreshUserDtl
    
    func RefreshUserDetail() {
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            let fileUrl = NSURL(string: PROFILE_PIC_BASEURL + (dictUser["photo"] as! String))
            viewMenuHeader.imgProfilePic.clipsToBounds = true
            viewMenuHeader.imgProfilePic.contentMode = UIViewContentMode.redraw
            viewMenuHeader.imgProfilePic.sd_cancelCurrentImageLoad()
//            viewMenuHeader.imgProfilePic.sd_setImage(with: fileUrl as URL!)
            viewMenuHeader.imgProfilePic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                if error != nil {
                    print("Failed: \(error)")
                } else {
                    print("Success")
                }
            }
//            viewMenuHeader.lblUserName.text = (dictUser["firstname"] as! String) + " " + (dictUser["lastname"] as! String)
            let strusenickname = dictUser["usenickname"] as! String
            if strusenickname == "1" {
                viewMenuHeader.lblUserName.text = dictUser["reporter_name"] as? String
            }
            else{
                viewMenuHeader.lblUserName.text = (dictUser["firstname"] as! String) + " " + (dictUser["lastname"] as! String)
            }
        }
    }
    // MARK: - Webservice Call
    func callWebserviceNotification() -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            service.callJSONMethod(methodName: "newNotificationCount", parameters: dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in

                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        let userDefault = UserDefaults.standard
                        if (dict?.keys.contains("user_data"))! {
                            if let dictUser = dict?["user_data"] {
                                userDefault.set(dictUser, forKey: "business_data")
                            }
                        }
                        if (dict?.keys.contains("business_data"))! {
                            if let dictBussiness = dict?["business_data"] {
                                userDefault.set(dictBussiness, forKey: "business_data")
                            }
                        }
                        userDefault.synchronize()
                        self.RefreshUserDetail()
                        let tempArray =  dict?["count"]
                        self.postCount = "\(tempArray!)"
                        self.tblMenu.reloadData()
                    }
                    
                }
            },onFailResponse: { (_ error:NSError?) in
               
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    // MARK: - Recability Method
    func isConnectedToNetwork() -> Bool {
        
        if (currentReachabilityStatus == ReachabilityStatus.reachableViaWiFi)
        {
            return true
        }
        else if (currentReachabilityStatus == ReachabilityStatus.reachableViaWWAN)
        {
            return true
        }
        else
        {
            return false
        }
    }
    func showNoNetworkAlert() -> Void {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Please check internet connection." , delegate: nil, cancelButtonTitle: "OK")
        alertWarning.show()
    }

}

//
//  BidPriceView.swift
//  Oriscene
//
//  Created by Parth on 02/12/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol BidPriceDelegate {
    func hideBidPriceView() -> Void
    func insertUpdateBidPriceClick(strAmount: String,indexOfObject : NSInteger) -> Void
}

class BidPriceView: UIView, UITextFieldDelegate{

    var delegate : BidPriceDelegate?
    var index : NSInteger = -1
    var dictBidDtl = Dictionary<String,Any>()
    
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var viewPriceContainer: UIView!
    @IBOutlet var txtPrice: UITextField!
    
    @IBOutlet var btnPlaceBid: UIButton!
    @IBOutlet var btnCancel: UIButton!
    @IBOutlet var btnClose: UIButton!
    
    @IBOutlet var lblTitle: UILabel!
    
    
    @IBOutlet var btnBottomConstBidView: NSLayoutConstraint!
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "BidPriceView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        
        viewPriceContainer.layer.cornerRadius = 3.0
        viewPriceContainer.layer.masksToBounds = true
        viewPriceContainer.layer.borderWidth = 1.0
        viewPriceContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
 
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.btnBottomConstBidView?.constant = 0.0
            } else {
                self.btnBottomConstBidView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    @IBAction func btnCloseAction(_ sender: Any) {
        delegate?.hideBidPriceView()
    }
    
    @IBAction func btnPlaceBidAction(_ sender: Any) {
        if (txtPrice.text?.characters.count)! > 0{
            delegate?.insertUpdateBidPriceClick(strAmount: txtPrice.text!, indexOfObject: index)
        }
    }
    @IBAction func btnCancelBidAction(_ sender: Any) {
        delegate?.hideBidPriceView()
    }
    
    @IBAction func btnHideAction(_ sender: Any) {
        delegate?.hideBidPriceView()
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if string.characters.count < 1 {
            return true
        }
        do {
//            if textField == self.tmpTextField {
            let startIndex =  textField.text?.index((textField.text?.startIndex)!, offsetBy:range.location);
            let endIndex = textField.text?.index(startIndex!, offsetBy:range.length);
            var newString = textField.text?.replacingCharacters(in: startIndex!..<endIndex!, with: string)
//                var newString = textField.text.replacingCharacters(inRange: range, with: string)
                let expression = "^([0-9]+)?(\\.([0-9]{1,4})?)?$"
                let regex = try NSRegularExpression(pattern: expression, options: .caseInsensitive)
                let numberOfMatches = regex.numberOfMatches(in: newString!, options: [], range: NSRange(location: 0, length: (newString?.characters.count)!))
                if numberOfMatches == 0 {
                    return false
                }
//            }
        }
        catch _ {
        }
        return true
//        let allowedCharacters = CharacterSet.decimalDigits
//        let characterSet = CharacterSet(charactersIn: string)
//        return allowedCharacters.isSuperset(of: characterSet)
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

}

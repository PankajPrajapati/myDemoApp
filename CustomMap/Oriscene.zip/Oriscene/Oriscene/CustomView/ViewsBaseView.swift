//
//  ViewsBaseView.swift
//  Oriscene
//
//  Created by Tristate on 12/27/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

class ViewsBaseView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    var ViewSpinner: UIView = UIView()
    var imageView : UIImageView = UIImageView()
   
    
    //Mark: progressHood method
    
    func showSpinner(enableInteraction : Bool) -> Void {
        //        self.spinner.isHidden = false
        
        imageView.stopRotating()
        ViewSpinner.removeFromSuperview()
        
        self.isUserInteractionEnabled = enableInteraction
        ViewSpinner = UIView(frame: CGRect(x:0, y:0, width:80, height: 80))
        ViewSpinner.center = self.center;
        ViewSpinner.backgroundColor = UIColor.init(red: 51.0/255.0, green: 59.0/255.0, blue: 81.0/255.0, alpha: 1.0)
        ViewSpinner.alpha = 0.5
        ViewSpinner.layer.cornerRadius = 5.0
        ViewSpinner.bringSubview(toFront: ViewSpinner)
        
        let imageName = "img_loader.png"
        let globalImage = UIImage(named: imageName)
        imageView = UIImageView(image: globalImage!)
        imageView.frame = CGRect(x: ViewSpinner.frame.size.width/2-25, y: ViewSpinner.frame.size.height/2-25, width: 50, height: 50)
        
        imageView.startRotating()
        imageView.layer.cornerRadius = imageView.frame.size.height/2
        imageView.layer.masksToBounds = true
        ViewSpinner.addSubview(imageView)
        
        self.addSubview(ViewSpinner)
    }
    
    func hideSpinner() -> Void {
        //        self.spinner.isHidden = true
        self.isUserInteractionEnabled = true
        
        imageView.stopRotating()
        ViewSpinner.removeFromSuperview()
    }

    
    func trimString(string : String) -> String {
        let trimmedString = string.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        return trimmedString
    }
    
    // MARK: - Recability Method
    func isConnectedToNetwork() -> Bool {
        
        if (currentReachabilityStatus == ReachabilityStatus.reachableViaWiFi)
        {
            return true
        }
        else if (currentReachabilityStatus == ReachabilityStatus.reachableViaWWAN)
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    func showAlert(string : String) -> Void {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: string , delegate: nil, cancelButtonTitle: "OK")
        alertWarning.show()
    }
    
    func showNoNetworkAlert() -> Void {
        let alertWarning = UIAlertView(title: Constant.APP_NAME, message: "Please check internet connection." , delegate: nil, cancelButtonTitle: "OK")
        alertWarning.show()
    }

}

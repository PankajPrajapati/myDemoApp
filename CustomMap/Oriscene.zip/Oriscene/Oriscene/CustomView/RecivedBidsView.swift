//
//  RecivedBidsView.swift
//  Oriscene
//
//  Created by Tristate on 25/01/17.
//  Copyright © 2017 Tristate. All rights reserved.
//

import UIKit

protocol RecivedBidsViewDelegate {
    func btnApproveClicked(index : NSInteger) -> Void
    func hideRecivedBidView(index : NSInteger) -> Void
}
class RecivedBidsView: ViewsBaseView, UITableViewDelegate, UITableViewDataSource,BidListDelegate {

    var dictBidData = Dictionary<String,Any>()
    var arrRecivedBids = [Dictionary<String,Any>]()
    var index : NSInteger = -1
    var delegate : RecivedBidsViewDelegate?
    var service = WebService()
    
    @IBOutlet weak var tblRecivedBids: UITableView!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    override func draw(_ rect: CGRect) {
//        Drawing code
        tblRecivedBids.register(BidsTVCell.self, forCellReuseIdentifier: "BidsTVCell")
        tblRecivedBids.register(UINib.init(nibName: "BidsTVCell", bundle: nil), forCellReuseIdentifier: "BidsTVCell")
    }
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "RecivedBidsView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    override func layoutSubviews() {
        tblRecivedBids.register(BidsTVCell.self, forCellReuseIdentifier: "BidsTVCell")
        tblRecivedBids.register(UINib.init(nibName: "BidsTVCell", bundle: nil), forCellReuseIdentifier: "BidsTVCell")
        self.tblRecivedBids.separatorStyle = UITableViewCellSeparatorStyle.none
        self.tblRecivedBids.layer.cornerRadius = 5.0;
    }
    // MARK: - UITableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return arrRecivedBids.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView .dequeueReusableCell(withIdentifier: "BidsTVCell") as! BidsTVCell
        cell.index = indexPath.row
        cell.delegate = self
        let dictRecivedBid = arrRecivedBids[indexPath.row]
        let dictUserData = dictRecivedBid["user_data"] as! Dictionary<String,Any>
        
        if dictUserData.keys.contains("photo") {
            
            let strStringNameId = dictUserData["photo"]
            if strStringNameId is String {
                let strPhotoName = strStringNameId as! String
                
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    cell.imgUserPic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
                }
            }else {
                cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
            }
        }
        else{
            cell.imgUserPic.image = #imageLiteral(resourceName: "default_img")
        }
        
        let strusenickname = dictUserData["usenickname"] as! String
        if strusenickname == "1" {
            cell.lblUserName.text = dictUserData["reporter_name"] as? String
        }
        else{
            cell.lblUserName.text = (dictUserData["firstname"] as! String) + " " + (dictUserData["lastname"] as! String)
        }
        cell.lblComment.text = dictBidData["title_text"] as? String
        cell.lblDescription.text = dictBidData["desc_text"] as? String //"$" + ()
        /*
        let dateFormat = DateFormatter()
        // 2016-12-26 04:18:23
        dateFormat.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let strDate = dictRecivedBid["edit_date"] as? String
        let date  = dateFormat.date(from: strDate!)
        cell.lblTime.text = date?.timestampString
        */
        
        let strDate = dictBidData["edit_date"] as? String
        cell.lblTime.text = convertDate(strDate: strDate!)
        if dictRecivedBid.keys.contains("dis_approved_btn"){
            cell.btnPending.setTitle("APPROVED",for: .normal)
            cell.btnPending.isEnabled = false
        }else{
            cell.btnPending.setTitle("APPROVE",for: .normal)
            cell.btnPending.isEnabled = true
        }
        if dictRecivedBid.keys.contains("dis_disApprove_btn_enable"){
            cell.btnEditBid.setTitle("DISAPPROVE",for: .normal)
            cell.btnEditBid.isEnabled = true
             cell.btnEditBid.isHidden = false
        }else{
//                cell.btnEditBid.setTitle("DISAPPROV",for: .normal)
//                cell.btnEditBid.isEnabled = false
            cell.btnEditBid.isHidden = true
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
            return UITableViewAutomaticDimension
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    }

    // MARK: - BID Cell Delegate
    func btnEditBidClicked(index: NSInteger) {
          //DisApprove Bid Button click
        callWebserviceShowAndUpdateRecivedBids(isForView: false, status: 2)
    }
    
    func btnPendingBidClicked(index: NSInteger) {
        //Approve Bid Button click
        callWebserviceShowAndUpdateRecivedBids(isForView: false, status: 1)
    }
  
  
    //MARK:- Button Action
    @IBAction func btnCloseClickAction(_ sender: Any) {
        self.arrRecivedBids.removeAll()
        self.tblRecivedBids.reloadData()
        self.delegate?.hideRecivedBidView(index: index)
    }
    //MARK:- Webservice
    func callWebserviceShowAndUpdateRecivedBids(isForView : Bool,status : NSInteger) -> Void {
        
        if self.isConnectedToNetwork() {
            let dictParam = NSMutableDictionary()
            
            if isForView {
                dictParam["forView"] = "1"
                dictParam["forStatusChange"] = "0"
                dictParam["cId"] = ""
                dictParam["status"] = ""
            }else{
                dictParam["forView"] = "0"
                dictParam["forStatusChange"] = "1"
                let dictData = arrRecivedBids[0] as Dictionary<String,Any>
                dictParam["cId"] = dictData["c_id"] as! String
               
                if status == 1 {
                    dictParam["status"] = "approve"
                }else if status == 2 {
                    dictParam["status"] = "disapprove"
                }
            }
            dictParam["postId"] = dictBidData["post_id"] as! String
            
            
            
//            {"method_name":"viewReceivedBidOrStatusChange","body":{"loggedUser":"","postId":"","forStatusChange":"","forView":"","cId":"","status":""}}
            self.showSpinner(enableInteraction: false)
            service.callJSONMethod(methodName: "viewReceivedBidOrStatusChange", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        print(dict!)
                       self.arrRecivedBids = dict?["data"] as! [Dictionary<String,Any>]
                        self.tblRecivedBids.reloadData()
                        if status > 0 {
                            self.showAlert(string: dict?["message"] as! String)
                        }
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    //MARK:- Custom Method
    func convertDate(strDate:String) -> String {
        let formater = DateFormatter()
        formater.dateFormat = "yyyy-MM-dd HH:mm:ss"
        //let strTrasDate = dictData["payed_date"] as? String
        let trasDate = formater.date(from: strDate)
        
        formater.dateFormat = "MMM dd, yyyy"
        let strTrasDate = formater.string(from: trasDate!)
        return strTrasDate
        
    }
}

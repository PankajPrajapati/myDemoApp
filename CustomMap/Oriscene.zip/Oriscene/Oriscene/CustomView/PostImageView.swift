//
//  PostImageView.swift
//  Oriscene
//
//  Created by Tristate on 12/19/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol PostImageViewDelegate {
    func hidePostImageView() -> Void
}

class PostImageView: UIView,UICollectionViewDataSource,UICollectionViewDelegate {
    
    var delegate : PostImageViewDelegate?
    var arrAttDetail = [Dictionary<String,Any>]()
    var currentPostType : NSInteger = -1
    
    @IBOutlet weak var cvPostImageList: UICollectionView!
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        //        cvPostImageList.register(PostImagesCVCell.self, forCellWithReuseIdentifier: "PostImagesCVCell")
        //        cvPostImageList.register(UINib.init(nibName: "PostImagesCVCell", bundle: nil), forCellWithReuseIdentifier: "PostImagesCVCell")
    }
    
    override func layoutSubviews() {
        cvPostImageList.register(ZoomImageCell.self, forCellWithReuseIdentifier: "ZoomImageCell")
        cvPostImageList.register(UINib.init(nibName: "ZoomImageCell", bundle: nil), forCellWithReuseIdentifier: "ZoomImageCell")
    }
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "PostImageView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    // MARK: - Button Click Action
    @IBAction func btnCloseClickAction(_ sender: Any) {
        delegate?.hidePostImageView()
    }
    
    // MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrAttDetail.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        //        let cell : UICollectionViewCell!
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ZoomImageCell", for: indexPath) as! ZoomImageCell
        cell.imgPostImage.frame = CGRect.init(x: 0.0, y: cell.imgPostImage.frame.origin.y, width: UIScreen.main.bounds.size.width, height: cell.imgPostImage.frame.size.height)
        cell.imgPostImage.contentMode = .scaleAspectFit
        cell.layoutIfNeeded()
        cell.setupScrollview()
        var strBaseUrl = ""
        
        if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
            strBaseUrl = IMAGE_ATTACHMENT_BASE_URL
        }
        else{
            strBaseUrl = SELL_IMAGE_ATTACHMENT_URL
        }
        
        let dictPostData = arrAttDetail[indexPath.item]
        let strPhotoName = dictPostData["attachment_name"] as! String
        if strPhotoName.characters.count != 0 {
            
            let strUrl = strBaseUrl + strPhotoName
            let fileUrl = NSURL(string: strUrl)
            cell.scrollView.contentSize = cell.imgPostImage.frame.size;
            cell.scrollView.addSubview(cell.imgPostImage)
            cell.imgPostImage.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                if error != nil {
                    print("Failed: \(error)")
                } else {
                    print("Success")
                    
                    let plusWidth : CGFloat = UIScreen.main.bounds.size.width
                    let imageNew : UIImage = self.imageResize(with: image!, scaledToWidth: plusWidth)
                    
                    cell.imgPostImage.frame = CGRect(x: CGFloat((UIScreen.main.bounds.size.width - (imageNew.size.width)) / 2), y: CGFloat((UIScreen.main.bounds.size.height - (imageNew.size.height)) / 2 ), width: CGFloat(imageNew.size.width), height: CGFloat(imageNew.size.height))
                    //                cell.imgPostImage.frame = CGRect(x: 0.0, y: CGFloat((UIScreen.main.bounds.size.height - (image?.size.height)!) / 2 ), width: CGFloat(UIScreen.main.bounds.size.width), height: CGFloat((image?.size.height)!))
                }
                cell.scrollView.contentSize = cell.imgPostImage.frame.size;
                cell.scrollView.addSubview(cell.imgPostImage)
            }
        }
        else{
            cell.imgPostImage.image = #imageLiteral(resourceName: "default_img")
            cell.scrollView.contentSize = cell.imgPostImage.frame.size;
            cell.scrollView.addSubview(cell.imgPostImage)
        }
        /*
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(self.handleDoubleTap))
        doubleTap.numberOfTapsRequired = 2
        cell.imgPostImage.tag = indexPath.row
        cell.imgPostImage.addGestureRecognizer(doubleTap)
        
        cell.scrollView.autoresizesSubviews = true;
        cell.scrollView.isMultipleTouchEnabled = true;
        cell.scrollView.maximumZoomScale = 4.0;
        cell.scrollView.minimumZoomScale = 1.0;
        cell.scrollView.clipsToBounds = true;
        cell.scrollView.delegate = self;
        cell.scrollView.zoomScale = 1.0;
        */
        return cell
    }
    
    func imageResize(with sourceImage: UIImage, scaledToWidth i_width: CGFloat) -> UIImage {
        let oldWidth: CGFloat = sourceImage.size.width
        let scaleFactor: CGFloat = i_width / oldWidth
        let newHeight: CGFloat = sourceImage.size.height * scaleFactor
        let newWidth: CGFloat = oldWidth * scaleFactor
        UIGraphicsBeginImageContext(CGSize(width: CGFloat(newWidth), height: CGFloat(newHeight)))
        sourceImage.draw(in: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(newWidth), height: CGFloat(newHeight)))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath: IndexPath) -> CGSize{
        return CGSize(width: UIScreen.main.bounds.size.width, height: cvPostImageList.frame.size.height);
    }
    
    // MARK: - UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
    
    // MARK: - ZoomImage
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        for v: UIView in scrollView.subviews {
            if (v is UIImageView) {
                return v
            }
        }
        return nil
    }
    /*
    func handleDoubleTap(_ gestureRecognizer: UIGestureRecognizer) {
        let imageView = (gestureRecognizer.view! as! UIImageView)
        if imageView != nil {
            var indexpath = IndexPath(row: imageView.tag, section: 0)
            let cell = (self.cvPostImageList.cellForItem(at: indexpath)! as! ZoomImageCell)
            cell.scrollView.tag = indexpath.row + 1
            if cell.scrollView.zoomScale > cell.scrollView.minimumZoomScale {
                cell.scrollView.setZoomScale(cell.scrollView.minimumZoomScale, animated: true)
            }
            else {
                let touch = gestureRecognizer.location(in: gestureRecognizer.view)
                let scrollViewSize = cell.bounds.size
                let w: CGFloat = scrollViewSize.width / cell.scrollView.maximumZoomScale
                let h: CGFloat = scrollViewSize.height / cell.scrollView.maximumZoomScale
                let x: CGFloat = touch.x - (w / 2.0)
                let y: CGFloat = touch.y - (h / 2.0)
                let rectTozoom = CGRect(x: x, y: y, width: w, height: h)
                cell.scrollView.zoom(to: rectTozoom, animated: true)
            }
        }
    }*/
    
}

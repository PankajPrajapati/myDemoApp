//
//  LocationSearchView.swift
//  Oriscene
//
//  Created by Parth on 20/12/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol LocationSearchViewDelegate {
    func hideLocationSearchView() -> Void
    func selectedLocation(dictLocation: Dictionary<String, Any>)
}

class LocationSearchView: UIView, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {

    var delegate : LocationSearchViewDelegate?
    var arrLocations = [Dictionary<String,Any>]()
    let service = WebService()
    
    @IBOutlet var btnHideLocation: UIButton!
    @IBOutlet var viewLocationContainer: UIView!
    @IBOutlet var imgLocation: UIImageView!
    @IBOutlet var txtLocation: UITextField!
    @IBOutlet var tblLocation: UITableView!
    
    @IBOutlet var heightConstTbl: NSLayoutConstraint!
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        viewLocationContainer.layer.cornerRadius = 3.0
        viewLocationContainer.layer.masksToBounds = true
        
        tblLocation.layer.cornerRadius = 3.0
        tblLocation.layer.masksToBounds = true
        
        self.heightConstTbl.constant = self.tblLocation.contentSize.height
    }
    
    override func layoutSubviews() {
        tblLocation.register(LocationSearchTVCell.self, forCellReuseIdentifier: "LocationSearchTVCell")
        tblLocation.register(UINib.init(nibName: "LocationSearchTVCell", bundle: nil), forCellReuseIdentifier: "LocationSearchTVCell")
    }
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "LocationSearchView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }

    @IBAction func btnHideLocationSearchViewAction(_ sender: Any) {
        delegate?.hideLocationSearchView()
    }
    
    // MARK: - UITableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrLocations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView .dequeueReusableCell(withIdentifier: "LocationSearchTVCell") as! LocationSearchTVCell
        
        let dict = arrLocations[indexPath.row] as Dictionary
        cell.lblLocationTitle.text = dict["description"] as! String?
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    // MARK: - UITableView Delegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dict = arrLocations[indexPath.row]
        delegate?.selectedLocation(dictLocation: dict)
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        /*
        if textField == txtCountry {
            viewCountryList.isHidden = true
            heightConstCountryList.constant = 0.0
            self.view.updateConstraintsIfNeeded()
        }
        else if textField == txtState {
            viewStateList.isHidden = true
            heightConstStateList.constant = 0.0
            self.view.updateConstraintsIfNeeded()
        }
        else{
        }*/
        
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        /*
        if textField == txtCountry {
            let point = CGPoint.init(x: 0.0, y: viewCountryList.frame.origin.y - 50.0)
            self.perform(#selector(setContentOffsetForList(point:)), with:point , afterDelay: 0.5)
            viewCountryList.isHidden = false
            viewStateList.isHidden = true
            
            heightConstStateList.constant = 0.0
            
            let searchString = txtCountry.text
            
            
            if searchString != "" {
                let predicate = NSPredicate(format: "name contains[cd] %@", searchString!)
                arrCountry = arrCountryBackup.filter { predicate.evaluate(with: $0) }
            }
            else{
                arrCountry = arrCountryBackup;
            }
            if arrCountry.count > 3 {
                heightConstCountryList.constant = 135.0
                self.view.updateConstraintsIfNeeded()
                viewCountryList.isHidden = false
            }
            else{
                heightConstCountryList.constant =  CGFloat(44*arrCountry.count)
                self.view.updateConstraintsIfNeeded()
            }
            
            tblCountryList.reloadData()
        }
        else if textField == txtState {
            let point = CGPoint.init(x: 0.0, y: viewStateList.frame.origin.y - 50.0)
            self.perform(#selector(setContentOffsetForList(point:)), with:point , afterDelay: 0.5)
            viewCountryList.isHidden = true
            viewStateList.isHidden = false
            heightConstCountryList.constant = 0.0
            
            let searchString = txtState.text
            if searchString != "" {
                let predicate = NSPredicate(format: "name contains[cd] %@", searchString!)
                arrState = arrStateBackup.filter { predicate.evaluate(with: $0) }
            }
            else{
                arrState = arrStateBackup;
            }
            if arrState.count > 3 {
                heightConstStateList.constant = 135.0
                self.view.updateConstraintsIfNeeded()
            }
            else{
                heightConstStateList.constant = CGFloat(44*arrState.count)
                self.view.updateConstraintsIfNeeded()
            }
            tblStateList.reloadData()
        }
        else{
            viewCountryList.isHidden = true
            viewStateList.isHidden = true
            heightConstCountryList.constant = 0.0
            heightConstStateList.constant = 0.0
            self.view.updateConstraintsIfNeeded()
        }*/
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
//        var searchStr = (textField.text! as String).replacingCharacters(in: string.index(after: String.index(string)), with: string)
        let title:String;
        
        if trimString(string: string).characters.count != 0 {
            if let original = textField.text {
                let startIndex =  original.index(original.startIndex, offsetBy:range.location);
                let endIndex = original.index(startIndex, offsetBy:range.length);
                title = original.replacingCharacters(in: startIndex..<endIndex, with: string)
            }
            else{
                title = string
            }
            if (title.characters.count) > 2 {
                callWebserviceForLocation(strText: title)
            }
            else if title.characters.count == 0 {
                heightConstTbl.constant = 0.0
            }
        }
        else
        {
            if textField.text?.characters.count == 0 {
                heightConstTbl.constant = 0.0
            }
        }
        
        return true
    }
    
    func callWebserviceForLocation(strText: String) -> Void {
        
        var strUrl = "https://maps.googleapis.com/maps/api/place/queryautocomplete/json?input=" + strText + "&key=AIzaSyC2G2TBNcjJ0ThRK6DoH_V5Qm6KCL5bK0M"
        strUrl = strUrl.replacingOccurrences(of: " ", with: "")
        strUrl = strUrl.replacingOccurrences(of: "  ", with: "")
        strUrl = strUrl.replacingOccurrences(of: "   ", with: "")
//        strUrl = strUrl.addingPercentEncoding(withAllowedCharacters: .urlUserAllowed)!
        let url = NSURL.init(string: strUrl)
      
        service .callGetWebServiceUsingURL(url: url!, onSuccessfulResponse:{ (_ dict:Dictionary<String, Any>?) in
            print(dict ?? "")
            
            if dict?["status"] as! String == "OK" {
                self.arrLocations = dict?["predictions"] as! [Dictionary<String,Any>]
                self.tblLocation.reloadData()
                self.heightConstTbl.constant = self.tblLocation.contentSize.height
            }
            
        }) { (_ error:NSError?) in
            print(error?.localizedDescription ?? "")
        }
    }
    
    func trimString(string : String) -> String {
        let trimmedString = string.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        return trimmedString
    }
}

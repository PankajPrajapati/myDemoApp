//
//  PostDetailView.swift
//  Oriscene
//
//  Created by Tristate on 12/20/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol PostDetailViewDelegate {
    func hidePostDetailView() -> Void
}

class PostDetailView: UIView {

    var delegate : PostDetailViewDelegate?
    
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var lblCapturedOn: UILabel!
    @IBOutlet weak var lblFileType: UILabel!
    @IBOutlet weak var lblFileSize: UILabel!
    @IBOutlet weak var lblFileFormat: UILabel!
    @IBOutlet weak var lblMultiFiles: UILabel!
    @IBOutlet weak var lblAudienceRestriction: UILabel!
    @IBOutlet var lblPrice: UILabel!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
  */
    override func draw(_ rect: CGRect) {
        viewContainer.layer.cornerRadius = 5.0;
    }
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "PostDetailView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    @IBAction func btnCloseClickAction(_ sender: Any) {
        delegate?.hidePostDetailView()
    }

}

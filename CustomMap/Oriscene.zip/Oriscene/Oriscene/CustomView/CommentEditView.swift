//
//  CommentEditView.swift
//  Oriscene
//
//  Created by Tristate on 12/27/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol CommentEditViewDelegate {
    func hideCommentEditView() -> Void
    func saveSectionCommentEditView(sectionIndex : NSInteger,dictComment : Dictionary<String,Any>) -> Void
    func saveReplyCommentEditView(cellIndex : NSInteger,dictComment : Dictionary<String,Any>) -> Void
    
}

class CommentEditView: ViewsBaseView, UITextFieldDelegate {

    var delegate : CommentEditViewDelegate?
    var dictCommentData = Dictionary<String,Any>()
    let service = WebService()
    var index = NSInteger()
    var isSectionEdit = true
    
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var txtComment: UITextField!
    
    @IBOutlet weak var viewCommentContainer: UIView!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var btnBottomConstCommentEditView: NSLayoutConstraint!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "CommentEditView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        
        viewCommentContainer.layer.cornerRadius = 3.0
        viewCommentContainer.layer.masksToBounds = true
        viewCommentContainer.layer.borderWidth = 1.0
        viewCommentContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.btnBottomConstCommentEditView?.constant = 0.0
            } else {
                self.btnBottomConstCommentEditView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    
    // MARK: - Button Click Action
    
    @IBAction func btnSaveClickAction(_ sender: Any) {
        if validateComment() {
            if isSectionEdit == true {
                callWebserviceEditSectionCommentPost()
            }
            else{
                callWebserviceEditReplyCommentPost()
            }
        }
    }

    @IBAction func btnCancelClickAction(_ sender: Any) {
        delegate?.hideCommentEditView()
    }
    
    func displayCommentForSection() -> Void {
        //txtComment.text = dictCommentData["reply"] as? String
        txtComment.text = dictCommentData["comment"] as? String
    }
    func displayCommentForReply() -> Void {
        txtComment.text = dictCommentData["reply"] as? String
    }
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }

    // MARK: - Validate Data
    
    func validateComment() -> Bool {
        
        if trimString(string: (txtComment.text)!).characters.count == 0 {
            showAlert(string: "Please enter comment")
            return false
        }
        return true
    }

    
    //MARK:- Webservice Method
    func callWebserviceEditSectionCommentPost() -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            let dictParam = NSMutableDictionary()
            dictParam["forEdit"] = "1"
            dictParam["comment"] = txtComment?.text
            
            dictParam["comId"] = dictCommentData["com_id"]
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            
            //{"method_name":"editDeleteComment","body":{"forEdit":"","comment":"","comId":"","userId":""}}
            
            service.callJSONMethod(methodName: "editDeleteComment", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        //replace comment in dict and replace it to main array
                        
                        self.dictCommentData["comment"] = self.txtComment.text
                        self.delegate?.saveSectionCommentEditView(sectionIndex: self.index, dictComment: self.dictCommentData)
                        
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }
    
    func callWebserviceEditReplyCommentPost() -> Void {
        if self.isConnectedToNetwork() {
            self.showSpinner(enableInteraction: false)
            
            let userDefault = UserDefaults.standard .dictionaryRepresentation()
            let dictUser =  userDefault["userData"] as! Dictionary<String,Any>
            
            let dictParam = NSMutableDictionary()
            dictParam["forEdit"] = "1"
            dictParam["reply"] = txtComment?.text
           
            print("================")
            print(dictCommentData)
            print("================")
            
            dictParam["comId"] = dictCommentData["com_id"]
            dictParam["repId"] = dictCommentData["rep_id"]
            dictParam["userId"] = dictUser["reporter_id"] as? String
            
            //{"method_name":"editDeleteReply","body":{"forEdit":"","reply":"","comId":"","repId":"","userId":""}}
            
            service.callJSONMethod(methodName: "editDeleteReply", parameters:dictParam, isEncrpyted: false, onSuccessfulResponse: { (_ dict:Dictionary<String, Any>?) in
                self.hideSpinner()
                
                if !(dict?.isEmpty)! {
                    if dict?["status"] as! String == "1"{
                        //replace comment object and get back to comment view
                        
                        self.dictCommentData["reply"] = self.txtComment.text
                        self.delegate?.saveReplyCommentEditView(cellIndex: self.index, dictComment:self.dictCommentData)
                    }
                    else{
                        self.showAlert(string: dict?["message"] as! String)
                    }
                }
                
            },onFailResponse: { (_ error:NSError?) in
                self.hideSpinner()
                self.showAlert(string: (error?.localizedDescription)!)
            })
        }
        else{
            self.showNoNetworkAlert()
        }
    }


    
}

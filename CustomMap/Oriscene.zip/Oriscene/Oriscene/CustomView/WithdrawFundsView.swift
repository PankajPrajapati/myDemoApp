//
//  WithdrawFundsView.swift
//  Oriscene
//
//  Created by Tristate on 27/01/17.
//  Copyright © 2017 Tristate. All rights reserved.
//

import UIKit

extension UIToolbar {
    
    func ToolbarPikerAmount(mySelect : Selector) -> UIToolbar {
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.barTintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        doneButton.tintColor = UIColor.white
        //        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        return toolBar
    }
    
}

protocol WithdrawFundsViewDelegate {
    func hideWithdrawFundsView() -> Void
    func saveWithdrawFundsView(strEnterAmount : String, strCommisionAmount : String, strWithdrawAmount : String, isForShare : Bool) -> Void
}

class WithdrawFundsView: ViewsBaseView,UITextFieldDelegate {

    var delegate : WithdrawFundsViewDelegate?
    var isForShare : Bool = false
    var floatCommisionRate : Float = 15.0
    var service = WebService()
    
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var txtAmount: UITextField!
    @IBOutlet weak var viewCommission: UIView!
    @IBOutlet weak var viewWithdrawAmount: UIView!
    
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var textViewContainer: UIView!
    @IBOutlet weak var btnBottomConstWithdrawFundsView: NSLayoutConstraint!
    @IBOutlet var lblCommision: UILabel!
    @IBOutlet var lblWithdrawAmount: UILabel!
    @IBOutlet var lblCommissionTitle: UILabel!
    @IBOutlet var lblWithdrawAmountTitle: UILabel!
    @IBOutlet var lblEnterAmountTitle: UILabel!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "WithdrawFundsView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    override func draw(_ rect: CGRect) {
        
        let toolBar = UIToolbar().ToolbarPikerAmount(mySelect: #selector(self.dismissPicker))
        txtAmount.inputAccessoryView = toolBar
        
        // Drawing code
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        
        textViewContainer.layer.cornerRadius = 3.0
        textViewContainer.layer.masksToBounds = true
        textViewContainer.layer.borderWidth = 1.0
        textViewContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        viewCommission.layer.cornerRadius = 3.0
        viewCommission.layer.masksToBounds = true
        viewCommission.layer.borderWidth = 1.0
        viewCommission.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        viewWithdrawAmount.layer.cornerRadius = 3.0
        viewWithdrawAmount.layer.masksToBounds = true
        viewWithdrawAmount.layer.borderWidth = 1.0
        viewWithdrawAmount.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.btnBottomConstWithdrawFundsView?.constant = 0.0
            } else {
                self.btnBottomConstWithdrawFundsView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    // MARK: - Textfield Delegate Methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
//        if string.characters.count < 1 {
//            return true
//        }
        do {
            //            if textField == self.tmpTextField {
            let startIndex =  textField.text?.index((textField.text?.startIndex)!, offsetBy:range.location);
            let endIndex = textField.text?.index(startIndex!, offsetBy:range.length);
            var newString = textField.text?.replacingCharacters(in: startIndex!..<endIndex!, with: string)
            //                var newString = textField.text.replacingCharacters(inRange: range, with: string)
            let expression = "^([0-9]+)?(\\.([0-9]{1,4})?)?$"
            let regex = try NSRegularExpression(pattern: expression, options: .caseInsensitive)
            let numberOfMatches = regex.numberOfMatches(in: newString!, options: [], range: NSRange(location: 0, length: (newString?.characters.count)!))
            if numberOfMatches == 0 {
                return false
            }
            //            }
        }
        catch _ {
        }
//        return true
        
        let title:String;
        
        if let original = textField.text {
            let startIndex =  original.index(original.startIndex, offsetBy:range.location);
            let endIndex = original.index(startIndex, offsetBy:range.length);
            title = original.replacingCharacters(in: startIndex..<endIndex, with: string)
            if title.characters.count > 0 {
                let floatAmount = Float(title)
                let userDefault = UserDefaults.standard.dictionaryRepresentation()
                if userDefault.keys.contains("WalletData") {
                    let dictWalletData = userDefault["WalletData"] as! Dictionary<String,Any>
                    if isForShare {
                        let intbon_ref_agr_amount = Float(dictWalletData["bon_ref_agr_amount"] as! String)
                        if Float(intbon_ref_agr_amount!) < Float(floatAmount!) {
                            self.showAlert(string: "Please Enter Correct Amount ( withdraw limit exceed )")
                            txtAmount.text = ""
                            lblCommision.text = ""
                            lblWithdrawAmount.text = ""
                            return false
                        }
                    }
                    else {
                        let intbon_ref_agr_amount = Float(dictWalletData["selling_amount"] as! String)
                        if Float(intbon_ref_agr_amount!) < Float(floatAmount!) {
                            self.showAlert(string: "Please Enter Correct Amount ( withdraw limit exceed )")
                            txtAmount.text = ""
                            lblCommision.text = ""
                            lblWithdrawAmount.text = ""
                            return false
                        }
                    }
                }
                
                let floatCommision = (floatAmount! * 15.0) / 100.0
                let floarWithdrawAmount = floatAmount! - floatCommision
                //                txtAmount.text = ""
                lblCommision.text = "\(floatCommision)"
                lblWithdrawAmount.text = "\(floarWithdrawAmount)"
            }
        }
        else{
            title = string
        }
        
        if title.characters.count == 0 {
            txtAmount.text = ""
            lblCommision.text = ""
            lblWithdrawAmount.text = ""
        }
        
//        if trimString(string: string).characters.count != 0 {
//            
//        }
//        else
//        {
//            txtAmount.text = ""
//            lblCommision.text = ""
//            lblWithdrawAmount.text = ""
//        }
        
        return true
    }
    
    // MARK: - Button Click Action
    @IBAction func btnHideAction(_ sender: Any) {
        self.delegate?.hideWithdrawFundsView()
    }

    @IBAction func btnSaveAction(_ sender: Any) {
           self.delegate?.saveWithdrawFundsView(strEnterAmount: self.txtAmount.text!, strCommisionAmount: self.lblCommision.text!, strWithdrawAmount: self.lblWithdrawAmount.text!, isForShare: self.isForShare)
    }
    
    func dismissPicker() {
        self.endEditing(true)
    }
}

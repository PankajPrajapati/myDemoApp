//
//  DocumentViewerView.swift
//  Oriscene
//
//  Created by Parth on 19/12/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol DocumentViewerViewDelegate {
    func hideDocumentViewerView() -> Void
    func documentWebViewLoadFinish()
}

class DocumentViewerView: UIView, UIWebViewDelegate {

    var delegate : DocumentViewerViewDelegate?
    
    @IBOutlet var btnHideDocumentView: UIButton!
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var btnClose: UIButton!
    @IBOutlet var webView: UIWebView!
    
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "DocumentViewerView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        webView.delegate = self
        
    }
 
    @IBAction func btnHideDocumentViewAction(_ sender: Any) {
        delegate?.hideDocumentViewerView()
    }
    @IBAction func btnCloseDocumentViewAction(_ sender: Any) {
        delegate?.hideDocumentViewerView()
    }
    
    //MARK: - UIWebViewDelegate
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        delegate?.documentWebViewLoadFinish()
    }

    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        return true
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        delegate?.documentWebViewLoadFinish()
    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {

    }
}

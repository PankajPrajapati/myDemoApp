//
//  PostCommentSectionView.swift
//  Oriscene
//
//  Created by Parth on 11/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol PostCommentSectionViewDelegate {
    func btnCommentSectionViewReplyClicked(index : NSInteger) -> Void
    func btnSubmitSectionViewReplyClicked(index : NSInteger, strReply : String) -> Void
    func btnCommentSectionEditClicked(index : NSInteger) -> Void
    func btnCommentSectionDeleteClicked(index : NSInteger) -> Void
    func textFieldReplyShouldBeginEditing(_ textField: UITextField) -> Bool
    func textFieldReplyShouldEndEditing(_ textField: UITextField) -> Bool
}


class PostCommentSectionView: UIView {

    var delegate : PostCommentSectionViewDelegate?
    var index : NSInteger = -1
    var indexPath : IndexPath?
    
    @IBOutlet var imgUserProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblComment: UILabel!
    @IBOutlet var lblTime: UILabel!
    @IBOutlet var btnReply: UIButton!
    @IBOutlet var viewReplyContainer: UIView!
    @IBOutlet var btnSubmitReply: UIButton!
    @IBOutlet var txtViewReply: UITextView!
    @IBOutlet var txtReply: UITextField!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        self.layoutIfNeeded()
        imgUserProfilePic.layer.cornerRadius = imgUserProfilePic.frame.size.height/2
        imgUserProfilePic.layer.masksToBounds = true

        btnSubmitReply.layer.cornerRadius = btnSubmitReply.frame.size.height/2
        btnSubmitReply.layer.masksToBounds = true
        
        txtViewReply.contentInset = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)
        let offset = CGPoint(x: CGFloat(0), y: CGFloat(self.txtViewReply.contentSize.height - self.txtViewReply.frame.size.height))
        self.txtViewReply.setContentOffset(offset, animated: true)
    }
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "PostCommentSectionView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.txtReply = textField
        print(delegate?.textFieldReplyShouldBeginEditing(textField) ?? "")
        return true
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool{
        self.txtReply = textField
        print(delegate?.textFieldReplyShouldEndEditing(textField) ?? "")
        return true
    }

    
    @IBAction func btnReplyAction(_ sender: AnyObject) {
        self.txtViewReply.resignFirstResponder()
        self.txtReply.resignFirstResponder()
        delegate?.btnCommentSectionViewReplyClicked(index: index)
        txtViewReply.contentInset = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)
        txtViewReply.setContentOffset(CGPoint(x: CGFloat(0), y: CGFloat(0)), animated: false)
    }
    @IBAction func btnSubmitReplyAction(_ sender: AnyObject) {
        delegate?.btnSubmitSectionViewReplyClicked(index: index, strReply: txtReply.text!)
    }

    @IBAction func btnEditAction(_ sender: Any) {
        delegate?.btnCommentSectionEditClicked(index: index)
    }
    @IBAction func btnDeleteAction(_ sender: Any) {
        self.txtViewReply.resignFirstResponder()
        self.txtReply.resignFirstResponder()
        self.endEditing(true)
        delegate?.btnCommentSectionDeleteClicked(index: index)
    }
    
}

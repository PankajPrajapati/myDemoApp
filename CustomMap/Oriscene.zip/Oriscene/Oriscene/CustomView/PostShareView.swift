//
//  PostShareView.swift
//  Oriscene
//
//  Created by Parth on 24/11/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol SharePostDelegate {
    func hideSharePostView() -> Void
    func sharePostClicked(strDescription: String,indexOfObject : NSInteger) -> Void
}

class PostShareView: UIView, UITextFieldDelegate {

    var delegate : SharePostDelegate?
    var index : NSInteger = -1
    
    @IBOutlet var viewSharePostContainer: UIView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var imgUserPic: UIImageView!
    @IBOutlet var btnClose: UIButton!
    @IBOutlet var viewMessageContainer: UIView!
    @IBOutlet var txtMessage: UITextField!
    @IBOutlet var btnShare: UIButton!
    @IBOutlet var lblPostDetail: UILabel!
    
    @IBOutlet var bottomConstPostShareView: NSLayoutConstraint!
    
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "PostShareView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        viewSharePostContainer.layer.cornerRadius = 3.0
        viewSharePostContainer.layer.masksToBounds = true
        viewMessageContainer.layer.cornerRadius = 3.0
        viewMessageContainer.layer.masksToBounds = true
        viewMessageContainer.layer.borderWidth = 1.0
        viewMessageContainer.layer.borderColor = UIColor.lightGray.cgColor
        
        imgUserPic.layer.cornerRadius = imgUserPic.frame.size.height / 2.0
        imgUserPic.layer.masksToBounds = true
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.bottomConstPostShareView?.constant = 0.0
            } else {
                self.bottomConstPostShareView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.layoutIfNeeded()
            },
                           completion: nil)
        }
    }
    
    
    @IBAction func btnHideShareViewAction(_ sender: Any) {
        delegate?.hideSharePostView()
    }
    @IBAction func btnCloseAction(_ sender: Any) {
        delegate?.hideSharePostView()
    }
    @IBAction func btnSharePostAction(_ sender: Any) {
        delegate?.sharePostClicked(strDescription: txtMessage.text!, indexOfObject: index)
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func setUserData() -> Void {
        let userDefault = UserDefaults.standard .dictionaryRepresentation()
        if userDefault.keys.contains("userData") {
            let dictUserData =  userDefault["userData"] as! Dictionary<String,Any>
            if dictUserData.keys.contains("photo") {
                let strPhotoName = dictUserData["photo"] as! String
                if strPhotoName.characters.count != 0 {
                    let strUrl = PROFILE_PIC_BASEURL + (dictUserData["photo"] as! String)
                    let fileUrl = NSURL(string: strUrl)
                    
                    imgUserPic.sd_setImage(with: fileUrl as URL!, placeholderImage: #imageLiteral(resourceName: "default_img"), options: [SDWebImageOptions.continueInBackground, SDWebImageOptions.lowPriority, SDWebImageOptions.refreshCached, SDWebImageOptions.handleCookies, SDWebImageOptions.retryFailed]) { (image, error, cacheType, url) in
                        if error != nil {
                            print("Failed: \(error)")
                        } else {
                            print("Success")
                        }
                    }
                }
                else{
                    imgUserPic.image = #imageLiteral(resourceName: "default_img")
                }
            }
            else{
                imgUserPic.image = #imageLiteral(resourceName: "default_img")
            }

            lblUserName.text = (dictUserData["firstname"] as! String?)! + " " + (dictUserData["lastname"] as! String?)!
        }
    }

}

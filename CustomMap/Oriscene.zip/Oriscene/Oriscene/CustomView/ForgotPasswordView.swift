//
//  ForgotPasswordView.swift
//  Oriscene
//
//  Created by Parth on 15/12/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit

protocol ForgotPasswordViewDelegate {
    func hideForgotPasswordView() -> Void
    func requestForgotPasswordClicked() -> Void
}

class ForgotPasswordView: UIView {

    var delegate : ForgotPasswordViewDelegate?
    
    @IBOutlet var btnHideForgotPasswordView: UIButton!
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var viewEmailContainer: UIView!
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var imgEmail: UIImageView!
    
    @IBOutlet var btnBottomConstForgotPasswrodView: NSLayoutConstraint!
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "ForgotPasswordView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        
        viewEmailContainer.layer.cornerRadius = 3.0
        viewEmailContainer.layer.masksToBounds = true
        viewEmailContainer.layer.borderWidth = 1.0
        viewEmailContainer.layer.borderColor = UIColor.init(red: 216.0/255.0, green: 220.0/255.0, blue: 223.0/255.0, alpha: 1.0).cgColor
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardNotification(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
 
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    // MARK: - Keyboard Notification
    
    func keyboardNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let endFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
            let duration:TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIViewAnimationOptions.curveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            if (endFrame?.origin.y)! >= UIScreen.main.bounds.size.height {
                self.btnBottomConstForgotPasswrodView?.constant = 0.0
            } else {
                self.btnBottomConstForgotPasswrodView?.constant = endFrame?.size.height ?? 0.0
            }
            UIView.animate(withDuration: duration,
                           delay: TimeInterval(0),
                           options: animationCurve,
                           animations: {
                            self.layoutIfNeeded()
            },
                           completion: nil)
        }
    }

    @IBAction func btnHideForgotPasswordViewAction(_ sender: Any) {
        txtEmail.resignFirstResponder()
        delegate?.hideForgotPasswordView()
    }
    @IBAction func btnHideForgotPasswrodView(_ sender: Any) {
        txtEmail.resignFirstResponder()
        delegate?.hideForgotPasswordView()
    }
    @IBAction func btnRequestForgotPasswordAction(_ sender: Any) {
        delegate?.requestForgotPasswordClicked()
    }
    @IBAction func btnCancelForgotPasswordAction(_ sender: Any) {
        txtEmail.text = ""
        txtEmail.resignFirstResponder()
        delegate?.hideForgotPasswordView()
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

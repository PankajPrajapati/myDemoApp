//
//  AudioPlayView.swift
//  Oriscene
//
//  Created by Parth on 19/12/16.
//  Copyright © 2016 Tristate. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

protocol AudioPlayViewDelegate {
    func hideAudioPlayView() -> Void
    func showSpinnerCallBack() -> Void
    func hideSpinnerCallBack() -> Void
}

class AudioPlayView: UIView {
    
    var delegate : AudioPlayViewDelegate?
    var player : AVPlayer?
    var isAudioPlaying : Bool = false
    var timer :Timer? = nil
    var timeForAudio : Double = 0.0
    var currentAudioTime = 0
    var dictPostDetail = Dictionary<String, Any>()
    var currentPostType : NSInteger = -1
    
    @IBOutlet var btnHideAudioPlay: UIButton!
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var sliderProgress: UISlider!
    @IBOutlet var btnPlayPause: UIButton!
    @IBOutlet weak var lblTime: UILabel!
    
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "AudioPlayView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        viewContainer.layer.cornerRadius = 3.0
        viewContainer.layer.masksToBounds = true
        let customBounds = CGRect(origin: sliderProgress.frame.origin, size: CGSize(width: sliderProgress.frame.size.width, height: 10.0))
        sliderProgress.trackRect(forBounds: customBounds)
    }
    
    //MARK: - Button Click Action

    @IBAction func btnHideAudioPlayViewAction(_ sender: Any) {
        delegate?.hideAudioPlayView()
        perform(#selector(resetPlayerView), with: nil, afterDelay: 0.3)
    }
    
    @IBAction func btnPlayPauseAction(_ sender: Any) {
    
        if isAudioPlaying {
            player?.pause()
            timer?.invalidate()
            timer = nil
            isAudioPlaying = false
        }
        else{
            isAudioPlaying = true
            if (self.player != nil) {
                player?.play()
                timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector:#selector(updateProgressView), userInfo: nil, repeats: true)
            }else{
                playAudio()
            }
        }
        btnPlayPause.isSelected = !btnPlayPause.isSelected
    }
    
      //MARK: - AVPlayer Play Method
    func playAudio() -> Void {
        print("player started")
        let arrAttachment = dictPostDetail["att_detail"] as! [Dictionary<String,Any>]
        let dictPostData = arrAttachment[0]
       
        let strAudioName = dictPostData["attachment_name"] as! String
        if strAudioName.characters.count != 0 {
            
            var strBaseUrl = ""
            if currentPostType == CurrentSelectedPostType.BOTH.rawValue || currentPostType == CurrentSelectedPostType.SHARE_POST.rawValue {
                strBaseUrl = AUDIO_ATTACHMENT_BASE_URL
            }
            else if currentPostType == CurrentSelectedPostType.SELL_POST.rawValue {
                strBaseUrl = SELL_AUDIO_ATTACHMENT_BASE_URL
            }
            
            let strUrl = strBaseUrl + (dictPostData["attachment_name"] as! String)
            let url = URL(string: strUrl)!
            delegate?.showSpinnerCallBack()
            DispatchQueue.global().async {
                HttpDownloader.loadFileSync(url: url as NSURL, completion: { (path, error) in
                    DispatchQueue.main.async {
                        self.delegate?.hideSpinnerCallBack()
                        if path != "" {
                            let urlLocal = URL(fileURLWithPath: path);
                            let playerItem = AVPlayerItem(url: urlLocal)
                            self.player = AVPlayer(playerItem:playerItem)
                            self.player!.volume = 1.0
                            self.player?.currentItem!.addObserver(self, forKeyPath: "status", options: NSKeyValueObservingOptions(), context: nil)
                            self.player!.play()
                        }
                    }
                })
            }
        }
    }
    
    //MARK: - AVPlayer Notification Method
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
      
        if player?.currentItem != nil {
            player?.currentItem?.removeObserver(self, forKeyPath: "status")
        }
        
        if (keyPath == "status") {
            if let currentItem = self.player?.currentItem {
                let status = currentItem.status
                if (status == .readyToPlay) {
                    let duration : CMTime = (self.player?.currentItem!.asset.duration)!;
                    let seconds = CMTimeGetSeconds(duration);
                    timeForAudio = round(seconds)
                    sliderProgress.maximumValue = Float(timeForAudio)
                    timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector:#selector(updateProgressView), userInfo: nil, repeats: true)
                }
                else{
                    //display error if you want 
                    print("Player failed!!")
                }
            }
        }
    }
    
      //MARK: - Update ProgressView Method
    func updateProgressView() -> Void {
        //update progressview 
        if timeForAudio > 0 {
            
            timeForAudio -= 1
            currentAudioTime += 1
            print("====================")
            print(timeForAudio)
            print("====================")
            print(currentAudioTime)
            print("====================")
            let min = timeForAudio/60
            let sec  = timeForAudio.truncatingRemainder(dividingBy:60)
         
            lblTime.text = String.localizedStringWithFormat("%2.0f.%2.0f", min, sec)
            sliderProgress.value = Float(currentAudioTime)
            print(lblTime.text!)
        }
        else{
            self.player = nil
            btnPlayPause.isSelected = false
            timer?.invalidate()
            timer = nil
            isAudioPlaying = false
            currentAudioTime = 0
            timeForAudio = 0.0
            sliderProgress.maximumValue = 0.0
            sliderProgress.value = 0.0
        }
    }
    
    //MARK: - Reset Audio PlayerView Method
    func resetPlayerView() -> Void {
        self.player = nil
        btnPlayPause.isSelected = false
        timer?.invalidate()
        timer = nil
        isAudioPlaying = false
        currentAudioTime = 0
        timeForAudio = 0.0
        sliderProgress.maximumValue = 0.0
        sliderProgress.value = 0.0
        lblTime.text = "0.0"
        lblTitle.text = ""
    }
    // open func trackRect(forBounds bounds: CGRect) -> CGRect
//     func trackRect(forBounds bounds: CGRect) -> CGRect
//    {
//        let rect:CGRect = CGRect (x:sliderProgress.frame.origin.x, y: sliderProgress.frame.origin.y, width:sliderProgress.frame.width, height: 30)
//        return rect
//    }

}
